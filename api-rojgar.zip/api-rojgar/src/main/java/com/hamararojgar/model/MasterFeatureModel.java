package com.hamararojgar.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "mst_feature")
@Entity
public class MasterFeatureModel extends CommonDBFields{
	
	public String getFeatureCode() {
		return featureCode;
	}

	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}

	public String getFeature() {
		return feature;
	}

	public void setFeature(String feature) {
		this.feature = feature;
	}

	
	@Override
	public String toString() {
		return "MasterFeatureModel [featureCode=" + featureCode + ", feature=" + feature + "]";
	}


	@Column(name="vc_feature_code")
	private String featureCode;
	
	@Column(name="vc_feature")
	private String feature;
	
	
}