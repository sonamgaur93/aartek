package com.hamararojgar.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hamararojgar.dto.JobMasterDto;


public class JobSeekerMasterQueryMapper implements RowMapper<JobSeekerMasterDto> {

	public JobSeekerMasterDto mapRow(ResultSet resultSet, int i) throws SQLException {

		JobSeekerMasterDto job = new JobSeekerMasterDto();
		job.setAddress(resultSet.getString("address"));
		job.setAdhaar_image_url(resultSet.getString("adhaar_image_url"));
		job.setAvailability(resultSet.getString("availability"));
		job.setContact(resultSet.getString("contact_no"));
		job.setCurrent_location(resultSet.getString("current_location"));
		job.setEmail(resultSet.getString("email"));
		job.setExpected_compensation(resultSet.getString("expected_compensation"));
		job.setExpected_salary(resultSet.getString("expected_salary"));
		job.setFather_name(resultSet.getString("father_name"));
		job.setMessage(resultSet.getString("message"));
		job.setName(resultSet.getString("name"));
		job.setPreferred_location(resultSet.getString("preferred_location"));
		job.setProfile_pic_url(resultSet.getString("profile_pic_url"));
		job.setVerified(resultSet.getBoolean("verified"));
		job.setExperience(resultSet.getString("experience"));
		job.setId(resultSet.getLong("id"));
		job.setRecording_url(resultSet.getString("recording_url"));
		job.setSkills(resultSet.getString("skills"));
		job.setStatus(resultSet.getString("status"));
		return job;
	}
}