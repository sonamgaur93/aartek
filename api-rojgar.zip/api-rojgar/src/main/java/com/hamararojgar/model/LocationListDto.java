package com.hamararojgar.model;

import java.util.List;

public class LocationListDto extends ResponseDto{

	List<LocationMaster> locationList ;

	public List<LocationMaster> getLocationList() {
		return locationList;
	}

	public void setLocationList(List<LocationMaster> locationList) {
		this.locationList = locationList;
	}
	
	
}
