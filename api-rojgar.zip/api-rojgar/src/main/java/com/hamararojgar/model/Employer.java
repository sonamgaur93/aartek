package com.hamararojgar.model;

import java.time.Instant;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.BreakIterator;

@Table(name = "employer_master")
@Entity
public class Employer extends CommonDBFields{

	private String email;
	private String phone;
	private String password;
	private String name;
	private String company;
	private String address;
	private String pan;
	private String gst;
	private String businessType;
	private String description;
	private String recordingUrl;
	private String companyImage;
	private String companyImage2;
	private String companyImage3;
	private String companyImage4;
	private String companyImage5;
	private String deviceToken; 
	private String status; 
	private Boolean verified;
	private Boolean mobileVerification;
	private Boolean emailVerification;
	private Boolean accountVerification;
	private Instant registeredDateTime;
	private Long leadId;
	
	
	
	
	public Long getLeadId() {
		return leadId;
	}

	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		if(null == phone || phone.trim().isEmpty()) {
			phone="";
		}
			
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		
		if(null != name && !name.trim().isEmpty()) {
			return UCharacter.toTitleCase(name, BreakIterator.getTitleInstance());
		}
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCompany() {
		if(null != company && !company.trim().isEmpty()) {
			return UCharacter.toTitleCase(company, BreakIterator.getTitleInstance());
		}
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getGst() {
		return gst;
	}

	public void setGst(String gst) {
		this.gst = gst;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRecordingUrl() {
		return recordingUrl;
	}

	public void setRecordingUrl(String recordingUrl) {
		this.recordingUrl = recordingUrl;
	}

	public String getCompanyImage() {
		return companyImage;
	}

	public void setCompanyImage(String companyImage) {
		this.companyImage = companyImage;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getVerified() {
		return verified;
	}

	public void setVerified(Boolean verified) {
		this.verified = verified;
	}

	public String getCompanyImage2() {
		return companyImage2;
	}

	public void setCompanyImage2(String companyImage2) {
		this.companyImage2 = companyImage2;
	}

	public String getCompanyImage3() {
		return companyImage3;
	}

	public void setCompanyImage3(String companyImage3) {
		this.companyImage3 = companyImage3;
	}

	public String getCompanyImage4() {
		return companyImage4;
	}

	public void setCompanyImage4(String companyImage4) {
		this.companyImage4 = companyImage4;
	}

	public String getCompanyImage5() {
		return companyImage5;
	}

	public void setCompanyImage5(String companyImage5) {
		this.companyImage5 = companyImage5;
	}

	public Boolean getMobileVerification() {
		return mobileVerification;
	}

	public void setMobileVerification(Boolean mobileVerification) {
		this.mobileVerification = mobileVerification;
	}

	public Boolean getEmailVerification() {
		return emailVerification;
	}

	public void setEmailVerification(Boolean emailVerification) {
		this.emailVerification = emailVerification;
	}

	public Instant getRegisteredDateTime() {
		return registeredDateTime;
	}

	public void setRegisteredDateTime(Instant registeredDateTime) {
		this.registeredDateTime = registeredDateTime;
	}

	public Boolean getAccountVerification() {
		return accountVerification;
	}

	public void setAccountVerification(Boolean accountVerification) {
		this.accountVerification = accountVerification;
	}

	
	

	
	
	

	
	

	@Override
	public String toString() {
		return "Employer [ email=" + email + ", phone=" + phone + ", password=" + password + ", name="
				+ name + ", company=" + company + ", address=" + address + ", pan=" + pan + ", gst=" + gst
				+ ", businessType=" + businessType + ", description=" + description + ", recordingUrl=" + recordingUrl
				+ ", companyImage=" + companyImage + ", companyImage2=" + companyImage2 + ", companyImage3="
				+ companyImage3 + ", companyImage4=" + companyImage4 + ", companyImage5=" + companyImage5
				+ ", deviceToken=" + deviceToken + ", status=" + status + ", verified=" + verified
				+ ", mobileVerification=" + mobileVerification + ", emailVerification=" + emailVerification
				+ ", accountVerification=" + accountVerification + ", registeredDateTime=" + registeredDateTime + "]";
	}

}
