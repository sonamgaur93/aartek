package com.hamararojgar.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "campaign_lead")
@Entity
public class RelationCampaignLead extends CommonDBFields{
	
	
	public Long getCampaignCode() {
		return campaignCode;
	}

	public void setCampaignCode(Long campaignCode) {
		this.campaignCode = campaignCode;
	}

	public Long getLeadCode() {
		return leadCode;
	}

	public void setLeadCode(Long leadCode) {
		this.leadCode = leadCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name="cl_campaign_code")
	private Long campaignCode;
	
	@Column(name="cl_lead_code")
	private Long leadCode;
	
	@Column(name="cl_status")
	private String status;
	
}