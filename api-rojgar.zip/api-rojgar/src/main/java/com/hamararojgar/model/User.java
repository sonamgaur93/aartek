package com.hamararojgar.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Id;

@Table(name = "admin_users")
@Entity
public class User extends CommonDBFields {
	
	private String username;
	private String email;
	private String password;
	private String passwords;
	private String profilePicUrl;
	private String role;
	private String status;
	
	
	public User() {
	}

	public User(String username, String email, String password, String passwords, String role) {
		this.username = username;
		this.email = email;
		this.password = password;
		this.passwords = password;
		this.role = role;
	}
	

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPasswords() {
		return passwords;
	}

	public void setPasswords(String passwords) {
		this.passwords = passwords;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getProfilePicUrl() {
		return profilePicUrl;
	}

	public void setProfilePicUrl(String profilePicUrl) {
		this.profilePicUrl = profilePicUrl;
	}
	
	
	
	
	@Override
	public String toString() {
		return "User [id=" + getId() + ", username=" + username + ", email=" + email + ", password=" + password
				+ ", passwords=" + passwords + ", profilePicUrl=" + profilePicUrl + ", role=" + role + ", status="
				+ status + "]";
	}

	

}
