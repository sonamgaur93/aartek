package com.hamararojgar.model;

import java.util.List;

public class SkillListDto extends ResponseDto{
	
	List<SkillMaster> skillList ;

	public List<SkillMaster> getSkillList() {
		return skillList;
	}

	public void setSkillList(List<SkillMaster> skillList) {
		this.skillList = skillList;
	}
	

}
