package com.hamararojgar.model;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.BreakIterator;

@Table(name = "job_seeker_master")
@Entity
public class JobSeekerMaster  extends CommonDBFields{
	
	public Long getLeadId() {
		return leadId;
	}

	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	
	public Boolean getVerified() {
		return verified;
	}
	public void setVerified(Boolean verified) {
		this.verified = verified;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getName() {
		if(null != name && !name.isEmpty()) {
			return UCharacter.toTitleCase(name, BreakIterator.getTitleInstance());
		}
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFather_name() {
		if(null != father_name && !father_name.isEmpty()) {
			return UCharacter.toTitleCase(father_name, BreakIterator.getTitleInstance());
		}
		return father_name;
	}
	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}
	public String getExpected_salary() {
		return expected_salary;
	}
	public void setExpected_salary(String expected_salary) {
		this.expected_salary = expected_salary;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getCurrent_location() {
		return current_location;
	}
	public void setCurrent_location(String current_location) {
		this.current_location = current_location;
	}
	public String getPreferred_location() {
		return preferred_location;
	}
	public void setPreferred_location(String preferred_location) {
		this.preferred_location = preferred_location;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getExpected_compensation() {
		return expected_compensation;
	}
	public void setExpected_compensation(String expected_compensation) {
		this.expected_compensation = expected_compensation;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getAdhaar_image_url() {
		return adhaar_image_url;
	}
	public void setAdhaar_image_url(String adhaar_image_url) {
		this.adhaar_image_url = adhaar_image_url;
	}
	public String getRecording_url() {
		return recording_url;
	}
	public void setRecording_url(String recording_url) {
		this.recording_url = recording_url;
	}
	public String getProfile_pic_url() {
		return profile_pic_url;
	}
	public void setProfile_pic_url(String profile_pic_url) {
		this.profile_pic_url = profile_pic_url;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	public String getDeviceToken() {
		return deviceToken;
	}
	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}
	
	public Boolean getEmailVerification() {
		return emailVerification;
	}
	public void setEmailVerification(Boolean emailVerification) {
		this.emailVerification = emailVerification;
	}
	public Boolean getAccountVerification() {
		return accountVerification;
	}
	public void setAccountVerification(Boolean accountVerification) {
		this.accountVerification = accountVerification;
	}
	public String getWhatsappNumber() {
		return whatsappNumber;
	}
	public void setWhatsappNumber(String whatsappNumber) {
		this.whatsappNumber = whatsappNumber;
	}
	public String getWhatsappVerification() {
		return whatsappVerification;
	}
	public void setWhatsappVerification(String whatsappVerification) {
		this.whatsappVerification = whatsappVerification;
	}
	
	
	
	public Boolean getMobileVerification() {
		return mobileVerification;
	}
	public void setMobileVerification(Boolean mobileVerification) {
		this.mobileVerification = mobileVerification;
	}

	public Instant getRegistredDateTime() {
		return registredDateTime;
	}

	public void setRegistredDateTime(Instant registredDateTime) {
		this.registredDateTime = registredDateTime;
	}
	
	
	
	
	
	

	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("JobSeekerMaster [id=");
		builder.append(getId());
		builder.append(", contact_no=");
		builder.append(contact);
		builder.append(", name=");
		builder.append(name);
		builder.append(", father_name=");
		builder.append(father_name);
		builder.append(", expected_salary=");
		builder.append(expected_salary);
		builder.append(", experience=");
		builder.append(experience);
		builder.append(", address=");
		builder.append(address);
		builder.append(", skills=");
		builder.append(skills);
		builder.append(", current_location=");
		builder.append(current_location);
		builder.append(", preferred_location=");
		builder.append(preferred_location);
		builder.append(", availability=");
		builder.append(availability);
		builder.append(", expected_compensation=");
		builder.append(expected_compensation);
		builder.append(", message=");
		builder.append(message);
		builder.append(", adhaar_image_url=");
		builder.append(adhaar_image_url);
		builder.append(", recording_url=");
		builder.append(recording_url);
		builder.append(", profile_pic_url=");
		builder.append(profile_pic_url);
		builder.append(", registredDateTime=");
		builder.append(registredDateTime);
		builder.append("]");
		return builder.toString();
	}	
	
	@Column(name = "contact_no")
	private String contact; 
	
	@Column(name = "device_token")
	private String deviceToken;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "father_name")
	private String father_name;
	
	@Column(name = "expected_salary")
	private String expected_salary;
	
	@Column(name = "experience")
	private String experience;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "skills")
	private String skills;
	
	@Column(name = "current_location")
	private String current_location;
	
	@Column(name = "preferred_location")
	private String preferred_location;
	
	@Column(name = "availability")
	private String availability;
	
	@Column(name = "expected_compensation")
	private String expected_compensation;
	
	@Column(name = "message")
	private String message;
	
	@Column(name = "adhaar_image_url")
	private String adhaar_image_url;
	
	@Column(name = "recording_url")
	private String recording_url;
	
	@Column(name = "profile_pic_url")
	private String profile_pic_url;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "verified")
	private Boolean verified;
	
	@Column(name = "email_verification")
	private Boolean emailVerification;
	
	@Column(name = "account_verification")
	private Boolean accountVerification;
	
	@Column(name = "whatsapp_number")
	private String whatsappNumber;
	
	@Column(name = "whatsapp_verification")
	private String whatsappVerification;	
	
	@Column(name = "mobile_verification")
	private Boolean mobileVerification;
	
	@Column(name = "lead_id")
	private Long leadId;
	
	@Column(name = "dt_register_date")
	private Instant registredDateTime;
	
	
}
