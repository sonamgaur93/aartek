package com.hamararojgar.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "job_skill_map")
@Entity
public class JobSkillMap {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "job_id")
	private int jobId;
	@Column(name = "skill_id")
	private int skillId;
	
	

	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getJob_id() {
		return jobId;
	}
	public void setJob_id(int job_id) {
		this.jobId = job_id;
	}
	public int getSkill_id() {
		return skillId;
	}
	public void setSkill_id(int skill_id) {
		this.skillId = skill_id;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}
	
	
	
	

}
