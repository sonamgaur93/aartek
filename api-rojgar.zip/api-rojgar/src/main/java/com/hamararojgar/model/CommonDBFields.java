package com.hamararojgar.model;

import java.time.Instant;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class CommonDBFields {
	
	public Instant getEntryDateTime() {
		return entryDateTime;
	}
	public void setEntryDateTime(Instant entryDateTime) {
		this.entryDateTime = entryDateTime;
	}
	public Instant getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(Instant updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	
	
	
	
//	public String getPlatform() {
//		return platform;
//	}
//	public void setPlatform(String platform) {
//		this.platform = platform;
//	}
//	public String getUpdateByPerson() {
//		return updateByPerson;
//	}
//	public void setUpdateByPerson(String updateByPerson) {
//		this.updateByPerson = updateByPerson;
//	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "CommonDBFields [entryDateTime=" + entryDateTime + ", updateDateTime=" + updateDateTime + "]";
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Instant entryDateTime;
	private Instant updateDateTime;
//	private String platform;
//	private String updateByPerson;
}