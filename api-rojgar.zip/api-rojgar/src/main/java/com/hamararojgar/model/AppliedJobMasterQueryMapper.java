package com.hamararojgar.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hamararojgar.dto.JobMasterDto;


public class AppliedJobMasterQueryMapper implements RowMapper<JobMasterDto> {

	public JobMasterDto mapRow(ResultSet resultSet, int i) throws SQLException {

		JobMasterDto job = new JobMasterDto();
		job.setAccomodation(resultSet.getString("accomodation"));
		job.setComponsation(resultSet.getString("componsation"));
		job.setDescription(resultSet.getString("description"));
		job.setExperience(resultSet.getString("experience"));
		job.setFood(resultSet.getString("food"));
		job.setId(resultSet.getLong("id"));
		job.setJob_type(resultSet.getString("job_type"));
		job.setLeave_policy(resultSet.getString("leave_policy"));
		job.setLocation(resultSet.getString("location"));
		job.setOpenings(resultSet.getInt("openings"));
		job.setRecording_url(resultSet.getString("recording_url"));
		job.setSkills(resultSet.getString("skills"));
		job.setStatus(resultSet.getString("status"));
		job.setTitle(resultSet.getString("title"));
		job.setContact(resultSet.getString("contact"));
		job.setAppliedJobId(resultSet.getInt("appliedJobId"));
		job.setAppliedDate(resultSet.getString("appliedDate"));
		job.setAppliedJobType(resultSet.getString("appliedJobType"));
		return job;
	}
}