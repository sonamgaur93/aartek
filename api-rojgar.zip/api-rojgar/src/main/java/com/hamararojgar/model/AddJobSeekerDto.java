package com.hamararojgar.model;

import org.springframework.web.multipart.MultipartFile;

public class AddJobSeekerDto{

	private int job_seeker_id;
	private String deviceToken;
	private String contact_no;
	private String name;
	private String email;
	private String father_name;
	private String expected_salary;
	private String experience;
	private String address;
	private String skills;
	private String current_location;
	private String preferred_location;
	private String availability;
	private String expected_compensation;
	private String message;
	private String status;
	private Boolean verified;
	private MultipartFile adhaar_image_multipart;
	private MultipartFile recording_multipart;
	private MultipartFile profile_pic_multipart;

	private Boolean emailVerification;
	private Boolean accountVerification;
	private String whatsappNumber;
	private String whatsappVerification;
	private Boolean mobileVerification;
	
	private String comment;

	
	
	
	
	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getJob_seeker_id() {
		return job_seeker_id;
	}

	public void setJob_seeker_id(int job_seeker_id) {
		this.job_seeker_id = job_seeker_id;
	}

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFather_name() {
		return father_name;
	}

	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}

	public String getExpected_salary() {
		return expected_salary;
	}

	public void setExpected_salary(String expected_salary) {
		this.expected_salary = expected_salary;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getCurrent_location() {
		return current_location;
	}

	public void setCurrent_location(String current_location) {
		this.current_location = current_location;
	}

	public String getPreferred_location() {
		return preferred_location;
	}

	public void setPreferred_location(String preferred_location) {
		this.preferred_location = preferred_location;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public String getExpected_compensation() {
		return expected_compensation;
	}

	public void setExpected_compensation(String expected_compensation) {
		this.expected_compensation = expected_compensation;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public MultipartFile getAdhaar_image_multipart() {
		return adhaar_image_multipart;
	}

	public void setAdhaar_image_multipart(MultipartFile adhaar_image_multipart) {
		this.adhaar_image_multipart = adhaar_image_multipart;
	}

	public MultipartFile getRecording_multipart() {
		return recording_multipart;
	}

	public void setRecording_multipart(MultipartFile recording_multipart) {
		this.recording_multipart = recording_multipart;
	}

	public MultipartFile getProfile_pic_multipart() {
		return profile_pic_multipart;
	}

	public void setProfile_pic_multipart(MultipartFile profile_pic_multipart) {
		this.profile_pic_multipart = profile_pic_multipart;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getVerified() {
		return verified;
	}

	public void setVerified(Boolean verified) {
		this.verified = verified;
	}

	public Boolean getEmailVerification() {
		return emailVerification;
	}

	public void setEmailVerification(Boolean emailVerification) {
		this.emailVerification = emailVerification;
	}

	public Boolean getAccountVerification() {
		return accountVerification;
	}

	public void setAccountVerification(Boolean accountVerification) {
		this.accountVerification = accountVerification;
	}

	public String getWhatsappNumber() {
		return whatsappNumber;
	}

	public void setWhatsappNumber(String whatsappNumber) {
		this.whatsappNumber = whatsappNumber;
	}

	public String getWhatsappVerification() {
		return whatsappVerification;
	}

	public void setWhatsappVerification(String whatsappVerification) {
		this.whatsappVerification = whatsappVerification;
	}

	public Boolean getMobileVerification() {
		return mobileVerification;
	}

	public void setMobileVerification(Boolean mobileVerification) {
		this.mobileVerification = mobileVerification;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
	


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AddJobSeekerDto [job_seeker_id=");
		builder.append(job_seeker_id);
		builder.append(", deviceToken=");
		builder.append(deviceToken);
		builder.append(", contact_no=");
		builder.append(contact_no);
		builder.append(", name=");
		builder.append(name);
		builder.append(", email=");
		builder.append(email);
		builder.append(", father_name=");
		builder.append(father_name);
		builder.append(", expected_salary=");
		builder.append(expected_salary);
		builder.append(", experience=");
		builder.append(experience);
		builder.append(", address=");
		builder.append(address);
		builder.append(", skills=");
		builder.append(skills);
		builder.append(", current_location=");
		builder.append(current_location);
		builder.append(", preferred_location=");
		builder.append(preferred_location);
		builder.append(", availability=");
		builder.append(availability);
		builder.append(", expected_compensation=");
		builder.append(expected_compensation);
		builder.append(", message=");
		builder.append(message);
		builder.append(", status=");
		builder.append(status);
		builder.append(", verified=");
		builder.append(verified);
		builder.append(", adhaar_image_multipart=");
		builder.append(adhaar_image_multipart);
		builder.append(", recording_multipart=");
		builder.append(recording_multipart);
		builder.append(", profile_pic_multipart=");
		builder.append(profile_pic_multipart);
		builder.append("]");
		return builder.toString();
	}

}
