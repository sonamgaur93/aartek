package com.hamararojgar.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.BreakIterator;

@Table(name = "skill_master")
@Entity
public class SkillMaster  extends CommonDBFields{

	public String getTitle() {
		if(null != title && !title.isEmpty()) {
			return UCharacter.toTitleCase(title, BreakIterator.getTitleInstance());
		}
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SkillMaster [id=");
		builder.append(getId());
		builder.append(", title=");
		builder.append(title);
		builder.append("]");
		return builder.toString();
	}
	
	private String title;
	
}
