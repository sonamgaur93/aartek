package com.hamararojgar.model;

public class JobSeekerIdDto {

	private int job_seeker_id;

	public int getJob_seeker_id() {
		return job_seeker_id;
	}

	public void setJob_seeker_id(int job_seeker_id) {
		this.job_seeker_id = job_seeker_id;
	}
	
}
