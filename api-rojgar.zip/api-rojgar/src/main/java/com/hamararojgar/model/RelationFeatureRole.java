package com.hamararojgar.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "role_feature_map")
@Entity
public class RelationFeatureRole extends CommonDBFields{

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	
	
	

	@Override
	public String toString() {
		return "RelationFeatureRole [roleCode=" + roleCode + ", actionCode=" + actionCode + "]";
	}




	@Column(name="role_code")
	private String roleCode;
	
	@Column(name="action_code")
	private String actionCode;	
	
}