package com.hamararojgar.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "campaign_members")
@Entity
public class RelationCampaignMembers extends CommonDBFields{
	
	
	public Long getCampaignCode() {
		return campaignCode;
	}

	public void setCampaignCode(Long campaignCode) {
		this.campaignCode = campaignCode;
	}

	public Long getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(Long memberCode) {
		this.memberCode = memberCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name="cm_campaign_code")
	private Long campaignCode;
	
	@Column(name="cm_member_code")
	private Long memberCode;
	
	@Column(name="cm_status")
	private String status;
	
}