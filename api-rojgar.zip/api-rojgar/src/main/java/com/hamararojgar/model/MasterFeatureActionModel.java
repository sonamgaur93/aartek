package com.hamararojgar.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "mst_feature_action")
@Entity
public class MasterFeatureActionModel extends CommonDBFields{
	
	public String getFeatureCode() {
		return featureCode;
	}

	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Column(name="vc_feature_code")
	private String featureCode;
	
	@Column(name="vc_action_code")
	private String actionCode;
	
	@Column(name="vc_action")
	private String action;
	
}