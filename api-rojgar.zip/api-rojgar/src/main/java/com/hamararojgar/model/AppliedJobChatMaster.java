package com.hamararojgar.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "applied_job_chat_master")
@Entity
public class AppliedJobChatMaster {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private int appliedJobId;
	private String message;
	private Date time;
	private String name;
	private String messageBy;
	private String type;
	private String imageUrl;
	private boolean readByEmployer;
	private boolean readByJobSeeker;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getAppliedJobId() {
		return appliedJobId;
	}
	public void setAppliedJobId(int appliedJobId) {
		this.appliedJobId = appliedJobId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public String getMessageBy() {
		return messageBy;
	}
	public void setMessageBy(String messageBy) {
		this.messageBy = messageBy;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isReadByEmployer() {
		return readByEmployer;
	}
	public void setReadByEmployer(boolean readByEmployer) {
		this.readByEmployer = readByEmployer;
	}
	public boolean isReadByJobSeeker() {
		return readByJobSeeker;
	}
	public void setReadByJobSeeker(boolean readByJobSeeker) {
		this.readByJobSeeker = readByJobSeeker;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	
	

}
