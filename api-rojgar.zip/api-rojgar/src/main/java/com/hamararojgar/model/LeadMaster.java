package com.hamararojgar.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "lead_master")
@Entity
public class LeadMaster extends CommonDBFields{

	
	
	public String getAgent_name() {
		return agent_name;
	}
	public void setAgent_name(String agent_name) {
		this.agent_name = agent_name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreate_date() {
		return create_date;
	}
	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getExpected_salary() {
		return expected_salary;
	}
	public void setExpected_salary(String expected_salary) {
		this.expected_salary = expected_salary;
	}
	public String getExpected_compensation() {
		return expected_compensation;
	}
	public void setExpected_compensation(String expected_compensation) {
		this.expected_compensation = expected_compensation;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getRecording_url() {
		return recording_url;
	}
	public void setRecording_url(String recording_url) {
		this.recording_url = recording_url;
	}
	public String getProfile_pic_url() {
		return profile_pic_url;
	}
	public void setProfile_pic_url(String profile_pic_url) {
		this.profile_pic_url = profile_pic_url;
	}
	public int getAgent_id() {
		return agentId;
	}
	public void setAgent_id(int agent_id) {
		this.agentId = agent_id;
	}
	public int getAgentId() {
		return agentId;
	}
	public void setAgentId(int agentId) {
		this.agentId = agentId;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getBussiness_type() {
		return bussiness_type;
	}
	public void setBussiness_type(String bussiness_type) {
		this.bussiness_type = bussiness_type;
	}
	
	public String getGst() {
		return gst;
	}
	public void setGst(String gst) {
		this.gst = gst;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getLattitude() {
		return lattitude;
	}
	public void setLattitude(String lattitude) {
		this.lattitude = lattitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}


	
	
	
	


	@Column(name = "agent_id")
	private int agentId;
	private String agent_name;
	private String type;
	private String priority;
	private String status;
	private String stage;
	private Date create_date;
	private String date;
	private String name;
	private String phone;
	private String email;
	private String company_name;
	private String bussiness_type;
	private String gst;
	private String pan;
	private String lattitude;
	private String longitude;
	private String address;
	private String note;
	private String availability;
	private String expected_salary;
	private String expected_compensation;
	private String experience;
	private String skills;
	private String recording_url;
	private String profile_pic_url;
	
	@Column(name = "campaign_code")
	private String campaignCode;
	
	@Column(name = "customer_id")
	private String customerId;
	
	
}
