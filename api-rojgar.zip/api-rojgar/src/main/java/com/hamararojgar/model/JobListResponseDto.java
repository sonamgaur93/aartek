package com.hamararojgar.model;

import java.util.List;

import com.hamararojgar.dto.JobMasterDto;

public class JobListResponseDto extends ResponseDto{
	
	List<JobMasterDto> jobList ;

	public List<JobMasterDto> getJobList() {
		return jobList;
	}

	public void setJobList(List<JobMasterDto> jobList) {
		this.jobList = jobList;
	}

}
