package com.hamararojgar.config;

public class ServerConstants {

	public static final String SUCCESRESPONSECODE = "1111";
	public static final String SUCCESRESPONSEDESC = "Success";
	public static final String FAILURERESPONSECODE = "0000";
	public static final String FAILURERESPONSEDESC = "Failure";
	public static final String UNAUTHOROSEDDESC = "Unauthorised";
	public static final String ALREADYEXISTS = "Already Exists";
	public static final String UPDATED = "Updated Successfully.";
	public static final String ADDED = "Added Successfully.";
	public static final String ASSIGNED = "Assigned Successfully";
	public static final String ACTIVE = "ACTIVE";
	public static final String INACTIVE = "IN-ACTIVE";
	public static final String APPROVED = "Approved Successfully";
	public static final String REJECTED = "Rejected Successfully";
	public static final String CREDITLIMITNOTAVAILABLE = "Cant complete this action due to Credit limit. Please co ordinate with Account Manager for Credit Allotment";
	
	//Advertiser Credit Actions
	public static final String CAMPASSIGNED = "ASSIGNED";
	public static final String VIDEOAPPROVED = "APPROVED";
	public static final String CAMPINACTIVE = "CAMP-INACTIVE";
	public static final String ASSIGNEDCAMPINACTIVE = "ASSIGNED-CAMP-INACTIVE";
	
	public static final String NOTALLOWED = "Only Admin is allowed to update Payment";
	public static final String PAYMENTUPDATED = "Payment Updated Successfully";
	public static final String ALREADYAPPLIED = "Already Applied for this Job.";
	public static final String ALREADYINVITED = "Already Invited for this Job.";
	public static final String CODE_VERIFY_TYPE_EMAIL="EMAIL";
	public static final String CODE_VERIFY_TYPE_MOBILE="MOBILE";
	
	public static final String USER_ROLE_FLDA="FLDA";
	public static final String USER_ROLE_CCA="CCA";
	public static final String USER_ROLE_ADM="ADM";
	public static final String USER_ROLE_USR="USR";
	public static final String USER_ROLE_MGR="MGR";
	
}
