package com.hamararojgar.config;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

@Configuration
@EnableAsync
public class SpringAsyncConfig {

	@Value("${app.variables.thread_pool_size}")
	private int thread_pool_size;

	@Bean(name = "asynExecutorMail")
	public Executor threadPoolTaskExecutor() {
		return Executors.newFixedThreadPool(thread_pool_size);
	}

	
}