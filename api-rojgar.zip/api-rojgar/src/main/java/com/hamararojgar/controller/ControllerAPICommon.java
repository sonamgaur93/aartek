package com.hamararojgar.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.ChatReadDto;
import com.hamararojgar.dto.JobMasterDto;
import com.hamararojgar.dto.NotificationDto;
import com.hamararojgar.dto.ResponseNotification;
import com.hamararojgar.dto.SaveJobChat;
import com.hamararojgar.model.AppliedJobChatMaster;
import com.hamararojgar.model.JobMaster;
import com.hamararojgar.model.ResponseDto;
import com.hamararojgar.model.VerifyUserDto;
import com.hamararojgar.payload.request.RequestCampaign;
import com.hamararojgar.payload.response.ResponseCampaign;
import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.repo.AppliedJobChatMasterRepo;
import com.hamararojgar.serviceimpl.JobSeekerService;
import com.hamararojgar.serviceimpl.MasterDataService;
import com.hamararojgar.serviceimpl.ServiceCampaign;
import com.hamararojgar.serviceimpl.ServiceEmployer;
import com.hamararojgar.util.Util;

@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/api-common")
public class ControllerAPICommon {
	
	private static final Logger log = LogManager.getLogger(ControllerAPICommon.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");
	
	@Autowired
	private JobSeekerService rozgarService;
	
	@Autowired
	private MasterDataService masterDataService;
	
	@Autowired
	private ServiceEmployer serviceEmployer;
	
	@Autowired
	private AppliedJobChatMasterRepo appliedJobChatMasterRepo;

	@RequestMapping(value = "/verifyUser", method = RequestMethod.POST)
	public @ResponseBody ResponseDto verifyUser(@RequestBody VerifyUserDto verifyUserDto) {
		ResponseDto responseDTO = new ResponseDto();
		try {
			if (ServerConstants.CODE_VERIFY_TYPE_EMAIL.equalsIgnoreCase(verifyUserDto.getVerificationType())) {
				if (rozgarService.verifyUserByEmail(verifyUserDto)) {
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				} else {
					responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
				}
			} else {
				int id = 0;
				if (verifyUserDto.isRegistration()) {
					id = rozgarService.verifyUserRegistrationMobileOTP(verifyUserDto);
				} else {
					id = rozgarService.verifyUser(verifyUserDto);
				}

				if (id > 0) {
					if (!verifyUserDto.isRegistration()) {
						responseDTO.setJobSeekerId(id);
					}
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				} else {
					responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
				}
			}

		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in verifyUser Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}
	
	@RequestMapping(value = "/getJobDetails/{id}", method = RequestMethod.GET)
	public @ResponseBody JobMasterDto getJobDetails(@PathVariable Long id) {
		reqLog.info("Got getJobSeekerProfileDetails by Id Request with Id : {}", id);
		log.info("Got getJobSeekerProfileDetails by Id Request with Id : {}", id);
		JobMasterDto jobMasterDto = new JobMasterDto();
		try {
			Optional<JobMaster> jobMaster = rozgarService.getJobDetails(id);
			if (jobMaster.isPresent()) {
				ObjectMapper mapper = new ObjectMapper();
				jobMasterDto = mapper.convertValue(jobMaster.get(), JobMasterDto.class);
				jobMasterDto.setSkills(rozgarService.getSkillStringByJobId(jobMasterDto.getId()));
				jobMasterDto.setCompany(serviceEmployer.getEmployer(Long.parseLong(jobMasterDto.getEmployerId())));
				jobMasterDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobMasterDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				jobMasterDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				jobMasterDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			jobMasterDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobMasterDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobDetails Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobMasterDto;
	}
	
	@RequestMapping(value = "/getNotificationList", method = RequestMethod.GET)
	public @ResponseBody NotificationDto getNotification(@RequestParam Map<String, String> allRequestParams) {
		NotificationDto notificationDto = new NotificationDto();
		try {
			List<ResponseNotification> notifications = masterDataService.getNotifications(allRequestParams);
			if (null == notifications) {
				notifications = new ArrayList<ResponseNotification>();
			}
			notificationDto.setNotificationList(notifications);
			notificationDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			notificationDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (

		Exception e) {
			notificationDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			notificationDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getNotificationList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return notificationDto;
	}
	
	@RequestMapping(value = "/getJobChatMessages/{id}", method = RequestMethod.GET)
	public @ResponseBody ChatMessagesDto getJobChatMessages(@PathVariable Long id) {
		reqLog.info("Got getJobChatMessages by Id :{}", id);
		ChatMessagesDto chatMessagesDto = new ChatMessagesDto();
		try {
			List<AppliedJobChatMaster> chatList = appliedJobChatMasterRepo.findByAppliedJobId(id.intValue());
			chatMessagesDto.setChatList(chatList);
			chatMessagesDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			chatMessagesDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			chatMessagesDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			chatMessagesDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobChatMessages Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return chatMessagesDto;
	}
	
	@RequestMapping(value = "/saveJobChatMessage", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseDto saveJobChatMessage(@ModelAttribute SaveJobChat jobSeekerIdDto) {
		ResponseDto responseDTO = new ResponseDto();
		try {
			String result = rozgarService.saveJobChatMessage(jobSeekerIdDto);
			if (result.equalsIgnoreCase(ServerConstants.SUCCESRESPONSEDESC)) {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(result);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(result);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in saveJobChatMessage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}
	
	
	@RequestMapping(value = "/chatReadUpdate", method = RequestMethod.POST)
	public @ResponseBody ResponseDto chatReadUpdate(@RequestBody ChatReadDto jobSeekerIdDto) {
		ResponseDto responseDTO = new ResponseDto();
		try {
			String result = rozgarService.chatReadUpdate(jobSeekerIdDto);
			if (result.equalsIgnoreCase(ServerConstants.SUCCESRESPONSEDESC)) {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(result);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(result);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in chatReadUpdate Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

}