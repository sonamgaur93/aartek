package com.hamararojgar.controller;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.AddUpdateJobDto;
import com.hamararojgar.dto.AdvertisementsDto;
import com.hamararojgar.dto.CheckBlockingDto;
import com.hamararojgar.dto.EmployerDto;
import com.hamararojgar.dto.JobDetailsDto;
import com.hamararojgar.dto.JobSeekerDto;
import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.dto.ResponseDTOEmployer;
import com.hamararojgar.dto.ResponseDTOHamararojgarUser;
import com.hamararojgar.dto.ResponseDTORefferal;
import com.hamararojgar.dto.StatusDTO;
import com.hamararojgar.model.AddJobSeekerDto;
import com.hamararojgar.model.AdvertisementsMaster;
import com.hamararojgar.model.BlockedData;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.JobMaster;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.LocationListDto;
import com.hamararojgar.model.NotificationMaster;
import com.hamararojgar.model.ResponseDto;
import com.hamararojgar.model.SkillListDto;
import com.hamararojgar.model.SkillMaster;
import com.hamararojgar.model.User;
import com.hamararojgar.payload.request.RequestRojgarNotification;
import com.hamararojgar.payload.request.RequestRojgarSearchParameter;
import com.hamararojgar.payload.response.ResponseCampaign;
import com.hamararojgar.payload.response.ResponseEmployer;
import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.payload.response.ResponseHamaraRojgarUser;
import com.hamararojgar.payload.response.ResponseHamararojgarContent;
import com.hamararojgar.payload.response.ResponseModuleComment;
import com.hamararojgar.payload.response.ResponseRojgarJob;
import com.hamararojgar.payload.response.ResponseUser;
import com.hamararojgar.repo.AdvertisementsMasterRepo;
import com.hamararojgar.repo.BlockedDataRepo;
import com.hamararojgar.repo.EmployerRepo;
import com.hamararojgar.repo.LocationMasterRepo;
import com.hamararojgar.repo.NotificationMasterRepo;
import com.hamararojgar.repo.SkillMasterRepo;
import com.hamararojgar.serviceimpl.AdminService;
import com.hamararojgar.serviceimpl.AsyncService;
import com.hamararojgar.serviceimpl.ServiceCampaign;
import com.hamararojgar.serviceimpl.ServiceEmployer;
import com.hamararojgar.serviceimpl.ServiceJobSeeker;
import com.hamararojgar.serviceimpl.ServiceMember;
import com.hamararojgar.serviceimpl.ServiceModuleComment;
import com.hamararojgar.serviceimpl.ServiceNotification;
import com.hamararojgar.serviceimpl.ServiceRojgarJobs;
import com.hamararojgar.util.RojgarConstantProperties;
import com.hamararojgar.util.Util;

@Controller
@CrossOrigin(origins = "*")
public class AdminController {

	private static final Logger log = LogManager.getLogger(AdminController.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	AdminService jobSeekerService;

	@Autowired
	LocationMasterRepo locationMasterRepo;

	@Autowired
	SkillMasterRepo skillMasterRepo;

	@Autowired
	NotificationMasterRepo notificationMasterRepo;

	@Autowired
	AdvertisementsMasterRepo advertisementsMasterRepo;

	@Autowired
	BlockedDataRepo blockedDataRepo;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	RojgarConstantProperties constantProperties;

	@Autowired
	ServiceModuleComment serviceModuleComment;

	@Autowired
	ServiceEmployer serviceEmployer;

	@Autowired
	ServiceRojgarJobs serviceRojgarJobs;

	@Autowired
	ServiceJobSeeker serviceJobSeeker;

	@Autowired
	AsyncService asyncService;

	@Autowired
	ServiceMember serviceMember;

	@Autowired
	Util util;

	@Autowired
	private ServiceCampaign serviceCampaign;

	@Autowired
	ServiceNotification serviceNotification;

	@RequestMapping(value = "/getJobSeekerList", method = RequestMethod.GET)
	public @ResponseBody Page<JobSeekerMaster> getJobSeekerList(Pageable pageable, @RequestParam String name,
			@RequestParam String contact, @RequestParam String email, @RequestParam String verified,
			@RequestParam String status) {

		Page<JobSeekerMaster> jobSeekerList = jobSeekerService.getJobSeekerList(pageable, name, contact, email,
				verified, status);
		return jobSeekerList;
	}

	@RequestMapping(value = "/getseekers", method = RequestMethod.GET)
	public @ResponseBody ResponseHamaraRojgar getJobSeekers(
			@RequestParam(required = false) Map<String, String> searchParameters) {
		reqLog.info("/getseekers called");
		ResponseHamaraRojgar responseHamaraRojgar = serviceJobSeeker.getSeekers(searchParameters);
		if (null != responseHamaraRojgar) {
			responseHamaraRojgar.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} else {
			responseHamaraRojgar = new ResponseHamaraRojgar();
			responseHamaraRojgar.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseHamaraRojgar.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
		}
		return responseHamaraRojgar;
	}

	// getNotifications
	@RequestMapping(value = "/getNotifications", method = RequestMethod.GET)
	public @ResponseBody Page<NotificationMaster> getNotifications(Pageable pageable) {
		Pageable sortedpage = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(),
				Sort.by("id").descending());
		Page<NotificationMaster> jobSeekerList = notificationMasterRepo.findAll(sortedpage);
		return jobSeekerList;
	}

	@RequestMapping(value = "/getAdvertisements", method = RequestMethod.GET)
	public @ResponseBody Page<AdvertisementsMaster> getAdvertisements(Pageable pageable) {
		Pageable sortedpage = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(),
				Sort.by("id").descending());
		Page<AdvertisementsMaster> jobSeekerList = advertisementsMasterRepo.findAll(sortedpage);
		for (AdvertisementsMaster am : jobSeekerList) {
			am.setImageUrl(constantProperties.getBaseUrlImage() + am.getImageUrl());
		}
		return jobSeekerList;
	}

	@RequestMapping(value = "/getEmployerList", method = RequestMethod.GET)
	public @ResponseBody Page<Employer> getEmployerList(Pageable pageable, @RequestParam String name,
			@RequestParam String contact, @RequestParam String email, @RequestParam String verified,
			@RequestParam String status) {
		log.info("/getEmployerList called sdfsdfsdfd");
		Page<Employer> employerList = jobSeekerService.getEmployerList(pageable, name, contact, email, verified,
				status);
		return employerList;
	}

	@RequestMapping(value = "/getEmployers", method = RequestMethod.GET)
	public @ResponseBody ResponseHamaraRojgar getEmployerList(
			@RequestParam(required = false) Map<String, String> searchParameters) {
		reqLog.info("/getEmployers called");
		ResponseHamaraRojgar responseHamaraRojgar = serviceEmployer.getEmployerList(searchParameters);
		if (null != responseHamaraRojgar) {
			responseHamaraRojgar.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} else {
			responseHamaraRojgar = new ResponseHamaraRojgar();
			responseHamaraRojgar.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseHamaraRojgar.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
		}
		return responseHamaraRojgar;
	}

	@RequestMapping(value = "/getJobList", method = RequestMethod.GET)
	public @ResponseBody Page<JobMaster> getJobList(@RequestParam(required = false) Map<String, String> searchParam) {
		Page<JobMaster> jobList = jobSeekerService.getJobList(searchParam);
		return jobList;
	}

	@RequestMapping(value = "/getJobSeekerById/{id}", method = RequestMethod.GET)
	public @ResponseBody JobSeekerDto getJobSeekerById(@PathVariable Long id) {
		reqLog.info("Got Get JobSeeker by Id Request with Id : {}", id);
		JobSeekerDto jobSeekerDto = null;
		try {
			jobSeekerDto = jobSeekerService.getJobSeekerById(id);
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerDto;
	}

	@RequestMapping(value = "/getNotificationById/{id}", method = RequestMethod.GET)
	public @ResponseBody NotificationMaster getNotificationById(@PathVariable Long id) {
		reqLog.info("Got Get JobSeeker by Id Request with Id : {}", id);
		NotificationMaster jobSeekerDto = null;
		try {
			jobSeekerDto = jobSeekerService.getNotificationById(id);
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerDto;
	}

	@RequestMapping(value = "/getAdvertisementById/{id}", method = RequestMethod.GET)
	public @ResponseBody AdvertisementsMaster getAdvertisementById(@PathVariable Long id) {
		reqLog.info("Got Get JobSeeker by Id Request with Id : {}", id);
		AdvertisementsMaster jobSeekerDto = null;
		try {
			jobSeekerDto = jobSeekerService.getAdvertisementById(id);
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerDto;
	}

	@RequestMapping(value = "/getJobDetailsById/{id}", method = RequestMethod.GET)
	public @ResponseBody JobDetailsDto getJobDetailsById(@PathVariable Long id) {
		reqLog.info("Got Get JobSeeker by Id Request with Id : {}", id);
		JobDetailsDto jobDetailsDto = null;
		try {
			jobDetailsDto = jobSeekerService.getJobDetailsById(id);
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobDetailsDto;
	}

	@RequestMapping(value = "/getEmployerById/{id}", method = RequestMethod.GET)
	public @ResponseBody ResponseDTOEmployer getEmployerById(@PathVariable Long id) {
		reqLog.info("Got Get getEmployerById by Id Request with Id : {}", id);
		ResponseDTOEmployer employer = null;
		try {
			employer = jobSeekerService.getEmployerById(id);
			
			
			
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return employer;
	}

	@RequestMapping(value = "/getLocationList", method = RequestMethod.GET)
	public @ResponseBody LocationListDto getLocations() {
		LocationListDto locationListDto = new LocationListDto();
		try {
			locationListDto.setLocationList(locationMasterRepo.findAll());
			locationListDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			locationListDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			locationListDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			locationListDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
		}
		return locationListDto;
	}

	@RequestMapping(value = "/getSkillList", method = RequestMethod.GET)
	public @ResponseBody SkillListDto getSkillList() {
		SkillListDto skillListDto = new SkillListDto();
		try {
			skillListDto.setSkillList(skillMasterRepo.findAll());
			skillListDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			skillListDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			skillListDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			skillListDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
		}
		return skillListDto;
	}
	
	@RequestMapping(value="/getAgents", method = RequestMethod.GET)
	public @ResponseBody ResponseHamaraRojgar getAgentsByType(@RequestParam("type") String type, @RequestParam("page") int pageNo, @RequestParam("size") int size) {
		
			ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
			ResponseUser agentsByType = jobSeekerService.getAgentsByType("FLDA");
			if (null == agentsByType) {
				responseHamaraRojgar.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseHamaraRojgar.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			} else {
				responseHamaraRojgar.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				responseHamaraRojgar.setContent(agentsByType);
			}
			return responseHamaraRojgar;		
		
	 
	}

	@RequestMapping(value = "/updateBlockedStatusClickedEmp", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO updateBlockedStatusClickedEmp(@RequestBody StatusDTO statusDTO) {
		reqLog.info("Got update blocked Status Request for :{}", statusDTO);
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			boolean result = jobSeekerService.updateBlockedStatusClickedEmp(statusDTO);
			if (result) {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/updateBlockedStatusClickedAdd", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO updateBlockedStatusClickedAdd(@RequestBody StatusDTO statusDTO) {
		reqLog.info("Got update blocked Status Request for :{}", statusDTO);
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			boolean result = jobSeekerService.updateBlockedStatusClickedAdd(statusDTO);
			if (result) {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/updateJobStatus", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO updateJobStatus(@RequestBody StatusDTO statusDTO) {
		reqLog.info("Got update blocked Status Request for :{}", statusDTO);
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			boolean result = jobSeekerService.updateJobStatus(statusDTO);
			if (result) {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/updateInfBlockedStatus", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO updateInfBlockedStatus(@RequestBody StatusDTO statusDTO) {
		reqLog.info("Got update blocked Status Request for :{}", statusDTO);
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			boolean result = jobSeekerService.updateInfBlockedStatus(statusDTO);
			if (result) {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/updateJobSeekerDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public @ResponseBody ResponseEntity<ResponseDto> updateJobSeekerDetails(
			@ModelAttribute AddJobSeekerDto addJobSeekerDto, HttpServletRequest request) {
		reqLog.info("Got updateJobSeekerDetails Request for :{}", addJobSeekerDto);
		ResponseDto responseDTO = new ResponseDto();

		try {
			int result = jobSeekerService.updateJobSeekerDetails(addJobSeekerDto);
			if (result > 0) {
				jdbcTemplate.update("delete from blocked_data where key_id=" + addJobSeekerDto.getJob_seeker_id()
						+ " and name='JobSeeker'");
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} /*
				 * else if(result == -1){ responseDTO.setResponseCode(ServerConstants.
				 * FAILURERESPONSECODE); responseDTO.
				 * setResponseDescription("Email Id ALready Exists with Another Job Seeker." );
				 * }
				 */else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/updateJobDetails", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<ResponseDto> updateJobDetails(@RequestBody AddUpdateJobDto addUpdateJobDto) {
		reqLog.info("Got updateJobSeekerDetails Request for :{}", addUpdateJobDto);
		ResponseDto responseDTO = new ResponseDto();

		try {
			int result = jobSeekerService.updateJobDetails(addUpdateJobDto);
			if (result > 0) {
				jdbcTemplate.update(
						"delete from blocked_data where key_id=" + addUpdateJobDto.getJobId() + " and name='Jobs'");
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/checkBlocking", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<ResponseDto> checkBlocking(@RequestBody CheckBlockingDto checkBlockingDto) {
		reqLog.info("Got updateJobSeekerDetails Request for :{}", checkBlockingDto);
		ResponseDto responseDTO = new ResponseDto();
		try {
			BlockedData blockedData = blockedDataRepo.findByKeyIdAndName(checkBlockingDto.getId(),
					checkBlockingDto.getKey());
			if (blockedData != null) {
				Date blockedDate = blockedData.getDate();
				if (blockedData.getUserId() == checkBlockingDto.getUserId()) {
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				} else {
					Date currentDate = new Date();
					long difference_In_Time = currentDate.getTime() - blockedDate.getTime();
					long difference_In_Minutes = (difference_In_Time / (1000 * 60)) % 60;
					if (difference_In_Minutes >= 2) {
						jdbcTemplate.update("delete from blocked_data where id=" + blockedData.getId().intValue());
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
					} else {
						responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
						responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
					}
				}
			} else {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/addBlocking", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<ResponseDto> addBlocking(@RequestBody CheckBlockingDto checkBlockingDto) {
		reqLog.info("Got updateJobSeekerDetails Request for :{}", checkBlockingDto);
		ResponseDto responseDTO = new ResponseDto();
		try {
			BlockedData blockedData = blockedDataRepo.findByKeyIdAndName(checkBlockingDto.getId(),
					checkBlockingDto.getKey());
			if (blockedData != null) {
				blockedData.setDate(new Date());
				blockedData.setUserId(checkBlockingDto.getUserId());
				blockedDataRepo.save(blockedData);
			} else {
				blockedData = new BlockedData();
				blockedData.setKeyId(checkBlockingDto.getId());
				blockedData.setName(checkBlockingDto.getKey());
				blockedData.setDate(new Date());
				blockedData.setUserId(checkBlockingDto.getUserId());
				blockedDataRepo.save(blockedData);
			}
			responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@Autowired
	EmployerRepo employerRepo;

	@RequestMapping(value = "/updateEmployerDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public @ResponseBody ResponseEntity<ResponseDto> updateEmployerDetails(@ModelAttribute EmployerDto employer) {
		reqLog.info("Got updateEmployerDetails Request for :{}", employer);
		ResponseDto responseDTO = new ResponseDto();
		try {
			boolean allow = true;
			Employer employerE = employerRepo.findByEmail(employer.getEmail());

			if (employerE != null) {
				if (employerE.getId().intValue() == employer.getId().intValue()) {
					allow = true;
				} else {
					allow = false;
				}
			}
			if (allow) {
				int result = jobSeekerService.updateEmployerDetails(employer);
				if (result > 0) {
					jdbcTemplate.update(
							"delete from blocked_data where key_id=" + employer.getId() + " and name='Employer'");
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				} else {
					responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
				}
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription("Email Id Already Exists with Another Employer.");
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/addAdvertisement", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public @ResponseBody ResponseEntity<ResponseDTO> addAdvertisement(@ModelAttribute AdvertisementsDto dto,
			HttpServletRequest request) {
		reqLog.info("Got addAdvertisement Request for : {}");
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			if (dto.getId() != null && !dto.getId().equalsIgnoreCase("undefined")) {
				Optional<AdvertisementsMaster> skillMaster = advertisementsMasterRepo
						.findById(Long.parseLong(dto.getId()));
				if (skillMaster.isPresent()) {
					AdvertisementsMaster sm = skillMaster.get();
					sm.setTitle(dto.getTitle());
					sm.setStatus(dto.getStatus());
					if (dto.getFile() != null && !dto.getFile().isEmpty()) {
						try {
							MultipartFile file = dto.getFile();
							FilenameUtils.getExtension(file.getOriginalFilename());
							if (file != null) {
								byte[] bytes = file.getBytes();
								String fName = "ad_banner_" + dto.getId() + "."
										+ FilenameUtils.getExtension(file.getOriginalFilename());

								Path path = Paths.get(constantProperties.getUploadFolderAd() + fName);
								Files.write(path, bytes);
								sm.setImageUrl(fName);
							}
						} catch (Exception e) {
							exceptionLog.error(e.getMessage(), e);
							e.printStackTrace();
						}
					}
					advertisementsMasterRepo.save(sm);
				} else {
					AdvertisementsMaster sm = new AdvertisementsMaster();
					sm.setTitle(dto.getTitle());
					sm.setStatus(dto.getStatus());
					advertisementsMasterRepo.save(sm);
					if (dto.getFile() != null && !dto.getFile().isEmpty()) {
						try {
							MultipartFile file = dto.getFile();
							FilenameUtils.getExtension(file.getOriginalFilename());
							if (file != null) {
								byte[] bytes = file.getBytes();
								String fName = "ad_banner_" + sm.getId() + "."
										+ FilenameUtils.getExtension(file.getOriginalFilename());

								Path path = Paths.get(constantProperties.getUploadFolderAd() + fName);
								Files.write(path, bytes);
								sm.setImageUrl(fName);
							}
						} catch (Exception e) {
							exceptionLog.error(e.getMessage(), e);
							e.printStackTrace();
						}
					}
					advertisementsMasterRepo.save(sm);
				}
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				AdvertisementsMaster sm = new AdvertisementsMaster();
				sm.setTitle(dto.getTitle());
				sm.setStatus(dto.getStatus());
				advertisementsMasterRepo.save(sm);
				if (dto.getFile() != null && !dto.getFile().isEmpty()) {
					try {
						MultipartFile file = dto.getFile();
						FilenameUtils.getExtension(file.getOriginalFilename());
						if (file != null) {
							byte[] bytes = file.getBytes();
							String fName = "ad_banner_" + sm.getId() + "."
									+ FilenameUtils.getExtension(file.getOriginalFilename());

							Path path = Paths.get(constantProperties.getUploadFolderAd() + fName);
							Files.write(path, bytes);
							sm.setImageUrl(fName);
						}
					} catch (Exception e) {
						exceptionLog.error(e.getMessage(), e);
						e.printStackTrace();
					}
				}
				advertisementsMasterRepo.save(sm);
			}
			responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			log.info("Exception in addIndustry Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/addNotification", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<ResponseDTO> addNotification(@Valid @RequestBody NotificationMaster industryDTO,
			HttpServletRequest request, Errors errors) {
		reqLog.info("Got Add Industry Request for : {}", industryDTO);
		Date currentDate = new Date();
		log.info("currentDate  : " + currentDate);
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			if (industryDTO.getId() != null) {
				Optional<NotificationMaster> skillMaster = notificationMasterRepo.findById(industryDTO.getId());
				if (skillMaster.isPresent()) {
					NotificationMaster notificationMaster = skillMaster.get();
					notificationMaster.setTitle(industryDTO.getTitle());
					notificationMaster.setDescription(industryDTO.getDescription());

					if (null != industryDTO.getUserType()) {
						notificationMaster.setUserType(industryDTO.getUserType());
					} else {
						notificationMaster.setUserType("ALL");
					}

					notificationMasterRepo.save(notificationMaster);
					// asyncService.sendPushNotificationForAllEmployers(notificationMaster);
					// asyncService.sendPushNotificationForAllJobSeekers(notificationMaster);
					asyncService.sendPushNotification(notificationMaster);
				} else {
					NotificationMaster notificationMaster = new NotificationMaster();
					notificationMaster.setTitle(industryDTO.getTitle());
					notificationMaster.setDescription(industryDTO.getDescription());
					notificationMaster.setTime(currentDate);
					if (null != industryDTO.getUserType()) {
						notificationMaster.setUserType(industryDTO.getUserType());
					} else {
						notificationMaster.setUserType("ALL");
					}
					notificationMasterRepo.save(notificationMaster);
					// asyncService.sendPushNotificationForAllEmployers(notificationMaster);
					// asyncService.sendPushNotificationForAllJobSeekers(notificationMaster);
					asyncService.sendPushNotification(notificationMaster);
				}
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				NotificationMaster notificationMaster = new NotificationMaster();
				notificationMaster.setTitle(industryDTO.getTitle());
				notificationMaster.setDescription(industryDTO.getDescription());
				notificationMaster.setTime(currentDate);
				if (null != industryDTO.getUserType()) {
					notificationMaster.setUserType(industryDTO.getUserType());
				} else {
					notificationMaster.setUserType("ALL");
				}
				notificationMasterRepo.save(notificationMaster);
				// asyncService.sendPushNotificationForAllEmployers(notificationMaster);
				// asyncService.sendPushNotificationForAllJobSeekers(notificationMaster);
				asyncService.sendPushNotification(notificationMaster);
			}
			responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			log.info("Exception in addIndustry Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@GetMapping("/{moduleName}/{recordId}")
	public @ResponseBody ResponseHamaraRojgar getComments(@PathVariable(name = "moduleName") String moduleName,
			@PathVariable(name = "recordId") String recordId,
			@RequestParam(required = false) Map<String, String> searchParameters) {
		log.info("getComments moduleName {} and recordid {} ", moduleName, recordId);
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseModuleComment responseModuleComment = serviceModuleComment.getComments(moduleName, recordId,
				searchParameters);
		responseHamaraRojgar.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
		responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		responseHamaraRojgar.setContent(responseModuleComment);
		return responseHamaraRojgar;
	}

	@GetMapping("/job/{jobId}/applied")
	public @ResponseBody ResponseHamaraRojgar getAppliedCandidates(@PathVariable(name = "jobId") String jobId,
			@RequestParam(required = false) Map<String, String> searchParameters) {
		reqLog.info("getAppliedCandnoidates jobId {}", jobId);
		System.out.println("searchParameters ======== "+ searchParameters.hashCode());
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseRojgarJob responseRojgarJob = serviceRojgarJobs.getAppliedCandidates(jobId, searchParameters);
		

		if (null == responseRojgarJob) {
			responseHamaraRojgar.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseHamaraRojgar.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
		} else {
			responseHamaraRojgar.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			responseHamaraRojgar.setContent(responseRojgarJob);
		}
		System.out.println("searchParameters ======== "+ searchParameters);
		return responseHamaraRojgar;
	}

	@PutMapping("/getusers")
	public @ResponseBody ResponseHamaraRojgar getUsers(
			@RequestBody RequestRojgarSearchParameter requestSearchParameter) {
		log.info("RequestRojgarUserSearchParameter::  {}", requestSearchParameter);
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseHamaraRojgarUser responseHamaraRojgarUser = serviceMember.getUsers(requestSearchParameter);
		responseHamaraRojgar.setContent(responseHamaraRojgarUser);
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(HttpStatus.OK.value()));
		responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		return responseHamaraRojgar;
	}

	@PutMapping("/campaigns")
	public @ResponseBody ResponseHamaraRojgar getCampaigns(
			@RequestBody RequestRojgarSearchParameter requestSearchParameter) {
		log.info("RequestRojgarSearchParameter::  {}", requestSearchParameter);
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseCampaign responseCampaign = serviceCampaign.getCampaign(requestSearchParameter);
		responseHamaraRojgar.setContent(responseCampaign);
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(HttpStatus.OK.value()));
		responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		return responseHamaraRojgar;
	}

	@PutMapping("/campaigns/member")
	public @ResponseBody ResponseHamaraRojgar getCampaignMembers(
			@RequestBody RequestRojgarSearchParameter requestSearchParameter) {
		/*
		 * log.info("RequestRojgarSearchParameter::  {}", requestSearchParameter);
		 * ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar(); //
		 * Need to modify this method to get memebers ResponseCampaign responseCampaign
		 * = serviceCampaign.getCampaignMembers(requestSearchParameter);
		 * responseHamaraRojgar.setContent(responseCampaign);
		 * responseHamaraRojgar.setResponseCode(util.buildResponseStatus(HttpStatus.OK.
		 * value())); responseHamaraRojgar.setResponseDescription(ServerConstants.
		 * SUCCESRESPONSEDESC); return responseHamaraRojgar;
		 */

		return getUsers(requestSearchParameter);
	}

	@PostMapping("/notification")
	public @ResponseBody ResponseHamaraRojgar postNotifications(
			@RequestBody RequestRojgarNotification requestRojgarNotification) {
		log.info("postNotifications:: {}", requestRojgarNotification);
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		serviceNotification.createNotification(requestRojgarNotification);
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(HttpStatus.OK.value()));
		responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		return responseHamaraRojgar;
	}

	/*
	 * @RequestMapping(value = "/getBusinessTypeList", method = RequestMethod.GET)
	 * public @ResponseBody Page<BusinessTypeMaster> getBusinessTypeList(Pageable
	 * pageable,@RequestParam String name) { Page<BusinessTypeMaster> businessTypes
	 * = jobSeekerService.getBusinessTypeList(pageable,name); return businessTypes;
	 * }
	 */

	/*
	 * @RequestMapping(value = "/updateInfluencerRating", method =
	 * RequestMethod.POST) public @ResponseBody ResponseEntity<ResponseDTO>
	 * updateInfluencerRating(@RequestBody RatingDTO ratingDTO) {
	 * reqLog.info("Got update Campaign Status Request for :{}",ratingDTO);
	 * ResponseDTO responseDTO = new ResponseDTO(); try { boolean result =
	 * influencerService.updateInfluencerRating(ratingDTO.getId(),
	 * ratingDTO.getRating()); if(result){
	 * responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
	 * responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
	 * }else{ responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
	 * responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC); } }
	 * catch (Exception e) { exceptionLog.error(e.getMessage(), e);
	 * e.printStackTrace(); } return new ResponseEntity<>(responseDTO,
	 * HttpStatus.OK); }
	 * 
	 * @RequestMapping(value = "/updateInfluencerPayout", method =
	 * RequestMethod.POST) public @ResponseBody ResponseEntity<ResponseDTO>
	 * updateInfluencerPayout(@RequestBody PayoutRangeDTO payoutRangeDTO) {
	 * reqLog.info("Got update Campaign Status Request for :{}",payoutRangeDTO);
	 * ResponseDTO responseDTO = new ResponseDTO(); try { boolean result =
	 * influencerService.updateInfluencerPayoutRange(payoutRangeDTO.getId(),
	 * payoutRangeDTO.getPayoutRange()); if(result){
	 * responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
	 * responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
	 * }else{ responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
	 * responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC); } }
	 * catch (Exception e) { exceptionLog.error(e.getMessage(), e);
	 * e.printStackTrace(); } return new ResponseEntity<>(responseDTO,
	 * HttpStatus.OK); }
	 * 
	 * @RequestMapping(value = "/updateInfluencerGrade", method =
	 * RequestMethod.POST) public @ResponseBody ResponseEntity<ResponseDTO>
	 * updateInfluencerGrade(@RequestBody PayoutRangeDTO gradeDTO) {
	 * reqLog.info("Got update Campaign Status Request for :{}",gradeDTO);
	 * ResponseDTO responseDTO = new ResponseDTO(); try { boolean result =
	 * influencerService.updateInfluencerGrade(gradeDTO.getId(),
	 * gradeDTO.getPayoutRange()); if(result){
	 * responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
	 * responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
	 * }else{ responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
	 * responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC); } }
	 * catch (Exception e) { exceptionLog.error(e.getMessage(), e);
	 * e.printStackTrace(); } return new ResponseEntity<>(responseDTO,
	 * HttpStatus.OK); }
	 * 
	 * @RequestMapping(value = "/updateInfBlockedStatus", method =
	 * RequestMethod.POST) public @ResponseBody ResponseDTO
	 * updateInfBlockedStatus(@RequestBody StatusDTO statusDTO) {
	 * reqLog.info("Got update blocked Status Request for :{}",statusDTO);
	 * ResponseDTO responseDTO = new ResponseDTO(); try { boolean result =
	 * influencerService.updateInfBlockedStatus(statusDTO); if(result){
	 * responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
	 * responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
	 * }else{ responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
	 * responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC); } }
	 * catch (Exception e) { exceptionLog.error(e.getMessage(), e);
	 * e.printStackTrace(); } return responseDTO; }
	 * 
	 * @RequestMapping(value = "/updateInfluencerBasicDetails", method =
	 * RequestMethod.POST) public @ResponseBody ResponseEntity<ResponseDTO>
	 * updateInfluencerBasicDetails(@RequestBody InfluencerDTO influencerDTO) {
	 * reqLog.info("Got update Influencer Request for :{}",influencerDTO);
	 * ResponseDTO responseDTO = new ResponseDTO(); try { boolean result =
	 * influencerService.updateInfluencerBasicDetails(influencerDTO); if(result){
	 * responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
	 * responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
	 * }else{ responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
	 * responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC); } }
	 * catch (Exception e) { exceptionLog.error(e.getMessage(), e);
	 * e.printStackTrace(); } return new ResponseEntity<>(responseDTO,
	 * HttpStatus.OK); }
	 */

}
