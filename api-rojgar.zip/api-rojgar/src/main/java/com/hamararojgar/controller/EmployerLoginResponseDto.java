package com.hamararojgar.controller;

import com.hamararojgar.dto.EmployerDto;
import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.User;

public class EmployerLoginResponseDto extends ResponseDTO{

	User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	Employer employer;

	public Employer getEmployer() {
		return employer;
	}

	public void setEmployer(Employer employer) {
		this.employer = employer;
	}
	
	
	private EmployerDto employerUpdate;

	public EmployerDto getEmployerUpdate() {
		return employerUpdate;
	}

	public void setEmployerUpdate(EmployerDto employerUpdate) {
		this.employerUpdate = employerUpdate;
	}
	
	
	
}
