package com.hamararojgar.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.NotificationDto;
import com.hamararojgar.dto.ResponseDTOBusinessType;
import com.hamararojgar.dto.ResponseNotification;
import com.hamararojgar.model.BusinessTypeMaster;
import com.hamararojgar.model.LocationListDto;
import com.hamararojgar.model.SkillListDto;
import com.hamararojgar.payload.request.RequestMasterUserRole;
import com.hamararojgar.payload.response.ResponseBuinsessTypes;
import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.payload.response.ResponseHamararojgarContent;
import com.hamararojgar.payload.response.ResponseLeadStageMaster;
import com.hamararojgar.payload.response.ResponseUserRole;
import com.hamararojgar.repo.LocationMasterRepo;
import com.hamararojgar.serviceimpl.MasterDataService;
import com.hamararojgar.util.Util;

@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/api-master")
public class ControllerAPIMasterData {

	private static final Logger log = LogManager.getLogger(ControllerAPIMasterData.class);
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	private MasterDataService masterDataService;

	@Autowired
	Util util;

	@Autowired
	private LocationMasterRepo locationMasterRepo;

	@RequestMapping(value = "/getSkills", method = RequestMethod.GET)
	public @ResponseBody SkillListDto getSkills() {
		SkillListDto skillListDto = new SkillListDto();
		try {
			//skillListDto.setSkillList(masterDataService.getAllSkills());
			skillListDto.setSkillList(masterDataService.getAllSkillsSortByTitle());
			skillListDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			skillListDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			skillListDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			skillListDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getSkills Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return skillListDto;
	}

	@RequestMapping(value = "/getNotificationList", method = RequestMethod.GET)
	public @ResponseBody NotificationDto getNotification(@RequestParam Map<String, String> allRequestParams) {
		NotificationDto notificationDto = new NotificationDto();
		try {
			List<ResponseNotification> notifications = masterDataService.getNotifications(allRequestParams);
			if (null == notifications) {
				notifications = new ArrayList<ResponseNotification>();
			}
			notificationDto.setNotificationList(notifications);
			notificationDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			notificationDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (

		Exception e) {
			notificationDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			notificationDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getNotificationList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return notificationDto;
	}

	@RequestMapping(value = "/getBusinessTypes", method = RequestMethod.GET)
	public @ResponseBody ResponseHamaraRojgar getBusinessTypes() {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		List<BusinessTypeMaster> businessTypeMasters = masterDataService.getBusinessTypes(Sort.by("title"));
		if (null == businessTypeMasters || businessTypeMasters.isEmpty()) {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
			responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
			return responseHamaraRojgar;
		}
		List<ResponseDTOBusinessType> businessTypes = new ArrayList<ResponseDTOBusinessType>();
		for (BusinessTypeMaster businessTypeMaster : businessTypeMasters) {
			ResponseDTOBusinessType responseDTOBusinessType = new ResponseDTOBusinessType();
			responseDTOBusinessType.setTitle(businessTypeMaster.getTitle());
			responseDTOBusinessType.setId(businessTypeMaster.getId());
			businessTypes.add(responseDTOBusinessType);
		}
		ResponseBuinsessTypes responseBuinsessTypes = new ResponseBuinsessTypes();
		responseBuinsessTypes.setBusinessTypes(businessTypes);
		httpStatusValue = HttpStatus.OK.value();
		responseHamaraRojgar.setContent(responseBuinsessTypes);
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}

	@GetMapping("/getLocations")
	public @ResponseBody LocationListDto getLocations() {
		LocationListDto locationListDto = new LocationListDto();
		try {
			//locationListDto.setLocationList(locationMasterRepo.findAll());
			locationListDto.setLocationList(locationMasterRepo.findAll(Sort.by("title").ascending()));
			locationListDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			locationListDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			locationListDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			locationListDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getLocations Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return locationListDto;
	}

	@GetMapping("/leadstages")
	public @ResponseBody ResponseHamaraRojgar getLeadStages(@RequestParam(required = false) Integer page,
			@RequestParam(required = false) Integer size, @RequestParam(required = false) String  userRole) {
		log.info("User Role:: "+ userRole);
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		Pageable paging = null;
		if (null != size && size >= 1) {
			if (null == page || page < 0) {
				page = 0;
			}
			paging = PageRequest.of(page, size);
		}
		ResponseLeadStageMaster responseLeadStageMaster = masterDataService.getLeadStages(paging, userRole);
		if (null != responseLeadStageMaster) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(responseLeadStageMaster);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}

	@PostMapping("/user-role")
	public @ResponseBody ResponseHamaraRojgar createMasterUserRole(
			@RequestBody RequestMasterUserRole requestMasterUserRole) {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		try {
			ResponseUserRole responseUserRole = masterDataService.createMasterUserRole(requestMasterUserRole);
			if (null != responseUserRole) {
				httpStatusValue = HttpStatus.OK.value();
				responseHamaraRojgar.setContent(responseUserRole);
			}
		} catch (Exception exception) {
			// httpStatusValue = HttpStatus.EXPECTATION_FAILED.value();
			throw exception;
		}

		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}

	@GetMapping("/user-role")
	public @ResponseBody ResponseHamaraRojgar getUserRoles(@RequestParam(required = false) Integer page,
			@RequestParam(required = false) Integer size) {
		log.info("Called api-users  getUserRoles");
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		Pageable paging = null;
		if (null != size && size >= 1) {
			if (null == page || page < 0) {
				page = 0;
			}
			paging = PageRequest.of(page, size);
		}
		ResponseHamararojgarContent content = masterDataService.getUserRoles(paging);
		if (null != content) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(content);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}

	@GetMapping("/leadstatus")
	public @ResponseBody ResponseHamaraRojgar getLeadStatus(@RequestParam(required = false) Integer page,
			@RequestParam(required = false) Integer size, @RequestParam(required = false) String userRole) {

		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		
		Pageable paging = null;
		if (null != size && size >= 1) {
			if (null == page || page < 0) {
				page = 0;
			}
			paging = PageRequest.of(page, size);
		}
		ResponseHamararojgarContent content = masterDataService.getLeadStatus(paging, userRole);
		if (null != content) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(content);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
}