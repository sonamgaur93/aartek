package com.hamararojgar.controller;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.RequestDTOBusinessType;
import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.dto.ResponseDTOBusinessType;
import com.hamararojgar.model.BusinessTypeMaster;
import com.hamararojgar.model.LeadStageMaster;
import com.hamararojgar.model.LocationMaster;
import com.hamararojgar.model.SkillMaster;
import com.hamararojgar.payload.request.RequestFeature;
import com.hamararojgar.payload.request.RequestMasterUserRole;
import com.hamararojgar.payload.response.ResponseBuinsessTypes;
import com.hamararojgar.payload.response.ResponseFeature;
import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.payload.response.ResponseHamararojgarContent;
import com.hamararojgar.payload.response.ResponseUserRole;
import com.hamararojgar.repo.LeadStageMasterRepo;
import com.hamararojgar.repo.LocationMasterRepo;
import com.hamararojgar.repo.SkillMasterRepo;
import com.hamararojgar.serviceimpl.MasterDataService;
import com.hamararojgar.util.Util;

@Controller
@CrossOrigin(origins = "*")
public class MasterDataContoller {

	private static final Logger log = LogManager.getLogger(MasterDataContoller.class);
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");
	private static final Logger reqLog = LogManager.getLogger("request-log");

	@Autowired
	SkillMasterRepo skillMasterRepo;

	@Autowired
	LeadStageMasterRepo leadStageMasterRepo;

	@Autowired
	MasterDataService masterDataService;

	@Autowired
	private Util util;
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	LocationMasterRepo locationMasterRepo;

	@RequestMapping(value = "/getLeadStagesAdmin/", method = RequestMethod.POST)
	public @ResponseBody List<LeadStageMaster> getLeadStagesAdmin() {
		return leadStageMasterRepo.findAll();
	}

	@RequestMapping(value = "/getBusinessTypeList", method = RequestMethod.GET)
	public @ResponseBody Page<BusinessTypeMaster> getAllBusinessTypes(@RequestParam(required = false) String name,
			@RequestParam(required = false) Integer page, @RequestParam(required = false) Integer size,
			@RequestParam(required = false) boolean isSorted) {

		Pageable pageable = null;
		if (null != size && size >= 1) {
			if (null == page || page < 0) {
				page = 0;
			}

		} else {
			size = 1000;
			page = 0;
		}

		pageable = PageRequest.of(page, size);
		if (null == name) {
			name = "";
		}

		Page<BusinessTypeMaster> businessTypes = masterDataService.getBusinessTypeList(pageable, name, isSorted);
		return businessTypes;
	}

	@PostMapping("/user-role")
	public @ResponseBody ResponseHamaraRojgar createMasterUserRole(
			@RequestBody RequestMasterUserRole requestMasterUserRole) {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		try {
			ResponseUserRole responseUserRole = masterDataService.createMasterUserRole(requestMasterUserRole);
			if (null != responseUserRole) {
				httpStatusValue = HttpStatus.OK.value();
				responseHamaraRojgar.setContent(responseUserRole);
			}
		} catch (Exception exception) {
			// httpStatusValue = HttpStatus.EXPECTATION_FAILED.value();
			throw exception;
		}

		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}

	@GetMapping("/user-role")
	public @ResponseBody ResponseHamaraRojgar getUserRoles(@RequestParam(required = false) Integer page,
			@RequestParam(required = false) Integer size) {
		log.info("Called api-users  getUserRoles");
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		Pageable paging = null;
		if (null != size && size >= 1) {
			if (null == page || page < 0) {
				page = 0;
			}
			paging = PageRequest.of(page, size);
		}
		ResponseHamararojgarContent content = masterDataService.getUserRoles(paging);
		if (null != content) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(content);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	@GetMapping("/user-role/{roleCode}")
	public @ResponseBody ResponseHamaraRojgar getUserRole(@PathVariable(name = "roleCode") String roleCode) {
		log.info("Called user-role/{roleCode}");
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseHamararojgarContent content = masterDataService.getUserRoleByRoleCode(roleCode);
		if (null != content) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(content);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	@PutMapping("/user-role")
	public @ResponseBody ResponseHamaraRojgar updateMasterUserRole(
			@RequestBody RequestMasterUserRole requestMasterUserRole) {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		try {
			ResponseUserRole responseUserRole = masterDataService.updatesMasterUserRole(requestMasterUserRole);
			if (null != responseUserRole) {
				httpStatusValue = HttpStatus.OK.value();
				responseHamaraRojgar.setContent(responseUserRole);
			}
		} catch (Exception exception) {
			// httpStatusValue = HttpStatus.EXPECTATION_FAILED.value();
			throw exception;
		}

		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	@PostMapping("/businessTypes")
	public @ResponseBody ResponseHamaraRojgar addBusinessTypes(@RequestBody RequestDTOBusinessType requestDTOBusinessType) {
		log.info("businessTypes called  " );
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseDTOBusinessType responseDTOBusinessType = null; 
		
		try {
			responseDTOBusinessType = masterDataService.createOrUpdateBusinessType(requestDTOBusinessType);
		} catch (Exception exception) {
			log.info("Exception in addIndustry Method : " + exception.getMessage());
			exceptionLog.error(exception.getMessage(), exception);
			responseHamaraRojgar.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			return responseHamaraRojgar;
		}
		
		if(null == responseDTOBusinessType) {
			responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
			return responseHamaraRojgar;
		}
		ResponseBuinsessTypes responseBuinsessTypes = new ResponseBuinsessTypes();
		responseBuinsessTypes.setBusinessType(responseDTOBusinessType);
		httpStatusValue = HttpStatus.OK.value();
		responseHamaraRojgar.setContent(responseBuinsessTypes);
		return responseHamaraRojgar;
	}
	
	@GetMapping("/businessType/{id}")
	public @ResponseBody ResponseHamaraRojgar getBusinessType(@PathVariable(value = "id") Long businessTypeId) {
		log.info("businessTypes called  " );
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseDTOBusinessType responseDTOBusinessType = null; 
		
		try {
			responseDTOBusinessType = masterDataService.getBusinessType(businessTypeId);
		} catch (Exception exception) {
			log.info("Exception in addIndustry Method : " + exception.getMessage());
			exceptionLog.error(exception.getMessage(), exception);
			responseHamaraRojgar.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			return responseHamaraRojgar;
		}
		
		if(null == responseDTOBusinessType) {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
			responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
			return responseHamaraRojgar;
		}
		ResponseBuinsessTypes responseBuinsessTypes = new ResponseBuinsessTypes();
		responseBuinsessTypes.setBusinessType(responseDTOBusinessType);
		httpStatusValue = HttpStatus.OK.value();
		responseHamaraRojgar.setContent(responseBuinsessTypes);
		return responseHamaraRojgar;
	}
	
	@PutMapping("/businessTypes")
	public @ResponseBody ResponseHamaraRojgar updateBusinessTypes(@RequestBody RequestDTOBusinessType requestDTOBusinessType) {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseDTOBusinessType responseDTOBusinessType = null; 
		BusinessTypeMaster businessTypeMaster = masterDataService.getBusinessTypeMaster(requestDTOBusinessType.getId());
		if(null == businessTypeMaster ) {
			responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
			return responseHamaraRojgar;
		}
		try {
			responseDTOBusinessType = masterDataService.createOrUpdateBusinessType(requestDTOBusinessType);
		} catch (Exception exception) {
			log.info("Exception in addIndustry Method : " + exception.getMessage());
			exceptionLog.error(exception.getMessage(), exception);
			responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
			return responseHamaraRojgar;
		}
		if(null == responseDTOBusinessType) {
			responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
			return responseHamaraRojgar;
		}
		ResponseBuinsessTypes responseBuinsessTypes = new ResponseBuinsessTypes();
		responseBuinsessTypes.setBusinessType(responseDTOBusinessType);
		httpStatusValue = HttpStatus.OK.value();
		responseHamaraRojgar.setContent(responseBuinsessTypes);
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	@RequestMapping(value = "/getLocations/", method = RequestMethod.GET)
	public @ResponseBody Page<LocationMaster> getLocations(@RequestParam String search, Pageable pageable) {
		reqLog.info("Got Get Industries Request with search : {}", search);
		Pageable sortedpage = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(),
				Sort.by("id").descending());
		Page<LocationMaster> industryList = masterDataService.getLocations( search, sortedpage);
		return industryList;
	}
	
	@RequestMapping(value = "/getSkills/", method = RequestMethod.GET)
	public @ResponseBody Page<SkillMaster> getSkills(@RequestParam String search, Pageable pageable) {
		reqLog.info("Got Get Industries Request with search : {}", search);
		Pageable sortedpage = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(),
				Sort.by("id").descending());
		Page<SkillMaster> industryList = masterDataService.getSkills(search, sortedpage);
		return industryList;
	}
	
	@RequestMapping(value = "/addSkill", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<ResponseDTO> addIndustry(@Valid @RequestBody SkillMaster industryDTO,
			HttpServletRequest request, Errors errors) {
		reqLog.info("Got Add Industry Request for : {}", industryDTO);
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			if (industryDTO.getId() != null) {
				Optional<SkillMaster> skillMaster = skillMasterRepo.findById(industryDTO.getId());
				if (skillMaster.isPresent()) {
					SkillMaster sm = skillMaster.get();
					sm.setUpdateDateTime(Instant.now());
					if (sm.getTitle().equalsIgnoreCase(industryDTO.getTitle())) {
						int count = jdbcTemplate.queryForObject(
								"SELECT count(*) FROM skill_master where title='" + industryDTO.getTitle() + "' ;",
								Integer.class);
						if (count == 1) {
							sm.setTitle(industryDTO.getTitle());
							skillMasterRepo.save(sm);
							responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
							responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
						} else {
							responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
							responseDTO.setResponseDescription("Skill Already Exists.");
						}
					} else {
						int count = jdbcTemplate.queryForObject(
								"SELECT count(*) FROM skill_master where title='" + industryDTO.getTitle() + "' ;",
								Integer.class);
						if (count == 0) {
							sm.setTitle(industryDTO.getTitle());
							skillMasterRepo.save(sm);
							responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
							responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
						} else {
							responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
							responseDTO.setResponseDescription("Skill Already Exists.");
						}
					}
				} else {
					int count = jdbcTemplate.queryForObject(
							"SELECT count(*) FROM skill_master where title='" + industryDTO.getTitle() + "' ;",
							Integer.class);
					if (count == 0) {
						SkillMaster sm = new SkillMaster();
						sm.setTitle(industryDTO.getTitle());
						sm.setEntryDateTime(Instant.now());
						sm.setUpdateDateTime(sm.getEntryDateTime());
						skillMasterRepo.save(sm);
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
					} else {
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription("Skill Already Exists.");
					}
				}
			} else {
				int count = jdbcTemplate.queryForObject(
						"SELECT count(*) FROM skill_master where title='" + industryDTO.getTitle() + "' ;",
						Integer.class);
				if (count == 0) {
					SkillMaster sm = new SkillMaster();
					sm.setTitle(industryDTO.getTitle());
					sm.setEntryDateTime(Instant.now());
					sm.setUpdateDateTime(sm.getEntryDateTime());
					skillMasterRepo.save(sm);
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				} else {
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription("Skill Already Exists.");
				}
			}
		} catch (Exception e) {
			log.info("Exception in addIndustry Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/addLocation", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<ResponseDTO> addLocation(@Valid @RequestBody SkillMaster industryDTO,
			HttpServletRequest request, Errors errors) {
		reqLog.info("Got Add Industry Request for : {}", industryDTO);
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			if (industryDTO.getId() != null) {
				Optional<LocationMaster> skillMaster = locationMasterRepo.findById(industryDTO.getId());
				if (skillMaster.isPresent()) {
					LocationMaster sm = skillMaster.get();
					sm.setUpdateDateTime(Instant.now());
					sm.setTitle(industryDTO.getTitle());
					locationMasterRepo.save(sm);
				} else {
					LocationMaster sm = new LocationMaster();
					sm.setTitle(industryDTO.getTitle());
					sm.setEntryDateTime(Instant.now());
					sm.setUpdateDateTime(sm.getEntryDateTime());
					locationMasterRepo.save(sm);
				}
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				LocationMaster sm = new LocationMaster();
				sm.setTitle(industryDTO.getTitle());
				sm.setEntryDateTime(Instant.now());
				sm.setUpdateDateTime(sm.getEntryDateTime());
				locationMasterRepo.save(sm);
			}
			responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			log.info("Exception in addIndustry Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}
	
	
	@PostMapping("/feature")
	public @ResponseBody ResponseHamaraRojgar createFeature(@RequestBody RequestFeature requestFeature) {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseFeature responseFeature =  null;
		
		try {
			responseFeature = masterDataService.createFeature(requestFeature);
		} catch (Exception exception) {
			log.info("Exception in createFeature Method : " + exception.getMessage());
			exceptionLog.error(exception.getMessage(), exception);
			responseHamaraRojgar.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			return responseHamaraRojgar;
		}
		
		if(null == responseFeature) {
			responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
			return responseHamaraRojgar;
		}
		httpStatusValue = HttpStatus.OK.value();
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		responseHamaraRojgar.setContent(responseFeature);
		return responseHamaraRojgar;
	}
	
	@GetMapping("/features")
	public @ResponseBody ResponseHamaraRojgar getFeatures(@RequestParam Map<String, String> searchParam) {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseFeature responseFeature =  null;
		
		try {
			responseFeature = masterDataService.getFeatures(searchParam);
		} catch (Exception exception) {
			log.info("Exception in addIndustry Method : " + exception.getMessage());
			exceptionLog.error(exception.getMessage(), exception);
			responseHamaraRojgar.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			return responseHamaraRojgar;
		}
		
		if(null == responseFeature) {
			responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
			return responseHamaraRojgar;
		}
		httpStatusValue = HttpStatus.OK.value();
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		responseHamaraRojgar.setContent(responseFeature);
		return responseHamaraRojgar;
	}
	
	@GetMapping("/feature/{featureCode}")
	public @ResponseBody ResponseHamaraRojgar getFeature(@PathVariable (name="featureCode") String featureCode) {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseFeature responseFeature =  null;
		
		try {
			responseFeature = masterDataService.getFeature(featureCode);
		} catch (Exception exception) {
			log.info("Exception in addIndustry Method : " + exception.getMessage());
			exceptionLog.error(exception.getMessage(), exception);
			responseHamaraRojgar.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			return responseHamaraRojgar;
		}
		
		if(null == responseFeature) {
			responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
			return responseHamaraRojgar;
		}
		httpStatusValue = HttpStatus.OK.value();
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		responseHamaraRojgar.setContent(responseFeature);
		return responseHamaraRojgar;
	}
}