package com.hamararojgar.controller;

import java.util.List;

import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.model.AppliedJobChatMaster;

public class ChatMessagesDto extends ResponseDTO{

	List<AppliedJobChatMaster> chatList;

	public List<AppliedJobChatMaster> getChatList() {
		return chatList;
	}

	public void setChatList(List<AppliedJobChatMaster> chatList) {
		this.chatList = chatList;
	}
	
}
