package com.hamararojgar.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.EmployerLoginRequestDto;
import com.hamararojgar.dto.LeadDto;
import com.hamararojgar.dto.LeadListReqDto;
import com.hamararojgar.dto.LeadListResponseDto;
import com.hamararojgar.dto.PublishMultiLeadRequestDto;
import com.hamararojgar.dto.PublishMultiLeadResponseDto;
import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.model.CommentMaster;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.JobSeekerSkillMap;
import com.hamararojgar.model.LeadMaster;
import com.hamararojgar.model.LeadSkillMap;
import com.hamararojgar.model.LeadStageMaster;
import com.hamararojgar.model.ResponseDto;
import com.hamararojgar.model.SkillMaster;
import com.hamararojgar.model.User;
import com.hamararojgar.repo.CommentMasterRepo;
import com.hamararojgar.repo.EmployerRepo;
import com.hamararojgar.repo.JobSeekerMasterRepo;
import com.hamararojgar.repo.JobSeekerSkillMapRepo;
import com.hamararojgar.repo.LeadMasterRepo;
import com.hamararojgar.repo.LeadQueryMapper;
import com.hamararojgar.repo.LeadSkillMapRepo;
import com.hamararojgar.repo.LeadStageMasterRepo;
import com.hamararojgar.repo.SkillMasterRepo;
import com.hamararojgar.repo.UserRepo;
import com.hamararojgar.serviceimpl.ServiceLeadMaster;
import com.hamararojgar.serviceimpl.ServiceMappingMemberFCM;
import com.hamararojgar.util.RojgarConstantProperties;
import com.hamararojgar.util.Util;

@Controller
@CrossOrigin(origins = "*")
public class LeadController {

	private static final Logger log = LogManager.getLogger(LeadController.class);
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");
	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	@Autowired
	UserRepo userRepo;

	@Autowired
	private EmployerRepo employerRepo;
	@Autowired
	private JobSeekerMasterRepo jobSeekerMasterRepo;
	@Autowired
	private JobSeekerSkillMapRepo jobSeekerSkillMapRepo;

	@Autowired
	private LeadMasterRepo leadMasterRepo;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private LeadSkillMapRepo leadSkillMapRepo;

	@Autowired
	SkillMasterRepo skillMasterRepo;
	@Autowired
	LeadStageMasterRepo leadStageMasterRepo;

	@Autowired
	RojgarConstantProperties constantProperties;

	@Autowired
	ServiceLeadMaster serviceLeadMaster;

	@Autowired
	Util util;

	@Autowired
	ServiceMappingMemberFCM serviceMappingMemberFCM;

	@RequestMapping(value = "/api/leadUserLoginCheck", method = RequestMethod.POST)
	public @ResponseBody EmployerLoginResponseDto leadUserLoginCheck(@RequestBody EmployerLoginRequestDto requestDto) {
		EmployerLoginResponseDto responseDTO = new EmployerLoginResponseDto();
		try {
			User user = null;
			// user = userRepo.findByEmail(requestDto.getEmail().toLowerCase());
			user = userRepo.findByEmailAndRole(requestDto.getEmail().toLowerCase(), "FLDA");
			if (null != user) {
				if (util.validateUserPassword(requestDto.getPassword(), user.getPassword())) {
					if ("ACTIVE".equalsIgnoreCase(user.getStatus())) {
						if (null != requestDto.getDeviceToken()
								&& !"".equalsIgnoreCase(requestDto.getDeviceToken().trim())) {
							serviceMappingMemberFCM.createMappingMemberFCM("ADM", String.valueOf(user.getId()),
									requestDto.getDeviceToken());
						}
						responseDTO.setUser(user);
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
					} else {
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription("Account is InActive.");
					}
				} else {
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription("Invalid Password.");
				}
			} else {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription("Invalid Email Address.");
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in leadUserLoginCheck Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/api/addLead", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<ResponseDto> addLead(@ModelAttribute LeadDto dto, HttpServletRequest request,
			Errors errors) {
		ResponseDto responseDTO = new ResponseDto();
		try {
			serviceLeadMaster.createLeadMaster(dto);
			responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in addLead Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/api/getLeadDetails/{id}", method = RequestMethod.GET)
	public @ResponseBody LeadDto getLeadDetails(@PathVariable Long id) {
		LeadDto leadMaster = new LeadDto();
		try {
			Optional<LeadMaster> lead = leadMasterRepo.findById(id);
			if (lead.isPresent()) {
				LeadMaster dto = lead.get();
				leadMaster.setType(dto.getType());
				leadMaster.setAgent_id(dto.getAgent_id());
				leadMaster.setAgent_name(dto.getAgent_name());
				leadMaster.setCreate_date(new Date());
				DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
				String strDate = dateFormat.format(dto.getCreate_date());
				leadMaster.setDate(strDate);
				leadMaster.setPriority(dto.getPriority());
				leadMaster.setStatus(dto.getStatus());
				leadMaster.setStage(dto.getStage());
				leadMaster.setName(dto.getName());
				leadMaster.setEmail(dto.getEmail());
				leadMaster.setPhone(dto.getPhone());
				leadMaster.setAddress(dto.getAddress());
				leadMaster.setNote(dto.getNote());
				leadMaster.setLattitude(dto.getLattitude());
				leadMaster.setLongitude(dto.getLongitude());
				leadMaster.setProfile_pic_url(dto.getProfile_pic_url());
				leadMaster.setRecording_url(dto.getRecording_url());
				if (dto.getType().equalsIgnoreCase("Employer")) {
					leadMaster.setCompany_name(dto.getCompany_name());
					leadMaster.setBussiness_type(dto.getBussiness_type());
					leadMaster.setGst(dto.getGst());
					leadMaster.setPan(dto.getPan());
				} else {

					leadMaster.setAvailability(dto.getAvailability());
					leadMaster.setExpected_compensation(dto.getExpected_compensation());
					leadMaster.setExpected_salary(dto.getExpected_salary());
					leadMaster.setExperience(dto.getExperience());
					leadMaster.setSkills(dto.getSkills());
					List<SkillMaster> skillList = new ArrayList<SkillMaster>();
					List<LeadSkillMap> skillMap = leadSkillMapRepo.findByLeadId(dto.getId().intValue());
					for (LeadSkillMap skill : skillMap) {
						Optional<SkillMaster> master = skillMasterRepo.findById((long) skill.getSkillId());
						if (master.isPresent()) {
							skillList.add(master.get());
						}
					}
					leadMaster.setSkillList(skillList);

				}

				leadMaster.setCampaignCode(dto.getCampaignCode());
				leadMaster.setCustomerId(dto.getCustomerId());
			}
		} catch (Exception e) {
			log.info("Exception in getLeadDetails Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return leadMaster;
	}

	@RequestMapping(value = "/api/getLeadList", method = RequestMethod.POST)
	public @ResponseBody LeadListResponseDto getLeadList(@RequestBody LeadListReqDto dto) {
		LeadListResponseDto leadListResponseDto = new LeadListResponseDto();

		try {
			List<LeadMaster> leadList = null;
			if (dto.getType().equalsIgnoreCase("All")) {
				leadList = leadMasterRepo.findByAgentIdDate(dto.getAgentId(), dto.getFromDate(), dto.getToDate());
			} else {
				leadList = leadMasterRepo.findByAgentIdDateAndType(dto.getAgentId(), dto.getFromDate(), dto.getToDate(),
						dto.getType());
			}

			if (null != leadList) {
				if (null == dto.getCampaignCode() || "-1".equalsIgnoreCase(dto.getCampaignCode())) {
					leadListResponseDto.setLeadList(leadList);
				} else {
					List<LeadMaster> updateList = new ArrayList<LeadMaster>();
					// Set<String> campaignCodes = dto.getCampaignCodes();
					for (LeadMaster leadMaster : leadList) {
						if (dto.getCampaignCode().equalsIgnoreCase(leadMaster.getCampaignCode())) {
							updateList.add(leadMaster);
						}

					}

					leadListResponseDto.setLeadList(updateList);
				}

			}

			leadListResponseDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			leadListResponseDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);

		} catch (Exception e) {
			leadListResponseDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			leadListResponseDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return leadListResponseDto;
	}

	@RequestMapping(value = "/api/getLeadList", method = RequestMethod.GET)
	public @ResponseBody Page<LeadDto> getLeadList(Pageable pageable, @RequestParam String agentname,
			@RequestParam String date, @RequestParam String priority, @RequestParam String type,
			@RequestParam String status, @RequestParam String stage, @RequestParam(required = false) String campaign,
			@RequestParam(required = false) String userRole, @RequestParam(required = false) String memberId) {
		log.info("called getLeadList");
		List<LeadDto> data = new ArrayList<>();
		String query = "";
		String star = "*";
		String countStar = "count(*)";
		String condition = "";
		if (!status.equalsIgnoreCase("All")) {
			condition = condition + " where status = '" + status + "'";
		}
		if (!agentname.equalsIgnoreCase("")) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and agent_name like '%" + agentname + "%'";
			} else {
				condition = condition + " where agent_name like '%" + agentname + "%'";
			}

		}
		if (!date.equalsIgnoreCase("")) {
			String dateArr[] = date.split("~");
			String startDate = dateArr[0];
			String endDate = dateArr[1];
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and date between '" + startDate + "' and '" + endDate + "' ";
			} else {
				condition = condition + " where date between '" + startDate + "' and '" + endDate + "' ";
			}
		}
		if (!priority.equalsIgnoreCase("All")) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and priority = '" + priority + "'";
			} else {
				condition = condition + " where priority = '" + priority + "'";
			}
		}
		if (!type.equalsIgnoreCase("All")) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and type = '" + type + "'";
			} else {
				condition = condition + " where type = '" + type + "'";
			}
		}
		if (!stage.equalsIgnoreCase("All")) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and stage = '" + stage + "'";
			} else {
				condition = condition + " where stage = '" + stage + "'";
			}
		}

		String requestCampaigCode = ((null == campaign || "-1".equalsIgnoreCase(campaign) || campaign.isEmpty()) ? "ALL"
				: campaign);

		if (!"ALL".equalsIgnoreCase(requestCampaigCode)) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and campaign_code = '" + requestCampaigCode + "'";
			} else {
				condition = condition + " where campaign_code = '" + requestCampaigCode + "'";
			}
		}

		if ("FLDA".equalsIgnoreCase(userRole)) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and agent_id=" + memberId;
			} else {
				condition = condition + " where agent_id=" + memberId;
			}
		}

		if (pageable.getPageNumber() == 0) {
			query = "SELECT " + star + " from lead_master " + condition + "  order by id desc limit  "
					+ pageable.getPageSize() + ";";

		} else {
			query = "SELECT " + star + " from lead_master " + condition + "  order by id desc limit  "
					+ pageable.getPageSize() + "  offset " + pageable.getPageNumber() * pageable.getPageSize() + ";";

		}

		int count = jdbcTemplate.queryForObject("SELECT " + countStar + " FROM lead_master " + condition + "",
				Integer.class);
		data = jdbcTemplate.query(query, new LeadQueryMapper());
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		for (LeadDto lm : data) {
			String strDate = dateFormat.format(lm.getCreate_date());
			lm.setDate(strDate);
		}

		return new PageImpl<LeadDto>(data, pageable, count);
	}

	@RequestMapping(value = "/getLeadListAdmin", method = RequestMethod.GET)
	public @ResponseBody Page<LeadDto> getLeadListAdmin(Pageable pageable, @RequestParam String agentname,
			@RequestParam String date, @RequestParam String priority, @RequestParam String type,
			@RequestParam String status, @RequestParam String stage, @RequestParam(required = false) String campaign) {

		List<LeadDto> data = new ArrayList<>();
		String query = "";
		String star = "*";
		String countStar = "count(*)";
		String condition = "";
		if (!status.equalsIgnoreCase("All")) {
			condition = condition + " where status = '" + status + "'";
		}
		if (!agentname.equalsIgnoreCase("")) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and agent_name like '%" + agentname + "%'";
			} else {
				condition = condition + " where agent_name like '%" + agentname + "%'";
			}

		}
		if (!date.equalsIgnoreCase("")) {
			String dateArr[] = date.split("~");
			String startDate = dateArr[0];
			String endDate = dateArr[1];
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and date between '" + startDate + "' and '" + endDate + "' ";
			} else {
				condition = condition + " where date between '" + startDate + "' and '" + endDate + "' ";
			}
		}
		if (!priority.equalsIgnoreCase("All")) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and priority = '" + priority + "'";
			} else {
				condition = condition + " where priority = '" + priority + "'";
			}
		}
		if (!type.equalsIgnoreCase("All")) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and type = '" + type + "'";
			} else {
				condition = condition + " where type = '" + type + "'";
			}
		}
		if (!stage.equalsIgnoreCase("All")) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and stage = '" + stage + "'";
			} else {
				condition = condition + " where stage = '" + stage + "'";
			}
		}

		String requestCampaigCode = ((null == campaign || "-1".equalsIgnoreCase(campaign) || campaign.isEmpty()) ? "ALL"
				: campaign);
		log.info("requestCampaigCode:: " + requestCampaigCode);
		if (!"ALL".equalsIgnoreCase(requestCampaigCode)) {
			if (!condition.equalsIgnoreCase("")) {
				condition = condition + " and campaign_code = '" + requestCampaigCode + "'";
			} else {
				condition = condition + " where campaign_code = '" + requestCampaigCode + "'";
			}
		}

		if (pageable.getPageNumber() == 0) {
			query = "SELECT " + star + " from lead_master " + condition + "  order by id desc limit  "
					+ pageable.getPageSize() + ";";

		} else {
			query = "SELECT " + star + " from lead_master " + condition + "  order by id desc limit  "
					+ pageable.getPageSize() + "  offset " + pageable.getPageNumber() * pageable.getPageSize() + ";";

		}
		log.info(query);
		int count = jdbcTemplate.queryForObject("SELECT " + countStar + " FROM lead_master " + condition + "",
				Integer.class);
		data = jdbcTemplate.query(query, new LeadQueryMapper());
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		for (LeadDto lm : data) {
			String strDate = dateFormat.format(lm.getCreate_date());
			lm.setDate(strDate);
		}
		return new PageImpl<LeadDto>(data, pageable, count);
	}

	@Autowired
	private CommentMasterRepo commentMasterRepo;

	@RequestMapping(value = "/addComment", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<ResponseDTO> addNotification(@RequestBody CommentMaster master,
			HttpServletRequest request, Errors errors) {
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			Optional<LeadMaster> lead = leadMasterRepo.findById((long) master.getLeadId());
			if (lead.isPresent()) {
				LeadMaster leadMaster = lead.get();
				DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
				CommentMaster commentMaster = new CommentMaster();
				commentMaster.setLeadId(master.getLeadId());
				commentMaster.setComment(master.getComment());
				commentMaster.setStage(leadMaster.getStage());
				String dateTime = dateFormat.format(new Date());
				commentMaster.setDateTime(dateTime);
				commentMasterRepo.save(commentMaster);
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			log.info("Exception in addComment Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/retrieveAllComments", method = RequestMethod.GET)
	public @ResponseBody Page<CommentMaster> retrieveAllComments(Pageable pageable, @RequestParam int id) {
		Pageable sortedByIdDesc = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(),
				Sort.by("id").descending());
		return commentMasterRepo.findAllByLeadId(id, sortedByIdDesc);
	}

	@RequestMapping(value = "/getLeadDetailsById/{id}", method = RequestMethod.GET)
	public @ResponseBody LeadDto getLeadDetailsById(@PathVariable Long id) {
		LeadDto leadMaster = new LeadDto();
		try {
			Optional<LeadMaster> lead = leadMasterRepo.findById(id);
			if (lead.isPresent()) {
				LeadMaster dto = lead.get();
				leadMaster.setType(dto.getType());
				leadMaster.setAgent_id(dto.getAgent_id());
				leadMaster.setAgent_name(dto.getAgent_name());
				leadMaster.setCreate_date(new Date());
				DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
				String strDate = dateFormat.format(dto.getCreate_date());
				leadMaster.setDate(strDate);
				leadMaster.setPriority(dto.getPriority());
				leadMaster.setStatus(dto.getStatus());
				leadMaster.setStage(dto.getStage());
				leadMaster.setName(dto.getName());
				leadMaster.setEmail(dto.getEmail());
				leadMaster.setPhone(dto.getPhone());
				leadMaster.setAddress(dto.getAddress());
				leadMaster.setNote(dto.getNote());
				leadMaster.setLattitude(dto.getLattitude());
				leadMaster.setLongitude(dto.getLongitude());
				leadMaster.setProfile_pic_url(dto.getProfile_pic_url());
				leadMaster.setRecording_url(dto.getRecording_url());
				leadMaster.setCustomerId(dto.getCustomerId());
				if (dto.getType().equalsIgnoreCase("Employer")) {
					leadMaster.setCompany_name(dto.getCompany_name());
					leadMaster.setBussiness_type(dto.getBussiness_type());
					leadMaster.setGst(dto.getGst());
					leadMaster.setPan(dto.getPan());
				} else {

					leadMaster.setAvailability(dto.getAvailability());
					leadMaster.setExpected_compensation(dto.getExpected_compensation());
					leadMaster.setExpected_salary(dto.getExpected_salary());
					leadMaster.setExperience(dto.getExperience());
					leadMaster.setSkills(dto.getSkills());
					List<SkillMaster> skillList = new ArrayList<SkillMaster>();
					List<LeadSkillMap> skillMap = leadSkillMapRepo.findByLeadId(dto.getId().intValue());
					for (LeadSkillMap skill : skillMap) {
						Optional<SkillMaster> master = skillMasterRepo.findById((long) skill.getSkillId());
						if (master.isPresent()) {
							skillList.add(master.get());
						}
					}
					leadMaster.setSkillList(skillList);

				}

			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return leadMaster;
	}

	@RequestMapping(value = "/updateLeadDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public @ResponseBody ResponseEntity<ResponseDto> updateLeadDetails(@ModelAttribute LeadDto dto,
			HttpServletRequest request) {
		ResponseDto responseDTO = new ResponseDto();
		try {
			int udateLeadMasterResult = serviceLeadMaster.updateLeadMaster(dto);
			if (udateLeadMasterResult == -1) {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription("In-Valid Lead Id.");
			} else {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/publishLead/{id}", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<ResponseDto> publishLead(@PathVariable Long id) {
		ResponseDto responseDTO = new ResponseDto();
		try {
			responseDTO = publishLeadByid(id);
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	private ResponseDto publishLeadByid(Long id) {
		ResponseDto responseDTO = new ResponseDto();
		responseDTO.setJobSeekerId(id.intValue());
		log.info("Going to get Lead Details");
		Optional<LeadMaster> lead = leadMasterRepo.findById(id);
		if (lead.isPresent()) {
			LeadMaster leadMaster = lead.get();

			if (leadMaster.getType().equalsIgnoreCase("Employer")) {
				log.info("Lead Type is Employer. Going to check Employer by Email Id " + leadMaster.getEmail());
				Employer employerE = employerRepo.findByEmail(leadMaster.getEmail());
				if (employerE != null) {
					log.info("Email Id Already Exist with Another Employer Email Id " + leadMaster.getEmail());
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription("Email Id Already Exist with Another Employer");
				} else {
					log.info("Lead Type is Employer. Going to check Employer by Phone No " + leadMaster.getPhone());
					List<Employer> employerP = employerRepo.findByPhone(leadMaster.getPhone());
					if (employerP != null && employerP.size() > 0) {
						log.info("Mobile No Already Exist with Another Employer Mobile No " + leadMaster.getPhone());
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription("Mobile No Already Exist with Another Employer");
					} else {
						log.info("Going to create Employer By Lead Details");
						Employer employer = new Employer();
						employer.setName(leadMaster.getName());
						employer.setEmail(leadMaster.getEmail());
						employer.setPassword(randomPassword(6));
						employer.setPhone(leadMaster.getPhone());
						employer.setCompany(leadMaster.getCompany_name());
						employer.setAddress(leadMaster.getAddress());
						employer.setPan(leadMaster.getPan());
						employer.setGst(leadMaster.getGst());
						employer.setBusinessType(leadMaster.getBussiness_type());
						employer.setDeviceToken("");
						employer.setVerified(false);
						employer.setStatus("IN-ACTIVE");
						employerRepo.save(employer);
						log.info("Created Employer By Lead Details");
						leadMaster.setStatus("Published");
						log.info("Updating Lead Status as Published");
						leadMasterRepo.save(leadMaster);
						log.info("Lead is Published");
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
					}
				}

			} else {
				log.info("Lead Type is Job Seeker");
				log.info("Checking Job Seeker with Phone No and Verified Status");
				JobSeekerMaster jm = null;
				// jm =
				// jobSeekerMasterRepo.findByContactAndVerified(addJobSeekerDto.getContact_no(),
				// true);
				jm = jobSeekerMasterRepo.findByContactAndMobileVerification(leadMaster.getPhone(), true);
				if (jm != null) {
					log.info("Mobile Number is already Verifed with Another Job Seeker " + leadMaster.getPhone());
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription("Mobile Number is already Verifed with Another Job Seeker");

				} else {
					log.info("Going to create jobSeeker By Lead Details");
					JobSeekerMaster jobSeeker = new JobSeekerMaster();

					if (leadMaster.getAddress() != null && !leadMaster.getAddress().equalsIgnoreCase("")) {
						jobSeeker.setAddress(leadMaster.getAddress());
					}
					if (leadMaster.getAvailability() != null && !leadMaster.getAvailability().equalsIgnoreCase("")) {
						jobSeeker.setAvailability(leadMaster.getAvailability());
					}
					if (leadMaster.getEmail() != null && !leadMaster.getEmail().equalsIgnoreCase("")) {
						jobSeeker.setEmail(leadMaster.getEmail());
					}
					if (leadMaster.getPhone() != null && !leadMaster.getPhone().equalsIgnoreCase("")) {
						jobSeeker.setContact(leadMaster.getPhone());
					}
					/*
					 * if(leadMaster.getCurrent_location()!=null &&
					 * !leadMaster.getCurrent_location().equalsIgnoreCase("")){
					 * jobSeeker.setCurrent_location(leadMaster.getCurrent_location()); }
					 */
					if (leadMaster.getExpected_compensation() != null
							&& !leadMaster.getExpected_compensation().equalsIgnoreCase("")) {
						jobSeeker.setExpected_compensation(leadMaster.getExpected_compensation());
					}
					if (leadMaster.getExpected_salary() != null
							&& !leadMaster.getExpected_salary().equalsIgnoreCase("")) {
						jobSeeker.setExpected_salary(leadMaster.getExpected_salary());
					}
					if (leadMaster.getExperience() != null && !leadMaster.getExperience().equalsIgnoreCase("")) {
						jobSeeker.setExperience(leadMaster.getExperience());
					}
					/*
					 * if(leadMaster.getFather_name()!=null &&
					 * !leadMaster.getFather_name().equalsIgnoreCase("")){
					 * jobSeeker.setFather_name(leadMaster.getFather_name()); }
					 */
					if (leadMaster.getNote() != null && !leadMaster.getNote().equalsIgnoreCase("")) {
						jobSeeker.setMessage(leadMaster.getNote());
					}
					if (leadMaster.getName() != null && !leadMaster.getName().equalsIgnoreCase("")) {
						jobSeeker.setName(leadMaster.getName());
					}
					/*
					 * if(leadMaster.getPreferred_location()!=null &&
					 * !leadMaster.getPreferred_location().equalsIgnoreCase("")){
					 * jobSeeker.setPreferred_location(leadMaster.getPreferred_location()); }
					 * if(leadMaster.getDeviceToken()!=null &&
					 * !leadMaster.getDeviceToken().equalsIgnoreCase("")){
					 * jobSeeker.setDeviceToken(leadMaster.getDeviceToken()); }
					 */
					jobSeeker.setStatus("IN-ACTIVE");
					jobSeeker.setVerified(false);
					if (leadMaster.getProfile_pic_url() != null) {
						jobSeeker.setProfile_pic_url(leadMaster.getProfile_pic_url());
					}
					if (leadMaster.getRecording_url() != null) {
						jobSeeker.setRecording_url(leadMaster.getRecording_url());
					}
					if (leadMaster.getSkills() != null && !leadMaster.getSkills().equalsIgnoreCase("")) {
						jobSeeker.setSkills(leadMaster.getSkills());
					}
					jobSeekerMasterRepo.save(jobSeeker);
					if (leadMaster.getSkills() != null && !leadMaster.getSkills().equalsIgnoreCase("")) {
						String skillArr[] = leadMaster.getSkills().split(",");
						if (skillArr.length > 0) {
							for (String s : skillArr) {
								JobSeekerSkillMap skillMap = new JobSeekerSkillMap();
								skillMap.setJobSeekerId(jobSeeker.getId().intValue());
								skillMap.setSkillId(Integer.parseInt(s));
								jobSeekerSkillMapRepo.save(skillMap);
							}
						}
					}
					log.info("Created Job Seeker by Lead Details");
					leadMaster.setStatus("Published");
					log.info("Updating Lead Status as Published");
					leadMasterRepo.save(leadMaster);
					log.info("Lead is Published");
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				}

			}

		} else {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription("In-Valid Lead Id.");
		}
		return responseDTO;
	}

	public String randomPassword(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	@RequestMapping(value = "/publishMultiLead", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<PublishMultiLeadResponseDto> publishMultiLead(
			@RequestBody PublishMultiLeadRequestDto dto, HttpServletRequest request, Errors errors) {
		PublishMultiLeadResponseDto publishMultiLeadResponseDto = new PublishMultiLeadResponseDto();
		try {
			List<ResponseDto> failedList = new ArrayList<>();
			for (Long id : dto.getIdArr()) {
				ResponseDto result = publishLeadByid(id);
				if (!result.getResponseDescription().equalsIgnoreCase(ServerConstants.SUCCESRESPONSEDESC)) {
					failedList.add(result);
				}
			}
			publishMultiLeadResponseDto.setFailedList(failedList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(publishMultiLeadResponseDto, HttpStatus.OK);
	}

}
