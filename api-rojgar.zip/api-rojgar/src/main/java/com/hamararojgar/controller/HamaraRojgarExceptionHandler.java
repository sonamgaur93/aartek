package com.hamararojgar.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.util.Util;

@RestControllerAdvice
public class HamaraRojgarExceptionHandler {

	@Autowired
	Util util;

	@ExceptionHandler(value = Exception.class)
	public @ResponseBody ResponseHamaraRojgar genericException(Exception exception) {
		ResponseHamaraRojgar responseDTO = new ResponseHamaraRojgar();
		responseDTO.setResponseCode(util.buildResponseStatus(500));
		responseDTO.setResponseDescription(exception.getMessage());
		return responseDTO;
	}

}