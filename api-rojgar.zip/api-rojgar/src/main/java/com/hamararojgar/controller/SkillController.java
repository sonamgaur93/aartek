package com.hamararojgar.controller;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import org.springframework.security.core.Authentication;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.AdminDto;
import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.model.LocationMaster;
import com.hamararojgar.model.SkillMaster;
import com.hamararojgar.model.User;
import com.hamararojgar.repo.LocationMasterRepo;
import com.hamararojgar.repo.NotificationMasterRepo;
import com.hamararojgar.repo.SkillMasterRepo;
import com.hamararojgar.repo.UserRepo;
import com.hamararojgar.serviceimpl.AdminService;
import com.hamararojgar.serviceimpl.UserDetailsImpl;
import com.hamararojgar.util.AssetType;
import com.hamararojgar.util.RojgarConstantProperties;
import com.hamararojgar.util.Util;

@Controller
@CrossOrigin(origins = "*")
public class SkillController {

	private static final Logger log = LogManager.getLogger(SkillController.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	AdminService jobSeekerService;

	@Autowired
	LocationMasterRepo locationMasterRepo;

	@Autowired
	SkillMasterRepo skillMasterRepo;

	@Autowired
	UserRepo userRepo;

	@Autowired
	NotificationMasterRepo notificationMasterRepo;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	private RojgarConstantProperties constantProperties;
	
	@Autowired
	Util util;



	@RequestMapping(value = "/getAdminUsers/", method = RequestMethod.GET)
	public @ResponseBody Page<User> getAdminUsers(@RequestParam String search, Pageable pageable) {
		reqLog.info("Got Get Industries Request with search : {}", search);
		Pageable sortedpage = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(),
				Sort.by("id").descending());
		Page<User> industryList = userRepo.findAll(sortedpage);
		return industryList;
	}

	@RequestMapping(value = "/getAdminUserById/{id}", method = RequestMethod.GET)
	public @ResponseBody User getAdminUserById(@PathVariable long id) {
		reqLog.info("Got Get Industry by Id Request with Id : {}", id);
		Optional<User> skillMaster = null;
		try {
			skillMaster = userRepo.findById(id);
		} catch (Exception e) {
			log.info("Exception in getIndustryById Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();

		}
		return skillMaster.get();
	}

	@RequestMapping(value = "/getSkillById/{id}", method = RequestMethod.GET)
	public @ResponseBody SkillMaster getIndustryById(@PathVariable long id) {
		reqLog.info("Got Get Industry by Id Request with Id : {}", id);
		Optional<SkillMaster> skillMaster = null;
		try {
			skillMaster = skillMasterRepo.findById(id);
		} catch (Exception e) {
			log.info("Exception in getIndustryById Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();

		}
		return skillMaster.get();
	}

	@RequestMapping(value = "/deleteSkillById/{id}", method = RequestMethod.GET)
	public @ResponseBody ResponseDTO deleteSkillById(@PathVariable long id) {
		reqLog.info("Got Get Industry by Id Request with Id : {}", id);
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			jdbcTemplate.update("delete from skill_master where id=" + id);
		} catch (Exception e) {
			log.info("Exception in deleteSkillById Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/deleteAdminById/{id}", method = RequestMethod.GET)
	public @ResponseBody ResponseDTO deleteAdminById(@PathVariable long id) {
		reqLog.info("Got Get Industry by Id Request with Id : {}", id);
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			jdbcTemplate.update("delete from admin_users where id=" + id);
		} catch (Exception e) {
			log.info("Exception in deleteAdminById Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/getLocationById/{id}", method = RequestMethod.GET)
	public @ResponseBody LocationMaster getLocationById(@PathVariable long id) {
		reqLog.info("Got Get Industry by Id Request with Id : {}", id);
		Optional<LocationMaster> skillMaster = null;
		try {
			skillMaster = locationMasterRepo.findById(id);
		} catch (Exception e) {
			log.info("Exception in getIndustryById Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();

		}
		return skillMaster.get();
	}

	@Autowired
	JdbcTemplate jdbcTemplate;


	@RequestMapping(value = "/addAdminUser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public @ResponseBody ResponseEntity<ResponseDTO> addAdminUser(@ModelAttribute AdminDto industryDTO,
			HttpServletRequest request, Errors errors) {
		
		
//		
//		String platform = request.getHeader("sec-ch-ua-platform");
//		System.out.println("platform: "+platform);
//		UserDetailsImpl userPrincipal = (UserDetailsImpl) auth.getPrincipal();
//		System.out.println("Principal name is "+userPrincipal);
//		Principal userPrincipal = request.getUserPrincipal();
//		String Princename = userPrincipal.getName();

		
		

		
		
		reqLog.info("Got Add Industry Request for : {}", industryDTO);
		ResponseDTO responseDTO = new ResponseDTO();
		try {

			if (industryDTO.getId() != null && !industryDTO.getId().equalsIgnoreCase("undefined")) {
				Optional<User> skillMaster = userRepo.findById(Long.parseLong(industryDTO.getId()));
				if (skillMaster.isPresent()) {
					User sm = skillMaster.get();
					if (sm.getEmail().equalsIgnoreCase(industryDTO.getEmail())) {
						int count = jdbcTemplate.queryForObject(
								"SELECT count(*) FROM admin_users where email='" + industryDTO.getEmail() + "' ;",
								Integer.class);
						if (count == 1) {
							sm.setEmail(industryDTO.getEmail());
							/*
							 * sm.setPassword(industryDTO.getPassword());
							 * sm.setPasswords(industryDTO.getPassword());
							 */
							if(null != industryDTO.getPassword() && !industryDTO.getPassword().trim().isEmpty()){
								sm.setPassword(encoder.encode(industryDTO.getPassword()));
								sm.setPasswords(encoder.encode(industryDTO.getPassword()));
							}
							
							sm.setRole(industryDTO.getRole());
							sm.setUsername(industryDTO.getUsername());
							sm.setStatus(industryDTO.getStatus());
							if (industryDTO.getProfile_multipart() != null) {
								String url = util.createAsset(industryDTO.getProfile_multipart(), Long.valueOf(industryDTO.getId()), AssetType.ADMIN_PROFILE);
								sm.setProfilePicUrl(constantProperties.getBaseURLAdminProfile() + url);
							}
							
//							sm.setUpdateByPerson(userPrincipal.getId()+" "+userPrincipal.getUsername());
//							sm.setPlatform(platform);


							userRepo.save(sm);
							responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
							responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
						} else {
							responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
							responseDTO.setResponseDescription("Email Already Exists.");
						}
					} else {
						int count = jdbcTemplate.queryForObject(
								"SELECT count(*) FROM admin_users where email='" + industryDTO.getEmail() + "' ;",
								Integer.class);
						if (count == 0) {
							sm.setEmail(industryDTO.getEmail());
							/*
							 * sm.setPassword(industryDTO.getPassword());
							 * sm.setPasswords(industryDTO.getPassword());
							 */
							if(null != industryDTO.getPassword() && !industryDTO.getPassword().trim().isEmpty()){
								sm.setPassword(encoder.encode(industryDTO.getPassword()));
								sm.setPasswords(encoder.encode(industryDTO.getPassword()));
							}
							sm.setRole(industryDTO.getRole());
							sm.setUsername(industryDTO.getUsername());
							sm.setStatus(industryDTO.getStatus());
							if (industryDTO.getProfile_multipart() != null) {
								String url = util.createAsset(industryDTO.getProfile_multipart(), Long.valueOf(industryDTO.getId()), AssetType.ADMIN_PROFILE);
								sm.setProfilePicUrl(constantProperties.getBaseURLAdminProfile() + url);
							}
							
//							sm.setUpdateByPerson(userPrincipal.getId()+" "+userPrincipal.getUsername());
//							sm.setPlatform(platform);

							userRepo.save(sm);
							responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
							responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
						} else {
							responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
							responseDTO.setResponseDescription("Email Already Exists.");
						}
					}

				} else {
					int count = jdbcTemplate.queryForObject(
							"SELECT count(*) FROM admin_users where email='" + industryDTO.getEmail() + "' ;",
							Integer.class);
					if (count == 0) {
						User sm = new User();
						sm.setEmail(industryDTO.getEmail());
						if(null != industryDTO.getPassword() && !industryDTO.getPassword().trim().isEmpty()){
							sm.setPassword(encoder.encode(industryDTO.getPassword()));
							sm.setPasswords(encoder.encode(industryDTO.getPassword()));
						}
						/*
						 * sm.setPassword(industryDTO.getPassword());
						 * sm.setPasswords(industryDTO.getPassword());
						 */
						sm.setRole(industryDTO.getRole());
						sm.setUsername(industryDTO.getUsername());
						sm.setStatus(industryDTO.getStatus());
						userRepo.save(sm);
						if (industryDTO.getProfile_multipart() != null) {
							String url = util.createAsset(industryDTO.getProfile_multipart(), Long.valueOf(industryDTO.getId()), AssetType.ADMIN_PROFILE);
							sm.setProfilePicUrl(constantProperties.getBaseURLAdminProfile() + url);
						}
						
						
//						sm.setUpdateByPerson(userPrincipal.getId()+" "+userPrincipal.getUsername());
//						sm.setPlatform(platform);

						userRepo.save(sm);
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
					} else {
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription("Email Already Exists.");
					}
				}

			} else {
				int count = jdbcTemplate.queryForObject(
						"SELECT count(*) FROM admin_users where email='" + industryDTO.getEmail() + "' ;",
						Integer.class);
				if (count == 0) {
					User sm = new User();
					sm.setEmail(industryDTO.getEmail());
					/*
					 * sm.setPassword(industryDTO.getPassword());
					 * sm.setPasswords(industryDTO.getPassword());
					 */
					if(null != industryDTO.getPassword() && !industryDTO.getPassword().trim().isEmpty()){
						sm.setPassword(encoder.encode(industryDTO.getPassword()));
						sm.setPasswords(encoder.encode(industryDTO.getPassword()));
					}
					sm.setRole(industryDTO.getRole());
					sm.setUsername(industryDTO.getUsername());
					sm.setStatus(industryDTO.getStatus());
					userRepo.save(sm);
					if (industryDTO.getProfile_multipart() != null) {
						String url = util.createAsset(industryDTO.getProfile_multipart(), Long.valueOf(industryDTO.getId()), AssetType.ADMIN_PROFILE);
						sm.setProfilePicUrl(constantProperties.getBaseURLAdminProfile() + url);
					}
					
					
//					sm.setUpdateByPerson(userPrincipal.getId()+" "+userPrincipal.getUsername());
//					sm.setPlatform(platform);

					userRepo.save(sm);
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				} else {
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription("Email Already Exists.");
				}
			}

		} catch (Exception e) {
			log.info("Exception in addIndustry Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	

	

	
}