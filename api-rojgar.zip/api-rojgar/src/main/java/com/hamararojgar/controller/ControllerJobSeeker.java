package com.hamararojgar.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.AddProfileResponseDto;
import com.hamararojgar.dto.JobMasterDto;
import com.hamararojgar.dto.NotificationDto;
import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.dto.ResponseNotification;
import com.hamararojgar.dto.SendOtpDto;
import com.hamararojgar.dto.VerificatioRequestDto;
import com.hamararojgar.dto.VerificatioResponseDto;
import com.hamararojgar.model.AddJobSeekerDto;
import com.hamararojgar.model.ApplyJobDto;
import com.hamararojgar.model.JobListDto;
import com.hamararojgar.model.JobListResponseDto;
import com.hamararojgar.model.JobSeekerIdDto;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.JobSeekerMasterDto;
import com.hamararojgar.model.ResponseDto;
import com.hamararojgar.model.UserOtp;
import com.hamararojgar.repo.JobSeekerMasterRepo;
import com.hamararojgar.repo.UserOtpRepo;
import com.hamararojgar.serviceimpl.JobSeekerService;
import com.hamararojgar.serviceimpl.ServiceNotification;
import com.hamararojgar.util.RojgarConstantProperties;
import com.hamararojgar.util.SmsSender;

@Controller
@CrossOrigin("*")
@RequestMapping("/apijs")
public class ControllerJobSeeker {

	private static final Logger log = LogManager.getLogger(ControllerJobSeeker.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	private JobSeekerService rozgarService;

	@Autowired
	private JobSeekerMasterRepo jobSeekerMasterRepo;

	@Autowired
	private RojgarConstantProperties constantProperties;

	@Autowired
	UserOtpRepo userOtpRepo;

	@Autowired
	ServiceNotification serviceNotification;

	@RequestMapping(value = "/addEditProfile", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<AddProfileResponseDto> addEditProfile(
			@ModelAttribute AddJobSeekerDto addJobSeekerDto, HttpServletRequest request, Errors errors) {
		AddProfileResponseDto responseDTO = new AddProfileResponseDto();
		reqLog.info("Got Add Edit Request :{}", addJobSeekerDto);
		log.info("Got Add Edit Request :{}", addJobSeekerDto);
		try {
			if (addJobSeekerDto.getJob_seeker_id() != 0) {
				JobSeekerMaster jm = null;
				// jm =
				// jobSeekerMasterRepo.findByContactAndVerified(addJobSeekerDto.getContact_no(),
				// true);
				jm = jobSeekerMasterRepo.findByContactAndMobileVerification(addJobSeekerDto.getContact_no(), true);
				if (jm != null) {
					if (jm.getId() != addJobSeekerDto.getJob_seeker_id()) {
						responseDTO.setResponseCode("9999");
						responseDTO.setResponseDescription("Mobile Number is already Verifed with another user in db");
						return new ResponseEntity<>(responseDTO, HttpStatus.OK);
					}
				}
			}

			int id = rozgarService.addEditProfile(addJobSeekerDto);
			log.info("Got Add Edit Request :{}", id);
			if (id > 0) {
				responseDTO.setJobSeekerId(id);
				Optional<JobSeekerMaster> js = rozgarService.getJobSeekerProfileDetails((long) id);
				if (js.isPresent()) {
					JobSeekerMasterDto jobSeekerMasterDto = new JobSeekerMasterDto();
					BeanUtils.copyProperties(js.get(), jobSeekerMasterDto);
					// ObjectMapper mapper = new ObjectMapper();
					// JobSeekerMasterDto jobSeekerMasterDto = mapper.convertValue(js.get(),
					// JobSeekerMasterDto.class);
					jobSeekerMasterDto.setSkills(rozgarService.getSkillStringByJobSeekerId(jobSeekerMasterDto.getId()));
					responseDTO.setJobSeeker(jobSeekerMasterDto);
				}
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else if (id == -1) {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription("Mobile Number Already Exist With Another User.");
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in addEditProfile Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		log.info("Final repsone : " + responseDTO);
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/getJobS", method = RequestMethod.POST)
	public @ResponseBody JobListResponseDto getJobs(@RequestBody JobListDto jobListDto) {
		JobListResponseDto jobListResponseDto = new JobListResponseDto();
		try {
			List<JobMasterDto> jobList = rozgarService.getJobs(jobListDto);
			if (jobList != null) {
				for (JobMasterDto jobMasterDto : jobList) {
					jobMasterDto.setSkills(rozgarService.getSkillStringByJobId(jobMasterDto.getId()));
				}
				jobListResponseDto.setJobList(jobList);
				jobListResponseDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobListResponseDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			jobListResponseDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobListResponseDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobListResponseDto;
	}

	@PostMapping("/getAppliedJobList")
	public @ResponseBody JobListResponseDto getAppliedJobList(@RequestBody JobSeekerIdDto jobSeekerIdDto) {
		JobListResponseDto jobListResponseDto = new JobListResponseDto();
		try {
			List<JobMasterDto> jobList = rozgarService.getAppliedJobList(jobSeekerIdDto);
			if (jobList != null) {
				List<JobMasterDto> jobListFinal = new ArrayList<>();
				List<JobMasterDto> jobListNoChat = new ArrayList<>();
				List<JobMasterDto> jobListChat = new ArrayList<>();
				for (JobMasterDto jobMasterDto : jobList) {
					jobMasterDto.setSkills(rozgarService.getSkillStringByJobId(jobMasterDto.getId()));
					int unreadCountJs = rozgarService.getUnreadMessageCountJobSeeker(jobMasterDto.getAppliedJobId());
					jobMasterDto.setUnreadMessagesByJobSeeker(unreadCountJs);
					int unreadCountEmp = rozgarService.getUnreadMessageCountEmployer(jobMasterDto.getAppliedJobId());
					jobMasterDto.setUnreadMessagesByEmployer(unreadCountEmp);
					boolean chatStarted = rozgarService.checkChatStatus(jobMasterDto.getAppliedJobId());
					jobMasterDto.setChatStarted(chatStarted);
					Date lastMessagetime = rozgarService.getLastChatMessageTime(jobMasterDto.getAppliedJobId());
					if (lastMessagetime != null) {
						// SimpleDateFormat DateFor = new
						// SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
						// String stringDate= DateFor.format(lastMessagetime);
						jobMasterDto.setLastMessagetime(lastMessagetime);
						jobListChat.add(jobMasterDto);
					} else {
						jobListNoChat.add(jobMasterDto);
					}
				}

				jobListChat.sort(Comparator.comparing(JobMasterDto::getLastMessagetime).reversed());
				jobListFinal.addAll(jobListChat);
				jobListFinal.addAll(jobListNoChat);
				jobListResponseDto.setJobList(jobListFinal);
			}
			jobListResponseDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			jobListResponseDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			jobListResponseDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobListResponseDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getAppliedJobList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobListResponseDto;
	}

	@GetMapping("/getJobSeekerProfileDetails/{id}")
	public @ResponseBody JobSeekerMasterDto getJobSeekerProfileDetails(@PathVariable Long id) {
		reqLog.info("Got getJobSeekerProfileDetails by Id Request with Id : {}", id);
		JobSeekerMasterDto jobSeekerMasterDto = new JobSeekerMasterDto();
		try {
			Optional<JobSeekerMaster> brandDTO = null;
			brandDTO = rozgarService.getJobSeekerProfileDetails(id);
			if (brandDTO.isPresent()) {
				// ObjectMapper mapper = new ObjectMapper();
				// jobSeekerMasterDto = mapper.convertValue(brandDTO.get(),
				// JobSeekerMasterDto.class);
				BeanUtils.copyProperties(brandDTO.get(), jobSeekerMasterDto);
				jobSeekerMasterDto.setSkills(rozgarService.getSkillStringByJobSeekerId(jobSeekerMasterDto.getId()));
				jobSeekerMasterDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobSeekerMasterDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				jobSeekerMasterDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				jobSeekerMasterDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			jobSeekerMasterDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobSeekerMasterDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobSeekerProfileDetails Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerMasterDto;
	}

	@PostMapping("/getVerificationStatus")
	public @ResponseBody VerificatioResponseDto getVerificationStatus(
			@RequestBody VerificatioRequestDto addJobSeekerDto) {
		VerificatioResponseDto responseDTO = new VerificatioResponseDto();
		responseDTO.setVerified(false);
		try {
			if (addJobSeekerDto.getContact_no() != null) {
				JobSeekerMaster jm = null;
				// jm =
				// jobSeekerMasterRepo.findByContactAndVerified(addJobSeekerDto.getContact_no(),
				// true);
				jm = jobSeekerMasterRepo.findByContactAndMobileVerification(addJobSeekerDto.getContact_no(), true);
				if (jm != null) {
					responseDTO.setVerified(jm.getVerified());
				}
			}
		} catch (Exception e) {
			log.info("Exception in getVerificationStatus Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/mobileVerification/{mobileNumber}", method = RequestMethod.GET)
	public @ResponseBody ResponseDto jobSeekerMobileVerification(@PathVariable String mobileNumber) {
		ResponseDto responseDTO = new ResponseDto();
		try {
			JobSeekerMaster jobSeekerMaster = rozgarService.getJobSeekerbyMobileNumber(mobileNumber);
			if (null != jobSeekerMaster) {
				SendOtpDto sendOtpDto = new SendOtpDto();
				sendOtpDto.setContact_no(mobileNumber);
				responseDTO = sendOtp(sendOtpDto);
				responseDTO.setJobSeekerId(jobSeekerMaster.getId().intValue());
				responseDTO.setResponseCode("2222");
				responseDTO.setResponseDescription("Mobile Number Already Exist.");
			} else {
				SendOtpDto sendOtpDto = new SendOtpDto();
				sendOtpDto.setContact_no(mobileNumber);

				responseDTO = sendOtp(sendOtpDto);
				// return sendOtp(sendOtpDto );
			}

		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in employerForgotPassword Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/sendOtp", method = RequestMethod.POST)
	public @ResponseBody ResponseDto sendOtp(@RequestBody SendOtpDto sendOtpDto) {
		ResponseDto responseDTO = new ResponseDto();
		try {
			if (sendOtpDto.getContact_no() != null && !sendOtpDto.getContact_no().equalsIgnoreCase("")) {
				String otp = "1234";
				Random random = new Random();
				UserOtp userOtp = userOtpRepo.findByPhone(sendOtpDto.getContact_no());
				if (userOtp != null) {
					if (constantProperties.isSendOtp()) {
						otp = String.format("%06d", random.nextInt(999999));
					}
					userOtp.setOtp(otp);
					userOtp.setPhone(sendOtpDto.getContact_no());
					userOtpRepo.save(userOtp);
				} else {
					UserOtp userOtp2 = new UserOtp();
					if (constantProperties.isSendOtp()) {
						otp = String.format("%06d", random.nextInt(999999));
					}
					userOtp2.setOtp(otp);
					userOtp2.setPhone(sendOtpDto.getContact_no());
					userOtpRepo.save(userOtp2);
				}
				if (constantProperties.isSendOtp()) {
					SmsSender.sendSMS(sendOtpDto.getContact_no(), otp);
				}
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription("Contact Number is Empty");
			}

		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in sendOtp Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/checkJobApplied", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO checkJobApplied(@RequestBody ApplyJobDto applyJobDto) {
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			String result = rozgarService.checkJobApplied(applyJobDto);
			if (result.equalsIgnoreCase(ServerConstants.SUCCESRESPONSEDESC)) {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(result);
			} else {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(result);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in applyForJob Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/applyForJob", method = RequestMethod.POST)
	public @ResponseBody ResponseDto applyForJob(@RequestBody ApplyJobDto applyJobDto) {
		ResponseDto responseDTO = new ResponseDto();
		try {
			String result = rozgarService.applyForJob(applyJobDto);
			if (result.equalsIgnoreCase(ServerConstants.SUCCESRESPONSEDESC)) {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(result);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(result);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in applyForJob Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/getNotificationList/{memberCode}", method = RequestMethod.GET)
	public @ResponseBody NotificationDto getNotification(@PathVariable(name = "memberCode") String memberCode,
			@RequestParam Map<String, String> allRequestParams) {
		NotificationDto notificationDto = new NotificationDto();
		try {
			if (null == allRequestParams) {
				allRequestParams = new HashMap<String, String>();
			}
			allRequestParams.put("memberCode", memberCode);
			allRequestParams.put("userType", "SEEKER");
			List<ResponseNotification> notifications = serviceNotification.getNotifications(allRequestParams);
			if (null == notifications) {
				notifications = new ArrayList<ResponseNotification>();
			}
			notificationDto.setNotificationList(notifications);
			notificationDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			notificationDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			notificationDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			notificationDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getNotificationList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return notificationDto;
	}
}
