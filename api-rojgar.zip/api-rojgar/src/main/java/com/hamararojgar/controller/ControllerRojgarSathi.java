package com.hamararojgar.controller;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.AddProfileResponseDto;
import com.hamararojgar.dto.AddUpdateJobDto;
import com.hamararojgar.dto.AddUpdateJobResponseDto;
import com.hamararojgar.dto.AppliedCandidateDto;
import com.hamararojgar.dto.BannerDTO;
import com.hamararojgar.dto.ChangePasswordRequestDto;
import com.hamararojgar.dto.ChatReadDto;
import com.hamararojgar.dto.DeleteImageDto;
import com.hamararojgar.dto.EmployerDto;
import com.hamararojgar.dto.EmployerJobListDto;
import com.hamararojgar.dto.EmployerLoginRequestDto;
import com.hamararojgar.dto.InviteForJobDto;
import com.hamararojgar.dto.JobListToInviteDto;
import com.hamararojgar.dto.JobMasterDto;
import com.hamararojgar.dto.JobSeekerListByJobDto;
import com.hamararojgar.dto.JobSeekerListResponseDto;
import com.hamararojgar.dto.LeadDto;
import com.hamararojgar.dto.NotificationDto;
import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.dto.ResponseNotification;
import com.hamararojgar.dto.SendOtpDto;
import com.hamararojgar.dto.UpdateDeviceTokenDTO;
import com.hamararojgar.dto.UpdateProfileEmployerDto;
import com.hamararojgar.dto.VerificatioRequestDto;
import com.hamararojgar.dto.VerificatioResponseDto;
import com.hamararojgar.model.AddJobSeekerDto;
import com.hamararojgar.model.AdvertisementsMaster;
import com.hamararojgar.model.ApplyJobDto;
import com.hamararojgar.model.BusinessTypeMaster;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.JobListDto;
import com.hamararojgar.model.JobListResponseDto;
import com.hamararojgar.model.JobMaster;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.JobSeekerMasterDto;
import com.hamararojgar.model.LocationListDto;
import com.hamararojgar.model.MappingMemberFCM;
import com.hamararojgar.model.MasterCampaign;
import com.hamararojgar.model.ResponseDto;
import com.hamararojgar.model.SkillListDto;
import com.hamararojgar.model.UserOtp;
import com.hamararojgar.payload.response.ResponseEmployer;
import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.repo.AdvertisementsMasterRepo;
import com.hamararojgar.repo.AppliedJobChatMasterRepo;
import com.hamararojgar.repo.BusinessTypeMasterRepo;
import com.hamararojgar.repo.EmployerRepo;
import com.hamararojgar.repo.JobMasterRepo;
import com.hamararojgar.repo.JobSeekerMasterRepo;
import com.hamararojgar.repo.LocationMasterRepo;
import com.hamararojgar.repo.NotificationMasterRepo;
import com.hamararojgar.repo.RepoMappingMemberFCM;
import com.hamararojgar.repo.UserOtpRepo;
import com.hamararojgar.serviceimpl.AWSS3Service;
import com.hamararojgar.serviceimpl.JobSeekerService;
import com.hamararojgar.serviceimpl.MailSenderService;
import com.hamararojgar.serviceimpl.MasterDataService;
import com.hamararojgar.serviceimpl.ServiceCampaign;
import com.hamararojgar.serviceimpl.ServiceLeadMaster;
import com.hamararojgar.serviceimpl.ServiceMappingMemberFCM;
import com.hamararojgar.serviceimpl.ServiceNotification;
import com.hamararojgar.util.JwtUtils;
import com.hamararojgar.util.RojgarConstantProperties;
import com.hamararojgar.util.RojgarPasswordGenerator;
import com.hamararojgar.util.SmsSender;
import com.hamararojgar.util.Util;

@Controller
@CrossOrigin("*")
@RequestMapping("/apisathi")
public class ControllerRojgarSathi {

	private static final Logger log = LogManager.getLogger(ControllerRojgarSathi.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	JwtUtils jwtUtils;

	@Autowired
	private JobSeekerService rozgarService;

	@Autowired
	private RojgarConstantProperties constantProperties;

	@Autowired
	private LocationMasterRepo locationMasterRepo;

	@Autowired
	private BusinessTypeMasterRepo businessTypeMasterRepo;

	@Autowired
	private NotificationMasterRepo notificationMasterRepo;

	@Autowired
	private AppliedJobChatMasterRepo appliedJobChatMasterRepo;

	@Autowired
	EmployerRepo employerRepo;

	@Autowired
	JobMasterRepo jobMasterRepo;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	AdvertisementsMasterRepo advertisementsMasterRepo;

	@Autowired
	private ServiceLeadMaster serviceLeadMaster;

	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	@Autowired
	MailSenderService mailSenderService;

	@Autowired
	UserOtpRepo userOtpRepo;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	private AWSS3Service awss3Service;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	MasterDataService masterDataService;

	@Autowired
	Util util;

	@Autowired
	private ServiceCampaign serviceCampaign;

	@Autowired
	ServiceMappingMemberFCM serviceMappingMemberFCM;

	@Autowired
	ServiceNotification serviceNotification;

	@RequestMapping(value = "/getSkills", method = RequestMethod.GET)
	public @ResponseBody SkillListDto getSkills() {
		SkillListDto skillListDto = new SkillListDto();
		try {
			skillListDto.setSkillList(masterDataService.getAllSkills());
			skillListDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			skillListDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			skillListDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			skillListDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getSkills Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return skillListDto;
	}

	@RequestMapping(value = "/addBanner", method = RequestMethod.GET)
	public @ResponseBody BannerDTO addBanner() {
		BannerDTO dto = new BannerDTO();
		try {
			List<AdvertisementsMaster> adList = advertisementsMasterRepo.findByStatus("ACTIVE");
			/*
			 * String imageName = rozgarService.getRandomBannerImage();
			 * if(!imageName.equalsIgnoreCase("")){
			 * dto.setBannerUrl(baseUrlImage+imageName); }else{ dto.setBannerUrl(imageName);
			 * }
			 */
			List<String> bannerList = new ArrayList<>();
			for (AdvertisementsMaster ad : adList) {
				bannerList.add(constantProperties.getBaseUrlImage() + ad.getImageUrl());
			}
			dto.setBannerList(bannerList);
			dto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			dto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			dto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			dto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getSkills Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return dto;
	}

	@RequestMapping(value = "/getLocations", method = RequestMethod.GET)
	public @ResponseBody LocationListDto getLocations() {
		LocationListDto locationListDto = new LocationListDto();
		try {
			locationListDto.setLocationList(locationMasterRepo.findAll());
			locationListDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			locationListDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			locationListDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			locationListDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getLocations Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return locationListDto;
	}

	@Autowired
	JobSeekerMasterRepo jobSeekerMasterRepo;

	@RequestMapping(value = "/getVerificationStatus", method = RequestMethod.POST)
	public @ResponseBody VerificatioResponseDto getVerificationStatus(
			@RequestBody VerificatioRequestDto addJobSeekerDto) {
		VerificatioResponseDto responseDTO = new VerificatioResponseDto();
		responseDTO.setVerified(false);
		try {
			if (addJobSeekerDto.getContact_no() != null) {
				JobSeekerMaster jm = null;
				// jm =
				// jobSeekerMasterRepo.findByContactAndVerified(addJobSeekerDto.getContact_no(),
				// true);
				jm = jobSeekerMasterRepo.findByContactAndMobileVerification(addJobSeekerDto.getContact_no(), true);
				if (jm != null) {
					responseDTO.setVerified(jm.getVerified());
				}
			}
		} catch (Exception e) {
			log.info("Exception in getVerificationStatus Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/addEditProfile", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<AddProfileResponseDto> addEditProfile(
			@ModelAttribute AddJobSeekerDto addJobSeekerDto, HttpServletRequest request, Errors errors) {
		AddProfileResponseDto responseDTO = new AddProfileResponseDto();
		reqLog.info("Got Add Edit Request :{}", addJobSeekerDto);
		try {
			if (addJobSeekerDto.getJob_seeker_id() != 0) {
				JobSeekerMaster jm = null;
				// jm =
				// jobSeekerMasterRepo.findByContactAndVerified(addJobSeekerDto.getContact_no(),
				// true);
				jm = jobSeekerMasterRepo.findByContactAndMobileVerification(addJobSeekerDto.getContact_no(), true);
				if (jm != null) {
					if (jm.getId() != addJobSeekerDto.getJob_seeker_id()) {
						responseDTO.setResponseCode("9999");
						responseDTO.setResponseDescription("Mobile Number is already Verifed with another user in db");
						return new ResponseEntity<>(responseDTO, HttpStatus.OK);
					}
				}
			}

			int id = rozgarService.addEditProfile(addJobSeekerDto);
			if (id > 0) {
				responseDTO.setJobSeekerId(id);
				Optional<JobSeekerMaster> js = rozgarService.getJobSeekerProfileDetails((long) id);
				if (js.isPresent()) {
					ObjectMapper mapper = new ObjectMapper();
					JobSeekerMasterDto jobSeekerMasterDto = mapper.convertValue(js.get(), JobSeekerMasterDto.class);
					jobSeekerMasterDto.setSkills(rozgarService.getSkillStringByJobSeekerId(jobSeekerMasterDto.getId()));
					responseDTO.setJobSeeker(jobSeekerMasterDto);
				}
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else if (id == -1) {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription("Mobile Number Already Exist With Another User.");
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in addEditProfile Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/sendOtp", method = RequestMethod.POST)
	public @ResponseBody ResponseDto sendOtp(@RequestBody SendOtpDto sendOtpDto) {
		ResponseDto responseDTO = new ResponseDto();
		try {
			if (sendOtpDto.getContact_no() != null && !sendOtpDto.getContact_no().equalsIgnoreCase("")) {
				String otp = "1234";
				Random random = new Random();
				UserOtp userOtp = userOtpRepo.findByPhone(sendOtpDto.getContact_no());
				if (userOtp != null) {
					if (constantProperties.isSendOtp()) {
						otp = String.format("%06d", random.nextInt(999999));
					}
					userOtp.setOtp(otp);
					userOtp.setPhone(sendOtpDto.getContact_no());
					userOtpRepo.save(userOtp);
				} else {
					UserOtp userOtp2 = new UserOtp();
					if (constantProperties.isSendOtp()) {
						otp = String.format("%06d", random.nextInt(999999));
					}
					userOtp2.setOtp(otp);
					userOtp2.setPhone(sendOtpDto.getContact_no());
					userOtpRepo.save(userOtp2);
				}
				if (constantProperties.isSendOtp()) {
					SmsSender.sendSMS(sendOtpDto.getContact_no(), otp);
				}
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription("Contact Number is Empty");
			}

		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in sendOtp Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/getJobList", method = RequestMethod.POST)
	public @ResponseBody JobListResponseDto getJobList(@RequestBody JobListDto jobListDto) {
		JobListResponseDto jobListResponseDto = new JobListResponseDto();
		try {
			List<JobMasterDto> jobList = rozgarService.getJobList(jobListDto);
			if (jobList != null) {
				for (JobMasterDto jobMasterDto : jobList) {
					jobMasterDto.setSkills(rozgarService.getSkillStringByJobId(jobMasterDto.getId()));
				}
				jobListResponseDto.setJobList(jobList);
				jobListResponseDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobListResponseDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			jobListResponseDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobListResponseDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobListResponseDto;
	}

	/**
	 * Employer's API's Started
	 * 
	 * @author Sumit Sharma
	 *
	 */

	@RequestMapping(value = "/getEmployerDetails/{id}", method = RequestMethod.GET)
	public @ResponseBody EmployerLoginResponseDto getEmployerDetails(@PathVariable Long id) {
		EmployerLoginResponseDto responseDTO = new EmployerLoginResponseDto();
		try {
			Optional<Employer> employerE = employerRepo.findById(id);
			if (employerE.isPresent()) {
				Employer employer = employerE.get();
				EmployerDto  employerDto = new EmployerDto();
				BeanUtils.copyProperties(employer, employerDto);
				BusinessTypeMaster businessTypeMaster = masterDataService.getBusinessTypeMaster(Long.parseLong(employerDto.getBusinessType()));
				if(null !=businessTypeMaster ) {
				employerDto.setBusinessTypeName(businessTypeMaster.getTitle());
				}
				responseDTO.setEmployer(employer);
				responseDTO.setEmployerUpdate(employerDto);
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getEmployerDetails Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/getEmployerDetails/{id}/{propertyName}", method = RequestMethod.GET)
	public @ResponseBody ResponseHamaraRojgar getEmployerDetails(@PathVariable Long id,
			@PathVariable String propertyName) {
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseEmployer responseEmployer = new ResponseEmployer();
		try {
			Optional<Employer> employerE = employerRepo.findById(id);
			if (employerE.isPresent()) {
				Employer employer = employerE.get();
				EmployerDto employerDto = new EmployerDto();
				if ("name".equalsIgnoreCase(propertyName)) {
					employerDto.setName(employer.getName());
				} else if ("company".equalsIgnoreCase(propertyName)) {
					employerDto.setCompany(employer.getCompany());
				}
				responseEmployer.setEmployer(employerDto);
				responseHamaraRojgar.setContent(responseEmployer);
				responseHamaraRojgar.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			responseHamaraRojgar.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseHamaraRojgar.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getEmployerDetails Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseHamaraRojgar;
	}

	@RequestMapping(value = "/employerLoginCheck", method = RequestMethod.POST)
	public @ResponseBody EmployerLoginResponseDto employerLoginCheck(@RequestBody EmployerLoginRequestDto requestDto) {
		EmployerLoginResponseDto responseDTO = new EmployerLoginResponseDto();
		try {
			Employer employer = employerRepo.findByEmail(requestDto.getEmail());
			if (null != employer) {
				if (util.validateUserPassword(requestDto.getPassword(), employer.getPassword())) {
					log.info("employerLoginCheck :: password matched ");
					if (null != requestDto.getDeviceToken()) {
						employer.setDeviceToken(requestDto.getDeviceToken());
						employerRepo.save(employer);
						serviceMappingMemberFCM.createMappingMemberFCM("SATHI", String.valueOf(employer.getId()),
								requestDto.getDeviceToken());
					}
					try {
						Authentication authentication = authenticationManager.authenticate(
								new UsernamePasswordAuthenticationToken(employer.getEmail(), employer.getPassword()));
						SecurityContextHolder.getContext().setAuthentication(authentication);
						String jwt = jwtUtils.generateMobileJwtToken(authentication, "EMPLOYER");

					} catch (AuthenticationException e) {

					}
					responseDTO.setEmployer(employer);
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				} else {
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription("Invalid Password.");
				}
			} else {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription("Invalid Email Address.");
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in employerLoginCheck Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/registerEmployer", method = RequestMethod.POST)
	public @ResponseBody EmployerLoginResponseDto registerEmployer(@RequestBody EmployerLoginRequestDto requestDto) {
		EmployerLoginResponseDto responseDTO = new EmployerLoginResponseDto();
		try {
			Employer employerE = employerRepo.findByEmail(requestDto.getEmail());
			if (employerE != null) {
				responseDTO.setResponseCode("2222");
				responseDTO.setResponseDescription("Email Id Already Exist.");
			} else {
				Employer employer = new Employer();
				employer.setName(requestDto.getName());
				employer.setEmail(requestDto.getEmail());
				// employer.setPassword(requestDto.getPassword());
				employer.setPassword(encoder.encode(requestDto.getPassword()));
				employer.setDeviceToken(requestDto.getDeviceToken());
				employer.setVerified(false);
				employer.setMobileVerification(requestDto.getMobileVerification());
				employer.setEmailVerification(requestDto.getEmailVerification());
				employer.setEntryDateTime(Instant.now());
				employer.setRegisteredDateTime(employer.getEntryDateTime());
				employer.setStatus("IN-ACTIVE");
				employerRepo.save(employer);
				responseDTO.setEmployer(employer);
				serviceLeadMaster.createEmployeeLead(employer);
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				serviceMappingMemberFCM.createMappingMemberFCM("SATHI", String.valueOf(employer.getId()),
						requestDto.getDeviceToken());
			}

		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in registerEmployer Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/deleteCompanyImage", method = RequestMethod.POST)
	public @ResponseBody EmployerLoginResponseDto deleteCompanyImage(@RequestBody DeleteImageDto dto) {
		EmployerLoginResponseDto responseDTO = new EmployerLoginResponseDto();
		try {
			Optional<Employer> employer = employerRepo.findById((long) dto.getEmployerId());
			if (employer.isPresent()) {
				Employer emp = employer.get();
				if (dto.getImageKey() == 1) {
					emp.setCompanyImage("");
				} else if (dto.getImageKey() == 2) {
					emp.setCompanyImage2("");
				} else if (dto.getImageKey() == 3) {
					emp.setCompanyImage3("");
				} else if (dto.getImageKey() == 4) {
					emp.setCompanyImage4("");
				} else if (dto.getImageKey() == 5) {
					emp.setCompanyImage5("");
				}
				employerRepo.save(emp);
				responseDTO.setEmployer(emp);
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}

		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in deleteCompanyImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/updateEmplyerProfile", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<EmployerLoginResponseDto> updateEmplyerProfile(
			@ModelAttribute UpdateProfileEmployerDto updateProfileEmployerDto, HttpServletRequest request,
			Errors errors) {
		EmployerLoginResponseDto responseDTO = new EmployerLoginResponseDto();
		try {
			Employer employer = rozgarService.updateEmplyerProfile(updateProfileEmployerDto);
			if (employer != null) {
				responseDTO.setEmployer(employer);
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in updateEmplyerProfile Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/employerForgotPassword/{email}", method = RequestMethod.GET)
	public @ResponseBody ResponseDTO employerForgotPassword(@PathVariable String email) {
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			if (null != email && !email.trim().isEmpty()) {
				Employer employerE = employerRepo.findByEmail(email);
				if (null != employerE) {
					// String pass = employerE.getPassword();
					/*
					 * employerE.setPassword(pass); employerRepo.save(employerE);
					 */

					String pass = RojgarPasswordGenerator.generateStrongPassword();
					log.info("Generate Pass: " + pass);
					employerE.setPassword(encoder.encode(pass));
					employerRepo.save(employerE);
					String to = employerE.getEmail();
					String mailContent = constantProperties.getEmailTemplateForgotContect()
							.replace("HAMARAROJGAR_NEW_PASSWORD", pass);
					String subject = constantProperties.getEmailTemplateForgotSubject();
					if (constantProperties.isSendByGmail()) {
						mailSenderService.sendMail(to, mailContent, subject);
					} else {
						mailSenderService.sendMailBySmtp(to, mailContent, subject);
					}
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				} else {
					responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
					responseDTO.setResponseDescription("Email Address Does not Exists.");
				}
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription("Email Address Empty");
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in employerForgotPassword Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	public String randomPassword(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	@RequestMapping(value = "/getJobSeekerList", method = RequestMethod.POST)
	public @ResponseBody JobSeekerListResponseDto getJobSeekerList(@RequestBody JobListDto jobListDto) {
		JobSeekerListResponseDto jobSeekerListResponseDto = new JobSeekerListResponseDto();
		try {
			List<JobSeekerMasterDto> jobSeekerList = rozgarService.getJobSeekerList(jobListDto);
			if (jobSeekerList != null) {
				for (JobSeekerMasterDto jobSeekerMasterDto : jobSeekerList) {
					jobSeekerMasterDto.setSkills(rozgarService.getSkillStringByJobSeekerId(jobSeekerMasterDto.getId()));
				}
				jobSeekerListResponseDto.setJobSeekerList(jobSeekerList);
				jobSeekerListResponseDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobSeekerListResponseDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			jobSeekerListResponseDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobSeekerListResponseDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobSeekerList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerListResponseDto;
	}

	@RequestMapping(value = "/getJobSeekers", method = RequestMethod.POST)
	public @ResponseBody JobSeekerListResponseDto getJobSeekersList(@RequestBody JobListDto jobListDto) {
		JobSeekerListResponseDto jobSeekerListResponseDto = new JobSeekerListResponseDto();
		try {
			List<JobSeekerMasterDto> jobSeekerList = rozgarService.getJobSeekers(jobListDto);
			if (jobSeekerList != null) {
				for (JobSeekerMasterDto jobSeekerMasterDto : jobSeekerList) {
					jobSeekerMasterDto.setSkills(rozgarService.getSkillStringByJobSeekerId(jobSeekerMasterDto.getId()));
				}
				jobSeekerListResponseDto.setJobSeekerList(jobSeekerList);
				jobSeekerListResponseDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobSeekerListResponseDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			jobSeekerListResponseDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobSeekerListResponseDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobSeekerList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerListResponseDto;
	}

	@RequestMapping(value = "/addUpdateJob", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<AddUpdateJobResponseDto> addUpdateJob(
			@ModelAttribute AddUpdateJobDto addUpdateJobDto, HttpServletRequest request, Errors errors) {
		AddUpdateJobResponseDto responseDTO = new AddUpdateJobResponseDto();
		try {
			JobMaster jobMaster = rozgarService.addUpdateJob(addUpdateJobDto);
			if (jobMaster != null) {
				responseDTO.setJobMaster(jobMaster);
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in addUpdateJob Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/getJobListToInviteByCandidate", method = RequestMethod.POST)
	public @ResponseBody EmployerJobListDto getJobListToInviteByCandidate(@RequestBody JobListToInviteDto dto) {
		EmployerJobListDto responseDTO = new EmployerJobListDto();
		try {
			List<JobMaster> jobList = jobMasterRepo.findByEmployerId(String.valueOf(dto.getEmployer_id()));
			List<JobMasterDto> jobListreq = new ArrayList<JobMasterDto>();
			for (JobMaster jm : jobList) {
				ApplyJobDto applyJobDto = new ApplyJobDto();
				applyJobDto.setJob_id(jm.getId().intValue());
				applyJobDto.setJob_seeker_id(dto.getJob_seeker_id());
				String result = rozgarService.checkJobApplied(applyJobDto);
				if (result.equalsIgnoreCase("Not Applied for this Job")) {
					ObjectMapper mapper = new ObjectMapper();
					JobMasterDto jobMasterDto = mapper.convertValue(jm, JobMasterDto.class);
					jobMasterDto.setSkills(rozgarService.getSkillStringByJobId(jobMasterDto.getId()));
					jobListreq.add(jobMasterDto);
				}
			}
			responseDTO.setJobList(jobListreq);
			responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobListToInviteByCandidate Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/getEmployerJobList/{id}", method = RequestMethod.GET)
	public @ResponseBody EmployerJobListDto getEmployerJobList(@PathVariable String id) {
		EmployerJobListDto employerJobListDto = new EmployerJobListDto();
		try {
			List<JobMaster> jobList = jobMasterRepo.findByEmployerId(id);
			List<JobMasterDto> jobListreq = new ArrayList<JobMasterDto>();
			for (JobMaster jm : jobList) {
				ObjectMapper mapper = new ObjectMapper();
				JobMasterDto jobMasterDto = mapper.convertValue(jm, JobMasterDto.class);
				jobMasterDto.setSkills(rozgarService.getSkillStringByJobId(jobMasterDto.getId()));
				jobListreq.add(jobMasterDto);
			}
			employerJobListDto.setJobList(jobListreq);
			employerJobListDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			employerJobListDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			employerJobListDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			employerJobListDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getEmployerJobList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return employerJobListDto;
	}

	@GetMapping("/employer/{id}/postedjobs")
	public @ResponseBody ResponseHamaraRojgar getJobList(@PathVariable Long id,
			@RequestParam Map<String, String> searchParameter) {

		int httpStatusValue = -1;

		ResponseEmployer responseEmployer = rozgarService.getJobList(id, searchParameter);
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		if (null == responseEmployer) {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
			responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
			return responseHamaraRojgar;
		}
		httpStatusValue = HttpStatus.OK.value();
		responseHamaraRojgar.setContent(responseEmployer);
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;

	}

	@RequestMapping(value = "/getContactedAppliedCandidatesByEmployerId/{id}", method = RequestMethod.GET)
	public @ResponseBody JobSeekerListByJobDto getContactedAppliedCandidatesByEmployerId(@PathVariable int id) {
		JobSeekerListByJobDto jobSeekerListByJobDto = new JobSeekerListByJobDto();
		try {
			List<AppliedCandidateDto> appliedCandidateChatList = new ArrayList<AppliedCandidateDto>();
			List<AppliedCandidateDto> appliedCandidateList = rozgarService.getAppliedCandidateListByEmployerId(id);
			if (appliedCandidateList != null) {
				List<AppliedCandidateDto> jobListFinal = new ArrayList<>();
				List<AppliedCandidateDto> jobListNoChat = new ArrayList<>();
				List<AppliedCandidateDto> jobListChat = new ArrayList<>();
				for (AppliedCandidateDto appliedCandidateDto : appliedCandidateList) {
					appliedCandidateDto.setSkills(
							rozgarService.getSkillStringByJobSeekerId((long) appliedCandidateDto.getJob_seeker_id()));
					int unreadCountJs = rozgarService
							.getUnreadMessageCountJobSeeker(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setUnreadMessagesByJobSeeker(unreadCountJs);
					int unreadCountEmp = rozgarService
							.getUnreadMessageCountEmployer(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setUnreadMessagesByEmployer(unreadCountEmp);
					boolean chatStarted = rozgarService.checkChatStatus(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setChatStarted(chatStarted);
					if (appliedCandidateDto.isChatStarted()) {
						// appliedCandidateChatList.add(appliedCandidateDto);
						// TODO
						Date lastMessageTime = rozgarService
								.getLastChatMessageTime(appliedCandidateDto.getAppliedJobId());
						if (lastMessageTime != null) {
							appliedCandidateDto.setLastMessageTime(lastMessageTime);
							jobListChat.add(appliedCandidateDto);
						} else {
							jobListNoChat.add(appliedCandidateDto);
						}
					}
				}
				jobListChat.sort(Comparator.comparing(AppliedCandidateDto::getLastMessageTime).reversed());
				jobListFinal.addAll(jobListChat);
				jobListFinal.addAll(jobListNoChat);
				jobSeekerListByJobDto.setAppliedCandidateList(jobListFinal);
			}
			jobSeekerListByJobDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			jobSeekerListByJobDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			jobSeekerListByJobDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobSeekerListByJobDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getAppliedCandidateListByJobId Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerListByJobDto;
	}

	@RequestMapping(value = "/getAppliedCandidateListByJobId/{id}", method = RequestMethod.GET)
	public @ResponseBody JobSeekerListByJobDto getAppliedCandidateListByJobId(@PathVariable int id) {
		JobSeekerListByJobDto jobSeekerListByJobDto = new JobSeekerListByJobDto();
		try {
			List<AppliedCandidateDto> appliedCandidateList = rozgarService.getAppliedCandidateListByJobId(id);
			if (appliedCandidateList != null) {
				for (AppliedCandidateDto appliedCandidateDto : appliedCandidateList) {
					appliedCandidateDto.setSkills(
							rozgarService.getSkillStringByJobSeekerId((long) appliedCandidateDto.getJob_seeker_id()));
					int unreadCountJs = rozgarService
							.getUnreadMessageCountJobSeeker(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setUnreadMessagesByJobSeeker(unreadCountJs);
					int unreadCountEmp = rozgarService
							.getUnreadMessageCountEmployer(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setUnreadMessagesByEmployer(unreadCountEmp);
					boolean chatStarted = rozgarService.checkChatStatus(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setChatStarted(chatStarted);
				}
				jobSeekerListByJobDto.setAppliedCandidateList(appliedCandidateList);
			}
			jobSeekerListByJobDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			jobSeekerListByJobDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			jobSeekerListByJobDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobSeekerListByJobDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getAppliedCandidateListByJobId Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerListByJobDto;
	}

	@RequestMapping(value = "/markJobAsFulfilled/{id}", method = RequestMethod.GET)
	public @ResponseBody JobMasterDto markJobAsFulfilled(@PathVariable int id) {
		JobMasterDto jobMasterDto = new JobMasterDto();
		try {
			rozgarService.markJobAsFulfilled(id);
			Optional<JobMaster> jobMaster = rozgarService.getJobDetails((long) id);
			if (jobMaster.isPresent()) {
				ObjectMapper mapper = new ObjectMapper();
				jobMasterDto = mapper.convertValue(jobMaster.get(), JobMasterDto.class);
				jobMasterDto.setSkills(rozgarService.getSkillStringByJobId((long) id));
				jobMasterDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobMasterDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				jobMasterDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				jobMasterDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			jobMasterDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobMasterDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in markJobAsFulfilled Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobMasterDto;
	}

	@RequestMapping(value = "/changePassword", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO changePassword(@RequestBody ChangePasswordRequestDto requestDto) {
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			Optional<Employer> emp = employerRepo.findById((long) requestDto.getEmployer_id());
			if (emp.isPresent()) {
				Employer employer = emp.get();
				// if (employer.getPassword().equalsIgnoreCase(requestDto.getOld_password())) {
				if (util.validateUserPassword(requestDto.getOld_password(), employer.getPassword())) {
					if (requestDto.getNew_password() != null && !requestDto.getNew_password().equalsIgnoreCase("")) {
						jdbcTemplate.update(
								"update employer_master set password='" + encoder.encode(requestDto.getNew_password())
										+ "' where id=" + requestDto.getEmployer_id());
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription("Password Updated.");
					} else {
						responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
						responseDTO.setResponseDescription("New Password is Empty or Null.");
					}
				} else {
					responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
					responseDTO.setResponseDescription("Invalid Old Password.");
				}
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription("Invalid Employer Id.");
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in changePassword Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/inviteForJob", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO inviteForJob(@RequestBody InviteForJobDto inviteForJobDto) {
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			String result = rozgarService.inviteForJob(inviteForJobDto);
			if (result.equalsIgnoreCase(ServerConstants.SUCCESRESPONSEDESC)) {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(result);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(result);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in chatReadUpdate Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/employerEmailVerification/{email}", method = RequestMethod.GET)
	public @ResponseBody ResponseDTO employerEmailVerification(@PathVariable String email) {

		ResponseDTO responseDTO = new ResponseDTO();

		try {
			Employer employerE = employerRepo.findByEmail(email);
			if (employerE != null) {
				responseDTO.setResponseCode("2222");
				responseDTO.setResponseDescription("Email Id Already Exist.");
			} else {
				String emailOTP = util.generateEmailOTP();
				UserOtp userOtp = new UserOtp();
				userOtp.setOtp(emailOTP);
				userOtp.setEmail(email);
				userOtp.setExpiryTimeStamp(util.addMinutesToCurrentTime(5));
				userOtpRepo.save(userOtp);

				String to = email;
				String mailContent = constantProperties.getEmailTemplateOTPContect().replace("HAMARAROJGAR_EMAIL_OTP",
						emailOTP);
				String subject = constantProperties.getEmailTemplateOTPSubject();
				if (constantProperties.isSendByGmail()) {
					mailSenderService.sendMail(to, mailContent, subject);
				} else {
					mailSenderService.sendMailBySmtp(to, mailContent, subject);
				}
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}

		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in employerForgotPassword Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/updateDeviceToken", method = RequestMethod.PUT)
	public @ResponseBody ResponseDTO updateDeviceToken(@RequestBody UpdateDeviceTokenDTO updateDeviceTokenDTO) {
		ResponseDTO responseDTO = new ResponseDTO();

		try {

			if (0 < rozgarService.updateDeviceToken(updateDeviceTokenDTO)) {
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode("2222");
				responseDTO.setResponseDescription("Unable to update the token");
			}

		} catch (Exception e) {
			log.info("Exception in getVerificationStatus Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
		}
		return responseDTO;
	}

	@RequestMapping(value = "/getNotificationList/{memberCode}", method = RequestMethod.GET)
	public @ResponseBody NotificationDto getNotification(@PathVariable(name = "memberCode") String memberCode,
			@RequestParam Map<String, String> allRequestParams) {
		NotificationDto notificationDto = new NotificationDto();
		try {
			if (null == allRequestParams) {
				allRequestParams = new HashMap<String, String>();
			}
			allRequestParams.put("memberCode", memberCode);
			allRequestParams.put("userType", "SATHI");
			List<ResponseNotification> notifications = serviceNotification.getNotifications(allRequestParams);
			if (null == notifications) {
				notifications = new ArrayList<ResponseNotification>();
			}
			notificationDto.setNotificationList(notifications);
			notificationDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			notificationDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			notificationDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			notificationDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getNotificationList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return notificationDto;
	}
}