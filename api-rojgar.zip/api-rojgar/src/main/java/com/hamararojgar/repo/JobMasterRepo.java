package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hamararojgar.model.JobMaster;

public interface JobMasterRepo extends JpaRepository<JobMaster, Long> {

	List<JobMaster> findByEmployerId(String id);
	 
	 @Query(value = "select * from job_master where employer_id =?1 \n#pageable\n",
	            countQuery = "select count(*) from job_master where employer_id  =?1",
	            nativeQuery = true)
	Page<JobMaster> findByEmployerId(String  employerId, Pageable sortedpage);

	 @Query(value = "select * from job_master where title like %?1% \n#pageable\n",
	            countQuery = "select count(*) from job_master where title like %?1%",
	            nativeQuery = true)
	Page<JobMaster> findAllByTitleLike(String title, Pageable sortedpage);

	 @Query(value = "select * from job_master where location like %?1% \n#pageable\n",
	            countQuery = "select count(*) from job_master where location like %?1%",
	            nativeQuery = true)
	Page<JobMaster> findAllByLocationLike(String location, Pageable sortedpage);

	 @Query(value = "select * from job_master where title like %?1% and location like %?2%  \n#pageable\n",
	            countQuery = "select count(*) from job_master where title like %?1% and location like %?2% ",
	            nativeQuery = true)
	Page<JobMaster> findAllByTitleLikeAndLocationLike(String title, String location, Pageable sortedpage);

	 @Query(value = "select * from job_master where title like %:title% and status IN (:names)  \n#pageable\n",
	            countQuery = "select count(*) from job_master where title like %:title% and status IN (:names) ",
	            nativeQuery = true)
	Page<JobMaster> findByTitleLikeAndStatus(@Param("title") String title, @Param("names") List<String> s, Pageable sortedpage);
	 
	 @Query(value = "select * from job_master where location like %?1% and status IN ?2  \n#pageable\n",
	            countQuery = "select count(*) from job_master where location like %?1% and status IN ?2 ",
	            nativeQuery = true)
	Page<JobMaster> findAllByLocationLikeAndStatus(String location, List<String> s, Pageable sortedpage);
	 
	@Query(value = "select * from job_master where job_track_id like %?1% and status IN ?2 \n#pageable\n",
	            countQuery = "select count(*) from job_master where job_track_id like %?1% and status IN ?2",
	            nativeQuery = true)
	Page<JobMaster> findAllByJobTrackIdLikeAndStatus(String jobid, List<String> s,
			Pageable sortedpage);

	 @Query(value = "select * from job_master where title like %?1% and location like %?2% and status IN ?3 \n#pageable\n",
	            countQuery = "select count(*) from job_master where title like %?1% and location like %?2% and status IN ?3",
	            nativeQuery = true)
	Page<JobMaster> findAllByTitleLikeAndLocationLikeAndStatus(String title, String location, List<String> s, Pageable sortedpage);

	 @Query(value = "select * from job_master where location like %?1% and job_track_id like %?2% and status IN ?3 \n#pageable\n",
	            countQuery = "select count(*) from job_master where location like %?1% and job_track_id like %?2% and status IN ?3",
	            nativeQuery = true)
	Page<JobMaster> findAllByLocationLikeAndJobTrackIdLikeAndStatus(String location, String jobid, List<String> s,
			Pageable sortedpage);
	 
	 @Query(value = "select * from job_master where title like %?1% and job_track_id like %?2% and status IN ?3 \n#pageable\n",
	            countQuery = "select count(*) from job_master where title like %?1% and job_track_id like %?2% and status IN ?3",
	            nativeQuery = true)
	Page<JobMaster> findAllByTitleLikeAndJobTrackIdLikeAndStatus(String title, String jobid, List<String> s,
			Pageable sortedpage);

	 @Query(value = "select * from job_master where title like %?1% and location like %?2% and job_track_id like %?3% and status IN ?4 \n#pageable\n",
	            countQuery = "select count(*) from job_master where title like %?1% and location like %?2% and job_track_id like %?3% and status IN ?4",
	            nativeQuery = true)
	Page<JobMaster> findAllByTitleLikeAndLocationLikeAndJobTrackIdLikeAndStatus(String title, String location,
			String jobid, List<String> s, Pageable sortedpage);
	 
	 
	 //RefactorAPIs
	 Page<JobMaster> findByStatusIn(List<String> staus, Pageable sortedpage);
	 Page<JobMaster> findByTitleContainsAndStatusIn(String title, List<String> staus, Pageable sortedpage);
	 Page<JobMaster> findByLocationContainsAndStatusIn(String location, List<String> staus, Pageable sortedpage);
	 Page<JobMaster> findByJobTrackIdContainsAndStatusIn(String jobTrackId, List<String> staus, Pageable sortedpage);
	 Page<JobMaster> findByTitleContainsAndLocationContainsAndStatusIn(String title, String location, List<String> staus, Pageable sortedpage);
	 Page<JobMaster> findByLocationContainsAndJobTrackIdContainsAndStatusIn(String location, String jobTrackId, List<String> staus, Pageable sortedpage);
	 Page<JobMaster> findByTitleContainsAndJobTrackIdContainsAndStatusIn(String title, String jobTrackId, List<String> staus, Pageable sortedpage);
	 Page<JobMaster> findByTitleContainsAndLocationContainsAndJobTrackIdContainsAndStatusIn(String title, String location, String jobTrackId, List<String> staus, Pageable sortedpage);
	 Page<JobMaster> findByEmployerIdInAndStatusIn(List<String> employeId, List<String> staus, Pageable sortedpage);
}
