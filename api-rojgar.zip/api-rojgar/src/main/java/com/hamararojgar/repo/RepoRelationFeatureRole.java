package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hamararojgar.model.RelationFeatureRole;


@Repository
public interface RepoRelationFeatureRole extends JpaRepository<RelationFeatureRole, Long> {
	
	List<RelationFeatureRole> findByRoleCode(String roleCode);
	List<RelationFeatureRole> findByActionCode(String actionCode);

}
