package com.hamararojgar.repo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StringResultQueryMapper  implements RowMapper<String>{

	@Override
	public String mapRow(ResultSet resultSet, int i) throws SQLException {
		String title = resultSet.getString("title");
		return title;
	}

}
