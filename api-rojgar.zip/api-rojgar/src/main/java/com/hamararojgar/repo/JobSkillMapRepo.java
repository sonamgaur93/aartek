package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.JobSkillMap;

public interface JobSkillMapRepo extends JpaRepository<JobSkillMap, Long> {

	List<JobSkillMap> findByJobId(int job_id);
	
	List<JobSkillMap> findBySkillId(int skill_id);

}
