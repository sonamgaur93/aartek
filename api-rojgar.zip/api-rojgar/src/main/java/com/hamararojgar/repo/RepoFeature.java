package com.hamararojgar.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hamararojgar.model.MasterFeatureModel;

@Repository
public interface RepoFeature extends JpaRepository<MasterFeatureModel, Long> {
	MasterFeatureModel findByFeatureCode(String featureCode);
}