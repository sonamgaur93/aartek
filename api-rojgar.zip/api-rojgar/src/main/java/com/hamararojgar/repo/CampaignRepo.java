package com.hamararojgar.repo;

import java.time.Instant;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.MasterCampaign;

public interface CampaignRepo extends JpaRepository<MasterCampaign, Long> {
	
	
	MasterCampaign findCampaignByCampaignCode(String campaignCode);
	
	List<MasterCampaign> findByCampaignCodeInAndCampaignEndDateGreaterThanEqual(List<String> campaignCode,  Instant campaignEndDate);
	List<MasterCampaign> findByCampaignCodeIn(List<String> campaignCode);
	
	//if(null != campaignKey && null !=campaignStartDate && null != campaignEndDate) 
	Page<MasterCampaign> findByCampaignStartDateGreaterThanEqualAndCampaignEndDateLessThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(Instant campaignStartDate, Instant campaignEndDate, String campaignCode,String campaignName,  Pageable pageRequest);
	List<MasterCampaign> findByCampaignStartDateGreaterThanEqualAndCampaignEndDateLessThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(Instant campaignStartDate, Instant campaignEndDate, String campaignCode,String campaignName);
	
	//if(null != campaignKey && null ==campaignStartDate && null == campaignEndDate)
	Page<MasterCampaign> findByCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(String campaignCode,String campaignName,  Pageable pageRequest);
	List<MasterCampaign> findByCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(String campaignCode,String campaignName, Sort sort);
	
	//if(null != campaignKey && null !=campaignStartDate && null == campaignEndDate)
	Page<MasterCampaign> findByCampaignCodeContainsOrCampaignNameContainsAllIgnoreCaseAndCampaignStartDateGreaterThanEqual(String campaignCode,String campaignName, Instant campaignStartDate,  Pageable pageRequest);
	List<MasterCampaign> findByCampaignCodeContainsOrCampaignNameContainsAllIgnoreCaseAndCampaignStartDateGreaterThanEqual(String campaignCode,String campaignName, Instant campaignStartDate);
	
	//if(null != campaignKey && null !=campaignStartDate && null == campaignEndDate)
	Page<MasterCampaign> findByCampaignStartDateGreaterThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(Instant campaignStartDate, String campaignCode,String campaignName,  Pageable pageRequest);
	List<MasterCampaign> findByCampaignStartDateGreaterThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(Instant campaignStartDate, String campaignCode,String campaignName);
	
	//if(null != campaignKey && null !=campaignStartDate && null == campaignEndDate)
	Page<MasterCampaign> findByCampaignCodeContainsAllIgnoreCaseAndCampaignStartDateGreaterThanEqual(String campaignCode, Instant campaignStartDate,  Pageable pageRequest);
	List<MasterCampaign> findByCampaignCodeContainsAllIgnoreCaseAndCampaignStartDateGreaterThanEqual(String campaignCode, Instant campaignStartDate);

	//if (null == campaignKey && null !=campaignStartDate && null == campaignEndDate)
	Page<MasterCampaign> findAllByCampaignStartDateGreaterThanEqual(Instant campaignStartDate,  Pageable pageRequest);
	List<MasterCampaign> findAllByCampaignStartDateGreaterThanEqual(Instant campaignStartDate);
	
	//if (null == campaignKey && null ==campaignStartDate && null != campaignEndDate)
	Page<MasterCampaign> findAllByCampaignEndDateLessThanEqual(Instant campaignEndDate,  Pageable pageRequest);
	List<MasterCampaign> findAllByCampaignEndDateLessThanEqual(Instant campaignEndDate);
	
	
	//if (null != campaignKey && null ==campaignStartDate && null != campaignEndDate)
	Page<MasterCampaign> findByCampaignEndDateLessThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(Instant campaignEndDate, String campaignCode,String campaignName,  Pageable pageRequest);
	List<MasterCampaign> findByCampaignEndDateLessThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(Instant campaignEndDate, String campaignCode,String campaignName);
	
	//if (null == campaignKey && null !=campaignStartDate && null != campaignEndDate)
	Page<MasterCampaign> findByCampaignStartDateGreaterThanEqualAndCampaignEndDateLessThanEqual(Instant campaignStartDate, Instant campaignEndDate,  Pageable pageRequest);
	List<MasterCampaign> findByCampaignStartDateGreaterThanEqualAndCampaignEndDateLessThanEqual(Instant campaignStartDate, Instant campaignEndDate);

	Page<MasterCampaign> findByCampaignCodeIn(List<String> campaignCodes,  Pageable pageRequest);
}