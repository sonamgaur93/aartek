package com.hamararojgar.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.ModelLeadStatusMaster;

public interface RepoLeadStatusMaster extends JpaRepository<ModelLeadStatusMaster, Long> {

	
}
