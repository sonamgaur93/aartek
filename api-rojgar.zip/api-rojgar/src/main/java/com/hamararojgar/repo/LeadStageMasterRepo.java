package com.hamararojgar.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.LeadStageMaster;

public interface LeadStageMasterRepo extends JpaRepository<LeadStageMaster, Long> {

	
}
