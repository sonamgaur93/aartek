package com.hamararojgar.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hamararojgar.model.BusinessTypeMaster;

public interface BusinessTypeMasterRepo extends JpaRepository<BusinessTypeMaster, Long> {

	@Query(value = "select * from business_type_master where title like %?1% \n#pageable\n", countQuery = "select count(*) from business_type_master where name like %?1%", nativeQuery = true)
	Page<BusinessTypeMaster> findAllByNameLike(String name, Pageable sortedpage);

}
