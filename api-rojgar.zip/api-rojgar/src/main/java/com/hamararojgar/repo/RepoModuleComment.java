package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hamararojgar.model.ModelModuleComment;

@Repository
public interface RepoModuleComment extends JpaRepository<ModelModuleComment, Long> {
	
	List<ModelModuleComment> findByModuleNameAndRecordId(String moduleName, String recordId);
	Page<ModelModuleComment> findByModuleNameAndRecordId(String processModuleName, String recordId, Pageable paging);

}