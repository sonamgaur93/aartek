package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.LeadSkillMap;

public interface LeadSkillMapRepo extends JpaRepository<LeadSkillMap, Long> {

	List<LeadSkillMap> findByLeadId(int leadId);

	List<LeadSkillMap> findBySkillId(int parseInt);

}
