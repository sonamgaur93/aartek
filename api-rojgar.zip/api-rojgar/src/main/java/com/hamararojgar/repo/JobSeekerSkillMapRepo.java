package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.JobSeekerSkillMap;

public interface JobSeekerSkillMapRepo extends JpaRepository<JobSeekerSkillMap, Long> {

	List<JobSeekerSkillMap> findByJobSeekerId(int job_seeker_id);

	List<JobSeekerSkillMap> findBySkillId(int parseInt);

}
