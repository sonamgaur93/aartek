package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.RelationCampaignMembers;

public interface CampaignMemberRepo extends JpaRepository<RelationCampaignMembers, Long> {
	
	List<RelationCampaignMembers> getMembersByCampaignCode(Long campaignCode);
	
	List<RelationCampaignMembers> getCampaignsByMemberCode(Long memberCode);
	
	List<RelationCampaignMembers> getCampaignMembersByCampaignCodeIn(List<Long> campaignCodes);

}