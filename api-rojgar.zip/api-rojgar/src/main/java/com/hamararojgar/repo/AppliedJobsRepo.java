package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.AppliedJobs;

public interface AppliedJobsRepo extends JpaRepository<AppliedJobs, Long> {

	long countByJobIdAndJobSeekerId(int job_id, int job_seeker_id);

	Page<AppliedJobs> findByJobSeekerId(int job_seeker_id,  Pageable paging);
	List<AppliedJobs> findByJobSeekerId(int job_seeker_id);
	
	
	List<AppliedJobs> findByJobSeekerIdAndJobId(int job_seeker_id,int job_id);
	
	Page<AppliedJobs> findByJobId(int jobId,  Pageable paging);
	List<AppliedJobs> findByJobId(int jobId);
	List<AppliedJobs> findByJobIdAndTypeIgnoreCase(int jobId,String type);


}
