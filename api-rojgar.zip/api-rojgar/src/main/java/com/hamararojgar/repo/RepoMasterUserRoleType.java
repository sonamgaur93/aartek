package com.hamararojgar.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hamararojgar.model.MasterUserRoleType;


@Repository
public interface RepoMasterUserRoleType extends JpaRepository<MasterUserRoleType, Long> {
	
	MasterUserRoleType findByShortCode(String shortCode);
	MasterUserRoleType findByUserRoleName(String roleName);
}
