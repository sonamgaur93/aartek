package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hamararojgar.model.Employer;

public interface EmployerRepo extends JpaRepository<Employer, Long> {

	Employer findByEmailAndPassword(String email, String password);

	Employer findByEmail(String email);

	// Employer findByPhone(String phone);

	List<Employer> findByPhone(String phone);

	List<Employer> findByIdIn(List<Long> ids);

	@Query(value = "select * from employer_master where company like %?1% and verified IN ?2 and status IN ?3 \n#pageable\n", countQuery = "select count(*) from employer_master where company like %?1% and verified IN ?2 and status IN ?3 ", nativeQuery = true)
	Page<Employer> findAllByNameLike(String company, List<Boolean> v, List<String> s, Pageable sortedpage);

	@Query(value = "select * from employer_master where phone like %?1% and verified IN ?2 and status IN ?3  \n#pageable\n", countQuery = "select count(*) from employer_master where phone like %?1% and verified IN ?2 and status IN ?3 ", nativeQuery = true)
	Page<Employer> findAllByContactLike(String contact, List<Boolean> v, List<String> s, Pageable sortedpage);

	@Query(value = "select * from employer_master where email like %?1%  and verified IN ?2 and status IN ?3 \n#pageable\n", countQuery = "select count(*) from employer_master where email like %?1% and verified IN ?2 and status IN ?3 ", nativeQuery = true)
	Page<Employer> findAllByEmailLike(String email, List<Boolean> v, List<String> s, Pageable sortedpage);

	@Query(value = "select * from employer_master where company like %?1% and phone like %?2% and verified IN ?3 and status IN ?4 \n#pageable\n", countQuery = "select count(*) from employer_master where company like %?1% and phone like %?2% and verified IN ?3 and status IN ?4 ", nativeQuery = true)
	Page<Employer> findByNameLikeAndContactLike(String company, String contact, List<Boolean> v, List<String> s,
			Pageable sortedpage);

	@Query(value = "select * from employer_master where company like %?1% and email like %?2%  and verified IN ?3 and status IN ?4  \n#pageable\n", countQuery = "select count(*) from employer_master where company like %?1% and email like %?2% and verified IN ?3 and status IN ?4 ", nativeQuery = true)
	Page<Employer> findByNameLikeAndEmailLike(String company, String email, List<Boolean> v, List<String> s,
			Pageable sortedpage);

	@Query(value = "select * from employer_master where phone like %?1% and email like %?2%  and verified IN ?3 and status IN ?4   \n#pageable\n", countQuery = "select count(*) from employer_master where phone like %?1% and email like %?2%  and verified IN ?3 and status IN ?4 ", nativeQuery = true)
	Page<Employer> findByContactLikeAndEmailLike(String contact, String email, List<Boolean> v, List<String> s,
			Pageable sortedpage);

	@Query(value = "select * from employer_master where company like %?1% and email like %?2% and phone like %?3%  and verified IN ?4 and status IN ?5 \n#pageable\n", countQuery = "select count(*) from employer_master where company like %?1% and email like %?2% and phone like %?3%  and verified IN ?4 and status IN ?5 ", nativeQuery = true)
	Page<Employer> findByNameLikeAndEmailLikeAndContactLike(String company, String email, String contact,
			List<Boolean> v, List<String> s, Pageable sortedpage);

	@Query(value = "select * from employer_master where verified IN ?1 and status IN ?2  \n#pageable\n", countQuery = "select count(*) from employer_master where verified IN ?1 and status IN ?2", nativeQuery = true)
	Page<Employer> findByVerifiedAndStatus(List<Boolean> v, List<String> s, Pageable sortedpage);

	Page<Employer> findByVerifiedInAndStatusIn(List<Boolean> v, List<String> s, Pageable sortedpage);
	Page<Employer> findByEmailVerificationInAndStatusIn(List<Boolean> v, List<String> s, Pageable sortedpage);
	List<Employer> findAllByVerifiedInAndStatusIn(List<Boolean> v, List<String> s, Sort sort);
	List<Employer> findAllByEmailVerificationInAndStatusIn(List<Boolean> v, List<String> s, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndVerifiedAndStatus(String company, List<Boolean> v,
			List<String> s, Pageable sortedpage);
	
	Page<Employer> findAllByCompanyContainsIgnoreCaseAndEmailVerificationInAndStatusIn(String company, List<Boolean> v,
			List<String> s, Pageable sortedpage);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndVerifiedAndStatus(String companyName,
			List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndVerifiedAndStatus(String company,
			String name, List<Boolean> v, List<String> s, Pageable sortedpage);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndVerifiedAndStatus(String companyName,
			String name, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndVerifiedAndStatus(
			String company, String name, String email, List<Boolean> v, List<String> s, Pageable sortedpage);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndVerifiedAndStatus(
			String companyName, String name, String email, List<Boolean> verfiedValues, List<String> statusValues,
			Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(
			String company, String name, String email, String phone, List<Boolean> v, List<String> s,
			Pageable sortedpage);
	
	Page<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndVerifiedAndStatus(
			String company, String name, String email, String phone, List<Boolean> v, List<String> s,
			Pageable sortedpage);
	List<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(
			String companyName, String name, String email, String phone, List<Boolean> verfiedValues,
			List<String> statusValues, Sort sort);
	
	
	Page<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndVerifiedInAndStatusIn(
			String company, String name, String email, String phone, List<Boolean> v, List<String> s,
			Pageable sortedpage);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndVerifiedAndStatus(
			String companyName, String name, String email, String phone, List<Boolean> verfiedValues,
			List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndPhoneContainsAndVerifiedAndStatus(String company,
			String phone, List<Boolean> v, List<String> s, Pageable sortedpage);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndPhoneContainsAndVerifiedAndStatus(String companyName,
			String phone, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndVerifiedAndStatus(
			String company, String email, String phone, List<Boolean> v, List<String> s, Pageable sortedpage);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndVerifiedAndStatus(
			String companyName, String email, String phone, List<Boolean> verfiedValues, List<String> statusValues,
			Sort sort);

	Page<Employer> findAllByNameContainsIgnoreCaseAndVerifiedAndStatus(String name, List<Boolean> v, List<String> s,
			Pageable sortedpage);

	List<Employer> findAllByNameContainsIgnoreCaseAndVerifiedAndStatus(String name, List<Boolean> verfiedValues,
			List<String> statusValues, Sort sort);

	Page<Employer> findAllByEmailContainsIgnoreCaseAndVerifiedAndStatus(String email, List<Boolean> verfiedValues,
			List<String> statusValues, Pageable paging);

	List<Employer> findAllByEmailContainsIgnoreCaseAndVerifiedAndStatus(String email, List<Boolean> verfiedValues,
			List<String> statusValues, Sort sort);

	Page<Employer> findAllByPhoneContainsIgnoreCaseAndVerifiedAndStatus(String contact, List<Boolean> verfiedValues,
			List<String> statusValues, Pageable paging);

	List<Employer> findAllByPhoneContainsIgnoreCaseAndVerifiedAndStatus(String contact, List<Boolean> verfiedValues,
			List<String> statusValues, Sort sort);
	
	Page<Employer> findAllByCompanyContainsIgnoreCaseAndEmailContainsIgnoreCaseAndVerifiedAndStatus(String company,
			String email, List<Boolean> v, List<String> s, Pageable sortedpage);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndEmailContainsIgnoreCaseAndVerifiedAndStatus(String companyName,
			String email, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByNameContainsIgnoreCaseAndEmailContainsAndVerifiedAndStatus(String contactName,
			String email, List<Boolean> verfiedValues, List<String> statusValues, Pageable paging);

	List<Employer> findAllByNameContainsIgnoreCaseAndEmailContainsAndVerifiedAndStatus(String contactName,
			String email, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByNameContainsIgnoreCaseAndPhoneContainsAndVerifiedAndStatus(String contactName,
			String contact, List<Boolean> verfiedValues, List<String> statusValues, Pageable paging);

	List<Employer> findAllByNameContainsIgnoreCaseAndPhoneContainsAndVerifiedAndStatus(String contactName,
			String contact, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByEmailContainsIgnoreCaseAndPhoneContainsAndVerifiedAndStatus(String email, String contact,
			List<Boolean> verfiedValues, List<String> statusValues, Pageable paging);

	List<Employer> findAllByEmailContainsIgnoreCaseAndPhoneContainsAndVerifiedAndStatus(String email, String contact,
			List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsAndPhoneContainsAndVerifiedAndStatus(
			String companyName, String contactName, String contact, List<Boolean> verfiedValues,
			List<String> statusValues, Pageable paging);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsAndPhoneContainsAndVerifiedAndStatus(
			String companyName, String contactName, String contact, List<Boolean> verfiedValues,
			List<String> statusValues, Sort sort);

	Page<Employer> findAllByNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndVerifiedAndStatus(
			String contactName, String email, String contact, List<Boolean> verfiedValues, List<String> statusValues,
			Pageable paging);

	List<Employer> findAllByNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndVerifiedAndStatus(
			String contactName, String email, String contact, List<Boolean> verfiedValues, List<String> statusValues,
			Sort sort);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndEmailVerificationInAndStatusIn(String companyName,
			List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByNameContainsIgnoreCaseAndEmailVerificationInAndStatusIn(String contactName,
			List<Boolean> verfiedValues, List<String> statusValues, Pageable paging);

	List<Employer> findAllByNameContainsIgnoreCaseAndEmailVerificationInAndStatusIn(String contactName,
			List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByEmailContainsIgnoreCaseAndEmailVerificationInAndStatusIn(String email,
			List<Boolean> verfiedValues, List<String> statusValues, Pageable paging);

	List<Employer> findAllByEmailContainsIgnoreCaseAndEmailVerificationInAndStatusIn(String email,
			List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByPhoneContainsIgnoreCaseAndEmailVerificationInAndStatusIn(String contact,
			List<Boolean> verfiedValues, List<String> statusValues, Pageable paging);

	List<Employer> findAllByPhoneContainsIgnoreCaseAndEmailVerificationInAndStatusIn(String contact,
			List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailVerificationInAndStatusIn(
			String companyName, String contactName, List<Boolean> verfiedValues, List<String> statusValues,
			Pageable paging);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailVerificationInAndStatusIn(
			String companyName, String contactName, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndEmailContainsIgnoreCaseAndEmailVerificationInAndStatusIn(
			String companyName, String email, List<Boolean> verfiedValues, List<String> statusValues, Pageable paging);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndEmailContainsIgnoreCaseAndEmailVerificationInAndStatusIn(
			String companyName, String email, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(
			String companyName, String contact, List<Boolean> verfiedValues, List<String> statusValues,
			Pageable paging);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(
			String companyName, String contact, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByNameContainsIgnoreCaseAndEmailContainsAndEmailVerificationInAndStatusIn(String contactName,
			String email, List<Boolean> verfiedValues, List<String> statusValues, Pageable paging);

	List<Employer> findAllByNameContainsIgnoreCaseAndEmailContainsAndEmailVerificationInAndStatusIn(String contactName,
			String email, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByNameContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(String contactName,
			String contact, List<Boolean> verfiedValues, List<String> statusValues, Pageable paging);

	List<Employer> findAllByNameContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(String contactName,
			String contact, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByEmailContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(String email,
			String contact, List<Boolean> verfiedValues, List<String> statusValues, Pageable paging);

	List<Employer> findAllByEmailContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(String email,
			String contact, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndEmailVerificationInAndStatusIn(
			String companyName, String contactName, String email, List<Boolean> verfiedValues,
			List<String> statusValues, Pageable paging);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndEmailVerificationInAndStatusIn(
			String companyName, String contactName, String email, List<Boolean> verfiedValues,
			List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(
			String companyName, String contactName, String contact, List<Boolean> verfiedValues,
			List<String> statusValues, Pageable paging);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndNameContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(
			String companyName, String contactName, String contact, List<Boolean> verfiedValues,
			List<String> statusValues, Sort sort);

	Page<Employer> findAllByCompanyContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(
			String companyName, String email, String contact, List<Boolean> verfiedValues, List<String> statusValues,
			Pageable paging);

	List<Employer> findAllByCompanyContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(
			String companyName, String email, String contact, List<Boolean> verfiedValues, List<String> statusValues,
			Sort sort);

	Page<Employer> findAllByNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(
			String contactName, String email, String contact, List<Boolean> verfiedValues, List<String> statusValues,
			Pageable paging);

	List<Employer> findAllByNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(
			String contactName, String email, String contact, List<Boolean> verfiedValues, List<String> statusValues,
			Sort sort);
}
