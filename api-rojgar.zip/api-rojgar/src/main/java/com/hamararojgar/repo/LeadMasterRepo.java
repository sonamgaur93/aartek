package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hamararojgar.model.LeadMaster;

public interface LeadMasterRepo extends JpaRepository<LeadMaster, Long> {

	List<LeadMaster> findByAgentId(int agentId);

	@Query(value = "select * from lead_master where type IN ?1 and priority IN ?2 and status IN ?3 and stage IN ?4 \n#pageable\n",
            countQuery = "select count(*) from lead_master where type IN ?1 and priority IN ?2 and status IN ?3 and stage IN ?4",
            nativeQuery = true)
	Page<LeadMaster> findByTypeAndPriorityAndStatus(List<String> t, List<String> p, List<String> s,List<String> st,
			Pageable sortedpage);

	@Query(value = "select * from lead_master where agent_name like %?1% and type IN ?2 and priority IN ?3 and status IN ?4  and stage IN ?5 \n#pageable\n",
            countQuery = "select count(*) from lead_master where agent_name like %?1% and type IN ?2 and priority IN ?3 and status IN ?4 and stage IN ?5 ",
            nativeQuery = true)
	Page<LeadMaster> findAllByAgentNameLike(String agentname, List<String> t, List<String> p, List<String> s,List<String> st,
			Pageable sortedpage);

	@Query(value = "select * from lead_master where date BETWEEN ?1 AND ?2 and type IN ?3 and priority IN ?4 and status IN ?5  and stage IN ?6  \n#pageable\n",
            countQuery = "select count(*) from lead_master where date BETWEEN ?1 AND ?2 and type IN ?3 and priority IN ?4 and status IN ?5  and stage IN ?6 ",
            nativeQuery = true)
	Page<LeadMaster> findAllByDate(String startDate,String endDate, List<String> t, List<String> p, List<String> s,List<String> st, Pageable sortedpage);

	@Query(value = "select * from lead_master where agent_name like %?1% and type IN ?2 and priority IN ?3 and status IN ?4  and stage IN ?5  and date BETWEEN ?6 AND ?7 \n#pageable\n",
            countQuery = "select count(*) from lead_master where agent_name like %?1% and type IN ?2 and priority IN ?3 and status IN ?4   and stage IN ?5 and date BETWEEN ?6 AND ?7",
            nativeQuery = true)
	Page<LeadMaster> findAllByAgentNameLikeAndDate(String agentname, List<String> t, List<String> p, List<String> s,List<String> st,
			String startDate, String endDate, Pageable sortedpage);

	
	@Query(value="select * from lead_master where agent_id = ?1 and date BETWEEN ?2 AND ?3 and type = ?4", nativeQuery = true)
	List<LeadMaster> findByAgentIdDateAndType(int agentId, String fromDate, String toDate, String type);

	@Query(value="select * from lead_master where agent_id = ?1 and date BETWEEN ?2 AND ?3", nativeQuery = true)
	List<LeadMaster> findByAgentIdDate(int agentId, String fromDate, String toDate);


}
