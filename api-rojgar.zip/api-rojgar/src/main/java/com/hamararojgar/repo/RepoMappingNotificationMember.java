package com.hamararojgar.repo;


import java.time.Instant;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hamararojgar.model.ModelMappingNotificationMember;

@Repository
public interface RepoMappingNotificationMember extends JpaRepository<ModelMappingNotificationMember, Long> {

	List<ModelMappingNotificationMember> findAllByEntryDateTimeGreaterThanEqualAndMemberCodeInAndMemberTypeIn(
			Instant instant, List<String> memberCodes, List<String> memberTypes);
	

}
