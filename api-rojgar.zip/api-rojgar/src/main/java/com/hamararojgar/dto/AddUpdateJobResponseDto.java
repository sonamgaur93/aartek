package com.hamararojgar.dto;

import com.hamararojgar.model.JobMaster;

public class AddUpdateJobResponseDto extends ResponseDTO{

	JobMaster  jobMaster;

	public JobMaster getJobMaster() {
		return jobMaster;
	}

	public void setJobMaster(JobMaster jobMaster) {
		this.jobMaster = jobMaster;
	}
	
}
