package com.hamararojgar.dto;

import java.util.List;

public class JobSeekerListByJobDto extends ResponseDTO{

	List<AppliedCandidateDto> appliedCandidateList;

	public List<AppliedCandidateDto> getAppliedCandidateList() {
		return appliedCandidateList;
	}

	public void setAppliedCandidateList(List<AppliedCandidateDto> appliedCandidateList) {
		this.appliedCandidateList = appliedCandidateList;
	}
	
	
	
}
