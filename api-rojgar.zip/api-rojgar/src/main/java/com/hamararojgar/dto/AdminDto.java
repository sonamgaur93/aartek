package com.hamararojgar.dto;

import org.springframework.web.multipart.MultipartFile;

public class AdminDto {
	private String id;
	private String username;
	private String email;
	private String password;
	private String passwords;
	private String role;
	private String status;
	private String profilePicUrl;
	private MultipartFile profile_multipart;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPasswords() {
		return passwords;
	}
	public void setPasswords(String passwords) {
		this.passwords = passwords;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getProfilePicUrl() {
		return profilePicUrl;
	}
	public void setProfilePicUrl(String profilePicUrl) {
		this.profilePicUrl = profilePicUrl;
	}
	public MultipartFile getProfile_multipart() {
		return profile_multipart;
	}
	public void setProfile_multipart(MultipartFile profile_multipart) {
		this.profile_multipart = profile_multipart;
	}
	
	
}
