package com.hamararojgar.dto;

public class ResponseDTOLead {
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLeadType() {
		return leadType;
	}
	public void setLeadType(String leadType) {
		this.leadType = leadType;
	}
	public String getLeadCompanyName() {
		return leadCompanyName;
	}
	public void setLeadCompanyName(String leadCompanyName) {
		this.leadCompanyName = leadCompanyName;
	}
	public String getLeadMemberName() {
		return leadMemberName;
	}
	public void setLeadMemberName(String leadMemberName) {
		this.leadMemberName = leadMemberName;
	}
	private Long id;
	private String leadType;
	private String leadCompanyName;
	private String leadMemberName;
}
