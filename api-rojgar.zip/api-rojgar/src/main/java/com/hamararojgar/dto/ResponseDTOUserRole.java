package com.hamararojgar.dto;

import org.springframework.data.annotation.Transient;

public class ResponseDTOUserRole {
	

	public String getShortCode() {
		return shortCode;
	}

	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}

	public String getUserRoleName() {
		return userRoleName;
	}

	public void setUserRoleName(String userRoleName) {
		this.userRoleName = userRoleName;
	}

	
	@Transient
	private Long id;

	private String shortCode;

	private String userRoleName;

}
