package com.hamararojgar.dto;

import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.BreakIterator;


public class EmployerDto {

	

	public Date getRegisteredDateTime() {
		return registeredDateTime;
	}

	public void setRegisteredDateTime(Date registeredDateTime) {
		this.registeredDateTime = registeredDateTime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		
		if(null != name && !name.isEmpty()) {
			return UCharacter.toTitleCase(name, BreakIterator.getTitleInstance());
		}
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCompany() {
		if(null != company && !company.isEmpty()) {
			return UCharacter.toTitleCase(company, BreakIterator.getTitleInstance());
		}
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getGst() {
		return gst;
	}

	public void setGst(String gst) {
		this.gst = gst;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRecordingUrl() {
		return recordingUrl;
	}

	public void setRecordingUrl(String recordingUrl) {
		this.recordingUrl = recordingUrl;
	}

	public String getCompanyImage() {
		return companyImage;
	}

	public void setCompanyImage(String companyImage) {
		this.companyImage = companyImage;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getVerified() {
		return verified;
	}

	public void setVerified(Boolean verified) {
		this.verified = verified;
	}

	public String getCompanyImage2() {
		return companyImage2;
	}

	public void setCompanyImage2(String companyImage2) {
		this.companyImage2 = companyImage2;
	}

	public String getCompanyImage3() {
		return companyImage3;
	}

	public void setCompanyImage3(String companyImage3) {
		this.companyImage3 = companyImage3;
	}

	public String getCompanyImage4() {
		return companyImage4;
	}

	public void setCompanyImage4(String companyImage4) {
		this.companyImage4 = companyImage4;
	}

	public String getCompanyImage5() {
		return companyImage5;
	}

	public void setCompanyImage5(String companyImage5) {
		this.companyImage5 = companyImage5;
	}

	public MultipartFile getCompany_image_multipart() {
		return company_image_multipart;
	}

	public void setCompany_image_multipart(MultipartFile company_image_multipart) {
		this.company_image_multipart = company_image_multipart;
	}

	public MultipartFile getCompany_image2_multipart() {
		return company_image2_multipart;
	}

	public void setCompany_image2_multipart(MultipartFile company_image2_multipart) {
		this.company_image2_multipart = company_image2_multipart;
	}

	public MultipartFile getCompany_image3_multipart() {
		return company_image3_multipart;
	}

	public void setCompany_image3_multipart(MultipartFile company_image3_multipart) {
		this.company_image3_multipart = company_image3_multipart;
	}

	public MultipartFile getCompany_image4_multipart() {
		return company_image4_multipart;
	}

	public void setCompany_image4_multipart(MultipartFile company_image4_multipart) {
		this.company_image4_multipart = company_image4_multipart;
	}

	public MultipartFile getCompany_image5_multipart() {
		return company_image5_multipart;
	}

	public void setCompany_image5_multipart(MultipartFile company_image5_multipart) {
		this.company_image5_multipart = company_image5_multipart;
	}

	public Boolean getMobileVerification() {
		return mobileVerification;
	}

	public void setMobileVerification(Boolean mobileVerification) {
		this.mobileVerification = mobileVerification;
	}

	public Boolean getEmailVerification() {
		return emailVerification;
	}

	public void setEmailVerification(Boolean emailVerification) {
		this.emailVerification = emailVerification;
	}
	
	public String getCreatedFromLeadId() {
		return createdFromLeadId;
	}
	public void setCreatedFromLeadId(String createdFromLeadId) {
		this.createdFromLeadId = createdFromLeadId;
	}
	
	

	public Boolean getAccountVerification() {
		return accountVerification;
	}

	public void setAccountVerification(Boolean accountVerification) {
		this.accountVerification = accountVerification;
	}
	
	public Long getLeadId() {
		return leadId;
	}

	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	
	public List<JobMasterDto> getJobList() {
		return jobList;
	}

	public void setJobList(List<JobMasterDto> jobList) {
		this.jobList = jobList;
	}
	
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public String getBusinessTypeName() {
		return businessTypeName;
	}

	public void setBusinessTypeName(String businessTypeName) {
		this.businessTypeName = businessTypeName;
	}

	@Override
	public String toString() {
		return "EmployerDto [id=" + id + ", email=" + email + ", phone=" + phone + ", password=" + password + ", name="
				+ name + ", company=" + company + ", address=" + address + ", pan=" + pan + ", gst=" + gst
				+ ", businessType=" + businessType + ", description=" + description + ", recordingUrl=" + recordingUrl
				+ ", companyImage=" + companyImage + ", companyImage2=" + companyImage2 + ", companyImage3="
				+ companyImage3 + ", companyImage4=" + companyImage4 + ", companyImage5=" + companyImage5
				+ ", deviceToken=" + deviceToken + ", status=" + status + ", verified=" + verified
				+ ", mobileVerification=" + mobileVerification + ", emailVerification=" + emailVerification
				+ ", company_image_multipart=" + company_image_multipart + ", company_image2_multipart="
				+ company_image2_multipart + ", company_image3_multipart=" + company_image3_multipart
				+ ", company_image4_multipart=" + company_image4_multipart + ", company_image5_multipart="
				+ company_image5_multipart + ", registeredDateTime=" + registeredDateTime + "]";
	}
	
	private Long id;
	private String email;
	private String phone;
	private String password;
	private String name;
	private String company;
	private String address;
	private String pan;
	private String gst;
	private String businessType;
	private String description;
	private String recordingUrl;
	private String companyImage;
	private String companyImage2;
	private String companyImage3;
	private String companyImage4;
	private String companyImage5;
	private String deviceToken; 
	private String status; 
	private Boolean verified; 
	private Boolean mobileVerification;
	private Boolean emailVerification;
	private MultipartFile company_image_multipart;
	private MultipartFile company_image2_multipart;
	private MultipartFile company_image3_multipart;
	private MultipartFile company_image4_multipart;
	private MultipartFile company_image5_multipart;
	private Date registeredDateTime;
	
	private String createdFromLeadId;
	private Boolean accountVerification;
	private Long leadId;
	
	private List<JobMasterDto> jobList;
	
	private String comment;
	
	private String businessTypeName;
}
