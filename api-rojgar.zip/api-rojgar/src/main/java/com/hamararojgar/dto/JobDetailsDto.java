package com.hamararojgar.dto;

import java.util.List;

import com.hamararojgar.model.SkillMaster;

public class JobDetailsDto {

	private Long id;
	private String title;
	private String contact;
	private int openings;
	private String experience;
	private String location;
	private String componsation;
	private String job_type;
	private String accomodation;
	private String food;
	private String leave_policy;
	private String status;
	private String description;
	private String recording_url;
	private int employerId;
	private List<SkillMaster> skills;

	public List<SkillMaster> getSkills() {
		return skills;
	}

	public void setSkills(List<SkillMaster> skills) {
		this.skills = skills;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getOpenings() {
		return openings;
	}

	public void setOpenings(int openings) {
		this.openings = openings;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getComponsation() {
		return componsation;
	}

	public void setComponsation(String componsation) {
		this.componsation = componsation;
	}

	public String getJob_type() {
		return job_type;
	}

	public void setJob_type(String job_type) {
		this.job_type = job_type;
	}

	public String getAccomodation() {
		return accomodation;
	}

	public void setAccomodation(String accomodation) {
		this.accomodation = accomodation;
	}

	public String getFood() {
		return food;
	}

	public void setFood(String food) {
		this.food = food;
	}

	public String getLeave_policy() {
		return leave_policy;
	}

	public void setLeave_policy(String leave_policy) {
		this.leave_policy = leave_policy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRecording_url() {
		return recording_url;
	}

	public void setRecording_url(String recording_url) {
		this.recording_url = recording_url;
	}

	public int getEmployerId() {
		return employerId;
	}

	public void setEmployerId(int employerId) {
		this.employerId = employerId;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
	
}
