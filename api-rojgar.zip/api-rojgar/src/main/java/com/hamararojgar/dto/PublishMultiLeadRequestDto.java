package com.hamararojgar.dto;

public class PublishMultiLeadRequestDto {

	private Long idArr[];

	public Long[] getIdArr() {
		return idArr;
	}

	public void setIdArr(Long[] idArr) {
		this.idArr = idArr;
	}
	
	
}
