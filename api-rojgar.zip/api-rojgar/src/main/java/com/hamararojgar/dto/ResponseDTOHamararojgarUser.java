package com.hamararojgar.dto;

import java.util.List;

public class ResponseDTOHamararojgarUser {
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public List<ResponseDTOFeature> getFeatures() {
		return features;
	}
	public void setFeatures(List<ResponseDTOFeature> features) {
		this.features = features;
	}

	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
	

	@Override
	public String toString() {
		return "ResponseDTOHamararojgarUser [id=" + id + ", username=" + username + ", email=" + email + ", role="
				+ role + ", status=" + status + ", features=" + features + ", roleName=" + roleName + "]";
	}



	private Long id;
	private String username;
	private String email;
	private String role;
	private String status; 
	private List<ResponseDTOFeature> features;
	private String roleName;

}
