package com.hamararojgar.dto;

public class VerificatioResponseDto {

	private boolean verified;

	public boolean isVerified() {
		return verified;
	}

	public void setVerified(boolean verified) {
		this.verified = verified;
	}
	
	
}
