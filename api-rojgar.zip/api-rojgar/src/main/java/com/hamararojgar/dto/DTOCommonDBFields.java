package com.hamararojgar.dto;

import java.time.Instant;

public abstract class DTOCommonDBFields {
	
	public Instant getEntryDateTime() {
		return entryDateTime;
	}
	public void setEntryDateTime(Instant entryDateTime) {
		this.entryDateTime = entryDateTime;
	}
	public Instant getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(Instant updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	
	@Override
	public String toString() {
		return "CommonDBFields [entryDateTime=" + entryDateTime + ", updateDateTime=" + updateDateTime + "]";
	}
	
	private Instant entryDateTime;
	private Instant updateDateTime;
	private Long id;
	
}