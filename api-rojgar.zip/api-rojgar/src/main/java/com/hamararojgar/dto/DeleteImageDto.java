package com.hamararojgar.dto;

public class DeleteImageDto {

	private int employerId;
	private int imageKey;
	
	public int getEmployerId() {
		return employerId;
	}
	public void setEmployerId(int employerId) {
		this.employerId = employerId;
	}
	public int getImageKey() {
		return imageKey;
	}
	public void setImageKey(int imageKey) {
		this.imageKey = imageKey;
	}
	
	
	
}
