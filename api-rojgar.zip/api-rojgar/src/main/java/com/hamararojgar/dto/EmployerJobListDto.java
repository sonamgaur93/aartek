package com.hamararojgar.dto;

import java.util.List;

public class EmployerJobListDto extends ResponseDTO{

	List<JobMasterDto> jobList;

	public List<JobMasterDto> getJobList() {
		return jobList;
	}

	public void setJobList(List<JobMasterDto> jobList) {
		this.jobList = jobList;
	}
	
	

	
	
	
}
