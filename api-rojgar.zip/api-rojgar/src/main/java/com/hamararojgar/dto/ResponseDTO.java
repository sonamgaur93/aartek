package com.hamararojgar.dto;

import java.util.Date;

public class ResponseDTO {

	private String responseCode = "";
	private String responseDescription = "";
	private Date responseTime;
	
	public Date getResponseTime() {
		if(null == responseTime)
			responseTime= new Date();
		return responseTime;
	}

	public void setResponseTime(Date responseTime) {
		this.responseTime = responseTime;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseDescription() {
		return responseDescription;
	}

	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	
}
