package com.hamararojgar.dto;

import java.util.List;

public class ResponseDTOJobSeeker extends DTOCommonDBFields{

	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public List<ResponseDTORojgarJobApplied> getAppliedJobs() {
		return appliedJobs;
	}
	public void setAppliedJobs(List<ResponseDTORojgarJobApplied> appliedJobs) {
		this.appliedJobs = appliedJobs;
	}

	private String contact; 
	private String name;
	private String email;
	private List<ResponseDTORojgarJobApplied> appliedJobs;
	
}
