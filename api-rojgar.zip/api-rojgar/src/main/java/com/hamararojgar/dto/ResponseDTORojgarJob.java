package com.hamararojgar.dto;

import java.util.List;
import java.util.Set;

public class ResponseDTORojgarJob extends DTOCommonDBFields {

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public int getOpenings() {
		return openings;
	}

	public void setOpenings(int openings) {
		this.openings = openings;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getComponsation() {
		return componsation;
	}

	public void setComponsation(String componsation) {
		this.componsation = componsation;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getAccomodation() {
		return accomodation;
	}

	public void setAccomodation(String accomodation) {
		this.accomodation = accomodation;
	}

	public String getFood() {
		return food;
	}

	public void setFood(String food) {
		this.food = food;
	}

	public String getLeavePolicy() {
		return leavePolicy;
	}

	public void setLeavePolicy(String leavePolicy) {
		this.leavePolicy = leavePolicy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRecordingURL() {
		return recordingURL;
	}

	public void setRecordingURL(String recordingURL) {
		this.recordingURL = recordingURL;
	}

	public EmployerDto getEmployer() {
		return employer;
	}

	public void setEmployer(EmployerDto employer) {
		this.employer = employer;
	}

	public List<ResponseDTOJobSeeker> getSeekers() {
		return seekers;
	}

	public void setSeekers(List<ResponseDTOJobSeeker> seekers) {
		this.seekers = seekers;
	}

	public Set<Integer> getApplied() {
		return applied;
	}

	public void setApplied(Set<Integer> applied) {
		this.applied = applied;
	}

	public Set<Integer> getInvited() {
		return invited;
	}

	public void setInvited(Set<Integer> invited) {
		this.invited = invited;
	}

	private String title;
	private String contact;
	private int openings;
	private String experience;
	private String location;
	private String componsation;
	private String jobType;
	private String accomodation;
	private String food;
	private String leavePolicy;
	private String status;
	private String description;
	private String recordingURL;
	private EmployerDto employer;
	private List<ResponseDTOJobSeeker> seekers;
	private Set<Integer> applied;
	private Set<Integer> invited;

}