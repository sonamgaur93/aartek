package com.hamararojgar.dto;

import java.time.Instant;

import org.springframework.web.multipart.MultipartFile;

public class UserDto {

	private Long id;
	private String username;
	private String email;
	private String password;
	private String passwords;
	private String role;
	private String status;
	private String profilePicUrl;
	private MultipartFile profile_multipart;
	private Instant entryDateTime;
	
	private Instant updateDateTime;
	
	private String platform;
	private String updateByPerson;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPasswords() {
		return passwords;
	}
	public void setPasswords(String passwords) {
		this.passwords = passwords;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getProfilePicUrl() {
		return profilePicUrl;
	}
	public void setProfilePicUrl(String profilePicUrl) {
		this.profilePicUrl = profilePicUrl;
	}
	public MultipartFile getProfile_multipart() {
		return profile_multipart;
	}
	public void setProfile_multipart(MultipartFile profile_multipart) {
		this.profile_multipart = profile_multipart;
	}
	public Instant getEntryDateTime() {
		return entryDateTime;
	}
	public void setEntryDateTime(Instant entryDateTime) {
		this.entryDateTime = entryDateTime;
	}
	public Instant getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(Instant updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	
	
	public String getPlatform() {
		return platform;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	public String getUpdateByPerson() {
		return updateByPerson;
	}
	public void setUpdateByPerson(String updateByPerson) {
		this.updateByPerson = updateByPerson;
	}
	
	
}
