package com.hamararojgar.dto;

import com.hamararojgar.model.JobSeekerMasterDto;
import com.hamararojgar.model.ResponseDto;

public class AddProfileResponseDto extends ResponseDto{

	JobSeekerMasterDto jobSeeker;

	public JobSeekerMasterDto getJobSeeker() {
		return jobSeeker;
	}

	public void setJobSeeker(JobSeekerMasterDto jobSeeker) {
		this.jobSeeker = jobSeeker;
	}

	@Override
	public String toString() {
		return "AddProfileResponseDto [jobSeeker=" + jobSeeker + "]";
	}
	
	
	
}
