package com.hamararojgar.dto;

import java.util.List;


public class NotificationDto extends ResponseDTO{

	List<ResponseNotification> notificationList;

	public List<ResponseNotification> getNotificationList() {
		return notificationList;
	}

	public void setNotificationList(List<ResponseNotification> notificationList) {
		this.notificationList = notificationList;
	}
	
}
