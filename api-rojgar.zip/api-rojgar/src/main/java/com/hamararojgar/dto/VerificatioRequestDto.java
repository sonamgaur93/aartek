package com.hamararojgar.dto;

public class VerificatioRequestDto {

	private String contact_no;

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	
	
}
