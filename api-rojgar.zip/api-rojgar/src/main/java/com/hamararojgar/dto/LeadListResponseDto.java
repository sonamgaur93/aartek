package com.hamararojgar.dto;

import java.util.List;

import com.hamararojgar.model.LeadMaster;

public class LeadListResponseDto extends ResponseDTO{

	List<LeadMaster> leadList;

	public List<LeadMaster> getLeadList() {
		return leadList;
	}

	public void setLeadList(List<LeadMaster> leadList) {
		this.leadList = leadList;
	}
	
	
}
