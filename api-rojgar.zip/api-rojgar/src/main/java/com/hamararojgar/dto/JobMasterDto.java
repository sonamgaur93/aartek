package com.hamararojgar.dto;

import java.sql.Timestamp;
import java.util.Date;

public class JobMasterDto extends ResponseDTO{

	private Long id;
	private String title;
	private String skills;
	private String contact;
	private String date;
	private int openings;
	private String experience;
	private String location;
	
	private String componsation;
	private String job_type;
	private String accomodation;
	private String food;
	private String leave_policy;
	private String status;
	private String description;
	private String recording_url;
	private String employerId;
	private int appliedJobId;
	private int unreadMessagesByJobSeeker;
	private int unreadMessagesByEmployer;
	private boolean chatStarted;
	private String appliedDate;
	private String appliedJobType;
	private Date lastMessagetime;
	private String jobTrackId;
	
	private String locationId;
	
	private EmployerDto company;
	
	public int getAppliedJobId() {
		return appliedJobId;
	}
	public void setAppliedJobId(int appliedJobId) {
		this.appliedJobId = appliedJobId;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public int getOpenings() {
		return openings;
	}
	public void setOpenings(int openings) {
		this.openings = openings;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getComponsation() {
		return componsation;
	}
	public void setComponsation(String componsation) {
		this.componsation = componsation;
	}
	public String getJob_type() {
		return job_type;
	}
	public void setJob_type(String job_type) {
		this.job_type = job_type;
	}
	public String getAccomodation() {
		return accomodation;
	}
	public void setAccomodation(String accomodation) {
		this.accomodation = accomodation;
	}
	public String getFood() {
		return food;
	}
	public void setFood(String food) {
		this.food = food;
	}
	public String getLeave_policy() {
		return leave_policy;
	}
	public void setLeave_policy(String leave_policy) {
		this.leave_policy = leave_policy;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRecording_url() {
		return recording_url;
	}
	public void setRecording_url(String recording_url) {
		this.recording_url = recording_url;
	}
	
	public String getEmployerId() {
		return employerId;
	}
	public void setEmployerId(String employerId) {
		this.employerId = employerId;
	}
	public boolean isChatStarted() {
		return chatStarted;
	}
	public void setChatStarted(boolean chatStarted) {
		this.chatStarted = chatStarted;
	}
	public int getUnreadMessagesByJobSeeker() {
		return unreadMessagesByJobSeeker;
	}
	public void setUnreadMessagesByJobSeeker(int unreadMessagesByJobSeeker) {
		this.unreadMessagesByJobSeeker = unreadMessagesByJobSeeker;
	}
	public int getUnreadMessagesByEmployer() {
		return unreadMessagesByEmployer;
	}
	public void setUnreadMessagesByEmployer(int unreadMessagesByEmployer) {
		this.unreadMessagesByEmployer = unreadMessagesByEmployer;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getAppliedDate() {
		return appliedDate;
	}
	public void setAppliedDate(String appliedDate) {
		this.appliedDate = appliedDate;
	}
	public String getAppliedJobType() {
		return appliedJobType;
	}
	public void setAppliedJobType(String appliedJobType) {
		this.appliedJobType = appliedJobType;
	}
	public Date getLastMessagetime() {
		return lastMessagetime;
	}
	public void setLastMessagetime(Date lastMessagetime) {
		this.lastMessagetime = lastMessagetime;
	}
	public String getJobTrackId() {
		return jobTrackId;
	}
	public void setJobTrackId(String jobTrackId) {
		this.jobTrackId = jobTrackId;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public EmployerDto getCompany() {
		return company;
	}
	public void setCompany(EmployerDto company) {
		this.company = company;
	}
	
	
}