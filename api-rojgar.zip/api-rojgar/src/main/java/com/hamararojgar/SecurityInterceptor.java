package com.hamararojgar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

@Component
public class SecurityInterceptor extends HandlerInterceptorAdapter {

	private static final Logger requrl = LogManager.getLogger("requrl-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) throws Exception {
		try {
			requrl.info("Request URL:: " + req.getRequestURL().toString());
		} catch (Exception e) {
			exceptionLog.error("Exception in Request Interceptor : " + e.getMessage());
			e.printStackTrace();
		}
		return true;
	}
}