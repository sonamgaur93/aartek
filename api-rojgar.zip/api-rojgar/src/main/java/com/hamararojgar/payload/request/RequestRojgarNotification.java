package com.hamararojgar.payload.request;

import java.util.Arrays;

public class RequestRojgarNotification{
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getNotificationTime() {
		return notificationTime;
	}
	public void setNotificationTime(String notificationTime) {
		this.notificationTime = notificationTime;
	}
	public Long[] getCampaignCodes() {
		return campaignCodes;
	}
	public void setCampaignCodes(Long[] campaignCodes) {
		this.campaignCodes = campaignCodes;
	}
	public Long[] getMemberCodes() {
		return memberCodes;
	}
	public void setMemberCodes(Long[] memberCodes) {
		this.memberCodes = memberCodes;
	}
	
	
	
	@Override
	public String toString() {
		return "RequestRojgarNotification [title=" + title + ", description=" + description + ", userType=" + userType
				+ ", notificationTime=" + notificationTime + ", campaignCodes=" + Arrays.toString(campaignCodes)
				+ ", memberCodes=" + Arrays.toString(memberCodes) + "]";
	}



	private String title;
	private String description;
	private String userType;
	private String notificationTime;
	private Long[] campaignCodes;
	private Long[] memberCodes;
}