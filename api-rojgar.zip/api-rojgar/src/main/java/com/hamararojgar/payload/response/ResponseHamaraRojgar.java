package com.hamararojgar.payload.response;

import com.hamararojgar.dto.ResponseDTO;

public class ResponseHamaraRojgar extends ResponseDTO{
	
	
	public ResponseHamararojgarContent getContent() {
		return content;
	}

	public void setContent(ResponseHamararojgarContent content) {
		this.content = content;
	}

	private ResponseHamararojgarContent content;

}
