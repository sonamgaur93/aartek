package com.hamararojgar.payload.request;

import java.util.Arrays;

public class RequestRojgarSearchParameter{
	
	public Integer getSize() {
		return size;
	}
	public void setSize(Integer size) {
		this.size = size;
	}
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	public Long[] getCampaignCodes() {
		return campaignCodes;
	}
	public void setCampaignCodes(Long[] campaignCodes) {
		this.campaignCodes = campaignCodes;
	}
	public String[] getUserTypes() {
		return userTypes;
	}
	public void setUserTypes(String[] userTypes) {
		this.userTypes = userTypes;
	}
	
	@Override
	public String toString() {
		return "RequestRojgarUserSearchParameter [size=" + size + ", page=" + page + ", campaignCodes="
				+ Arrays.toString(campaignCodes) + ", userTypes=" + Arrays.toString(userTypes) + "]";
	}


	private Integer size;
	private Integer page;
	private Long[] campaignCodes;
	private String[] userTypes;
}