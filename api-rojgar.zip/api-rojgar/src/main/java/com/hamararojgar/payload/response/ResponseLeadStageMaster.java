package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.DTOLeadStageMaster;

public class ResponseLeadStageMaster extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	public List<DTOLeadStageMaster> getLeadStages() {
		return leadStages;
	}
	public void setLeadStages(List<DTOLeadStageMaster> leadStages) {
		this.leadStages = leadStages;
	}
	public DTOLeadStageMaster getLeadStage() {
		return leadStage;
	}
	public void setLeadStage(DTOLeadStageMaster leadStage) {
		this.leadStage = leadStage;
	}
	
	private List<DTOLeadStageMaster> leadStages;
	private DTOLeadStageMaster leadStage;
}