package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.ResponseDTOHamararojgarUser;
import com.hamararojgar.dto.ResponseDTORojgarMember;

public class ResponseRojgarMember extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	public List<ResponseDTORojgarMember> getMembers() {
		return members;
	}
	public void setMembers(List<ResponseDTORojgarMember> members) {
		this.members = members;
	}
	public ResponseDTORojgarMember getMember() {
		return member;
	}
	public void setMember(ResponseDTORojgarMember member) {
		this.member = member;
	}
	private List<ResponseDTORojgarMember> members;
	private ResponseDTORojgarMember member;
}