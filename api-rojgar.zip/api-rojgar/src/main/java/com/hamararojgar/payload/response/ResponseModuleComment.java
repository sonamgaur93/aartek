package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.ResponseDTOModuleComment;

public class ResponseModuleComment extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	private List<ResponseDTOModuleComment> comments;

	public List<ResponseDTOModuleComment> getComments() {
		return comments;
	}

	public void setComments(List<ResponseDTOModuleComment> comments) {
		this.comments = comments;
	}
}