package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.ResponseDTOJobSeeker;

public class ResponseJobSeeker extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {

	public ResponseDTOJobSeeker getJobSeeker() {
		return jobSeeker;
	}
	public void setJobSeeker(ResponseDTOJobSeeker jobSeeker) {
		this.jobSeeker = jobSeeker;
	}
	public List<ResponseDTOJobSeeker> getJobSeekers() {
		return jobSeekers;
	}
	public void setJobSeekers(List<ResponseDTOJobSeeker> jobSeekers) {
		this.jobSeekers = jobSeekers;
	}
	private ResponseDTOJobSeeker jobSeeker;
	private List<ResponseDTOJobSeeker> jobSeekers;
}