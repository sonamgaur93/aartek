package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.ResponseDTOUserRole;

public class ResponseUserRole extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	public List<ResponseDTOUserRole> getUserRoles() {
		return userRoles;
	}
	public void setUserRoles(List<ResponseDTOUserRole> userRoles) {
		this.userRoles = userRoles;
	}
	public ResponseDTOUserRole getUserRole() {
		return userRole;
	}
	public void setUserRole(ResponseDTOUserRole userRole) {
		this.userRole = userRole;
	}
	
	private List<ResponseDTOUserRole> userRoles;
	private ResponseDTOUserRole userRole;

}
