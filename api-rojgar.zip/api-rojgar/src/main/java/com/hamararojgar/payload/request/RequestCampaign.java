package com.hamararojgar.payload.request;

import java.util.List;
import java.util.Set;

public class RequestCampaign {
	
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}
	public String getCampaignName() {
		return campaignName;
	}
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}
	public String getCampaignDescription() {
		return campaignDescription;
	}
	public void setCampaignDescription(String campaignDescription) {
		this.campaignDescription = campaignDescription;
	}
	public Integer getCampaignType() {
		return campaignType;
	}
	public void setCampaignType(Integer campaignType) {
		this.campaignType = campaignType;
	}
	public String getCampaignStartDate() {
		return campaignStartDate;
	}
	public void setCampaignStartDate(String campaignStartDate) {
		this.campaignStartDate = campaignStartDate;
	}
	public String getCampaignEndDate() {
		return campaignEndDate;
	}
	public void setCampaignEndDate(String campaignEndDate) {
		this.campaignEndDate = campaignEndDate;
	}
	public String getCampaignStatus() {
		return campaignStatus;
	}
	public void setCampaignStatus(String campaignStatus) {
		this.campaignStatus = campaignStatus;
	}
	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	
	

	public Set<Long> getMembers() {
		return members;
	}
	public void setMembers(Set<Long> members) {
		this.members = members;
	}



	private String campaignCode;
	private String campaignName;
	private String campaignDescription;
	private Integer campaignType;
	private String campaignStartDate;
	private String campaignEndDate;
	private String campaignStatus;
	private String action;
	
	private Set<Long> members;
	

}
