package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOCampaign;
import com.hamararojgar.dto.DTOHamaraRojgarPagination;

public class ResponseCampaign extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	public List<DTOCampaign> getCampaigns() {
		return campaigns;
	}
	public void setCampaigns(List<DTOCampaign> campaigns) {
		this.campaigns = campaigns;
	}
	public DTOCampaign getCampaign() {
		return campaign;
	}
	public void setCampaign(DTOCampaign campaign) {
		this.campaign = campaign;
	}
	private List<DTOCampaign> campaigns;
	private DTOCampaign campaign;
	
}
