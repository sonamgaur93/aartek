package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.ResponseDTORefferal;

public class ResponseUser extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent{
	

	public List<ResponseDTORefferal> getUsers() {
		return users;
	}

	public void setUsers(List<ResponseDTORefferal> users) {
		this.users = users;
	}
	
	private List<ResponseDTORefferal> users;

}
