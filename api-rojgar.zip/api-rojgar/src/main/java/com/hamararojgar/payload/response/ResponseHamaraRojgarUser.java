package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.ResponseDTOHamararojgarUser;

public class ResponseHamaraRojgarUser extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	public List<ResponseDTOHamararojgarUser> getUsers() {
		return users;
	}
	public void setUsers(List<ResponseDTOHamararojgarUser> users) {
		this.users = users;
	}
	public ResponseDTOHamararojgarUser getUser() {
		return user;
	}
	public void setUser(ResponseDTOHamararojgarUser user) {
		this.user = user;
	}
	
	private List<ResponseDTOHamararojgarUser> users;
	private ResponseDTOHamararojgarUser user;
}