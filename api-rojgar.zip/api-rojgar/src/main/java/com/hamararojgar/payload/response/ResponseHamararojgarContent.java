package com.hamararojgar.payload.response;

public interface ResponseHamararojgarContent {

}
