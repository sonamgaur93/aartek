package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.DTOLeadStatusMaster;
import com.hamararojgar.dto.ResponseDTOLeadStatus;

public class ResponseLeadStatus extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	public List<DTOLeadStatusMaster> getLeadStatusList() {
		return leadStatusList;
	}
	public void setLeadStatusList(List<DTOLeadStatusMaster> leadStatusList) {
		this.leadStatusList = leadStatusList;
	}
	public DTOLeadStatusMaster getLeadStatus() {
		return leadStatus;
	}
	public void setLeadStatus(DTOLeadStatusMaster leadStatus) {
		this.leadStatus = leadStatus;
	}
	
	private List<DTOLeadStatusMaster> leadStatusList;
	private DTOLeadStatusMaster leadStatus;
}
