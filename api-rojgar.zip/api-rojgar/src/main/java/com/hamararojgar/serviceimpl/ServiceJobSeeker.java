package com.hamararojgar.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.EmployerDto;
import com.hamararojgar.dto.JobSeekerDto;
import com.hamararojgar.dto.ResponseDTOJobSeeker;
import com.hamararojgar.dto.ResponseDTORojgarJob;
import com.hamararojgar.dto.ResponseDTORojgarJobApplied;
import com.hamararojgar.model.AppliedJobs;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.JobMaster;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.payload.response.ResponseEmployer;
import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.payload.response.ResponseJobSeeker;
import com.hamararojgar.repo.AppliedJobsRepo;
import com.hamararojgar.repo.EmployerRepo;
import com.hamararojgar.repo.JobMasterRepo;
import com.hamararojgar.repo.JobSeekerMasterRepo;


@Service
public class ServiceJobSeeker {
	
	private static final Logger log = LogManager.getLogger(ServiceJobSeeker.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");
	
	@Autowired
	JobSeekerMasterRepo jobSeekerMasterRepo;
	
	@Autowired
	AppliedJobsRepo appliedJobsRepo;
	
	@Autowired
	JobMasterRepo jobMasterRepo;
	
	@Autowired
	ServiceEmployer serviceEmployer;

	public ResponseHamaraRojgar getSeekers(Map<String, String> searchParameters) {
		reqLog.info("getSeekers called");
		Sort sort = Sort.by("name").ascending();
		Pageable paging = null;
		Integer size = null;
		Integer pageNumber = null;
		try {
			size = Integer.valueOf(searchParameters.get("size"));
			pageNumber = Integer.valueOf(searchParameters.get("page"));
			paging = PageRequest.of(pageNumber, size, sort);
		}catch(Exception exception) {
			
		}
		
		String contactName = searchParameters.get("name");
		contactName = (null == contactName? "": contactName.trim());
		
		String email = searchParameters.get("email");
		email = (null == email? "": email.trim());
		
		String contact = searchParameters.get("contact");
		contact = (null == contact? "": contact.trim());
		
		List<String> statusValues = new ArrayList<>();
		String status = searchParameters.get("status");
		if(null == status || status.trim().isEmpty()) {
			status = "ALL";
		}
		
		if("ALL".equalsIgnoreCase(status)){
			statusValues.add("ACTIVE");
			statusValues.add("IN-ACTIVE");
			statusValues.add("BLOCKED");
		}else {
			statusValues.add(status);
		}
		
		List<Boolean> verfiedValues = new ArrayList<>();
		
		String verified = searchParameters.get("verified");
		if(null == verified || verified.trim().isEmpty()) {
			verified = "ALL";
		}
		if("ALL".equalsIgnoreCase(verified)){
			verfiedValues.add(true);
			verfiedValues.add(false);
		}else if(verified.equalsIgnoreCase("Verified")){
			verfiedValues.add(true);
		}else if(verified.equalsIgnoreCase("Not Verified")){
			verfiedValues.add(false);
		}
		
		List<JobSeekerMaster> jobSeekerMasters = null;
		Page<JobSeekerMaster> jobSeekerMasterPageList = null;
		
		if(contactName.isEmpty() && email.isEmpty() && contact.isEmpty()){
			if(null != paging) {
				jobSeekerMasterPageList = jobSeekerMasterRepo.findByVerifiedAndStatus(verfiedValues,statusValues,paging);
				jobSeekerMasters = jobSeekerMasterPageList.getContent();
			}else {
				jobSeekerMasters = jobSeekerMasterRepo.findByVerifiedAndStatus(verfiedValues,statusValues,sort);
			}
		}else if(!contactName.isEmpty() && !email.isEmpty() && !contact.isEmpty()){
			if(null != paging) {
				jobSeekerMasterPageList = jobSeekerMasterRepo.findByNameLikeAndEmailLikeAndContactLike(contactName, email, contact,verfiedValues,statusValues, paging);
				jobSeekerMasters = jobSeekerMasterPageList.getContent();
			}else {
				jobSeekerMasters = jobSeekerMasterRepo.findByNameLikeAndEmailLikeAndContactLike(contactName, email, contact,verfiedValues,statusValues, sort);
			}
		}else if(!contactName.isEmpty() && email.isEmpty() && contact.isEmpty()){
			if(null != paging) {
				jobSeekerMasterPageList = jobSeekerMasterRepo.findAllByNameLike(contactName,verfiedValues,statusValues,paging);
				jobSeekerMasters = jobSeekerMasterPageList.getContent();
			}else {
				jobSeekerMasters = jobSeekerMasterRepo.findAllByNameLike(contactName, verfiedValues,statusValues, sort);
			}
		}else if(contactName.isEmpty() && !email.isEmpty() && contact.isEmpty()){
			if(null != paging) {
				jobSeekerMasterPageList = jobSeekerMasterRepo.findAllByEmailLike(email,verfiedValues,statusValues,paging);
				jobSeekerMasters = jobSeekerMasterPageList.getContent();
			}else {
				jobSeekerMasters = jobSeekerMasterRepo.findAllByEmailLike(email, verfiedValues,statusValues, sort);
			}
		}else if(contactName.isEmpty() && email.isEmpty() && !contact.isEmpty()){
			if(null != paging) {
				jobSeekerMasterPageList = jobSeekerMasterRepo.findAllByContactLike(contact,verfiedValues,statusValues,paging);
				jobSeekerMasters = jobSeekerMasterPageList.getContent();
			}else {
				jobSeekerMasters = jobSeekerMasterRepo.findAllByContactLike(contact, verfiedValues,statusValues, sort);
			}
		}else if(!contactName.isEmpty() && email.isEmpty() && !contact.isEmpty()){
			if(null != paging) {
				jobSeekerMasterPageList = jobSeekerMasterRepo.findByNameLikeAndContactLike(contactName, contact,verfiedValues,statusValues,paging);
				jobSeekerMasters = jobSeekerMasterPageList.getContent();
			}else {
				jobSeekerMasters = jobSeekerMasterRepo.findByNameLikeAndContactLike(contactName, contact, verfiedValues,statusValues, sort);
			}
		}else if(!contactName.isEmpty() && !email.isEmpty() && contact.isEmpty()){
			if(null != paging) {
				jobSeekerMasterPageList = jobSeekerMasterRepo.findByNameLikeAndEmailLike(contactName, email,verfiedValues,statusValues,paging);
				jobSeekerMasters = jobSeekerMasterPageList.getContent();
			}else {
				jobSeekerMasters = jobSeekerMasterRepo.findByNameLikeAndEmailLike(contactName, email, verfiedValues,statusValues, sort);
			}
		}else if(contactName.isEmpty() && !email.isEmpty() && !contact.isEmpty()){
			if(null != paging) {
				jobSeekerMasterPageList = jobSeekerMasterRepo.findByContactLikeAndEmailLike(contact, email,verfiedValues,statusValues,paging);
				jobSeekerMasters = jobSeekerMasterPageList.getContent();
			}else {
				jobSeekerMasters = jobSeekerMasterRepo.findByContactLikeAndEmailLike(contact, email, verfiedValues,statusValues, sort);
			}
		}
		
		if(null != paging) {
			jobSeekerMasterPageList = jobSeekerMasterRepo.findAll(paging);
			jobSeekerMasters = jobSeekerMasterPageList.getContent();
		}else {
			jobSeekerMasters = jobSeekerMasterRepo.findAll(sort);
		}
		
		if(null == jobSeekerMasters) {
			return null;
		}
		
		ResponseJobSeeker responseJobSeeker = new ResponseJobSeeker();
		if(null != jobSeekerMasterPageList) {
			responseJobSeeker.setCurrentPage(jobSeekerMasterPageList.getNumber());
			responseJobSeeker.setTotalItems(jobSeekerMasterPageList.getNumberOfElements());
			responseJobSeeker.setTotalPages(jobSeekerMasterPageList.getTotalPages());
		}else {
			responseJobSeeker.setCurrentPage(1);
			responseJobSeeker.setTotalItems(jobSeekerMasters.size());
			responseJobSeeker.setTotalPages(1);
		}
		List<ResponseDTOJobSeeker> responseSeekers = new ArrayList<ResponseDTOJobSeeker>();
		for (JobSeekerMaster jobSeekerMaster : jobSeekerMasters) {
			ResponseDTOJobSeeker responseDTOJobSeeker = new ResponseDTOJobSeeker();
			responseDTOJobSeeker.setId(jobSeekerMaster.getId());
			responseDTOJobSeeker.setName(jobSeekerMaster.getName());
			responseSeekers.add(responseDTOJobSeeker);
		}
		responseJobSeeker.setJobSeekers(responseSeekers);
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		responseHamaraRojgar.setContent(responseJobSeeker);
		responseHamaraRojgar.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
		responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		return responseHamaraRojgar;
	}
	
	public ResponseJobSeeker getAppliedJobs(String seekerId, Map<String, String> searchParameters) {
		JobSeekerDto  jobSeekerDto = getJobSeekerById(seekerId);
		if(null == jobSeekerDto) {
			return null;		
		}

		ResponseJobSeeker responseJobSeeker = new ResponseJobSeeker();
		ResponseDTOJobSeeker responseDTOJobSeeker = new ResponseDTOJobSeeker();
		responseDTOJobSeeker.setId(Long.valueOf(jobSeekerDto.getId()));
		responseDTOJobSeeker.setContact(jobSeekerDto.getContact());
		responseDTOJobSeeker.setName(jobSeekerDto.getName());
		
		Pageable pageable = null;
		Integer size = null;
		Integer pageNumber = null;
		try {
			size = Integer.valueOf(searchParameters.get("size"));
			pageNumber = Integer.valueOf(searchParameters.get("page"));
		}catch(Exception exception) {
			
		}
		if (null != size && size >= 1) {
			if (null == pageNumber || pageNumber < 0) {
				pageNumber = 0;
			}
			pageable = PageRequest.of(pageNumber, size);
		}
		Page<AppliedJobs> appliedJobsPage = null;
		List<AppliedJobs> masterAppliedJobs = null;
		
		if(null != pageable) {
			appliedJobsPage = appliedJobsRepo.findByJobSeekerId(jobSeekerDto.getId(), pageable );	
		}else {
			masterAppliedJobs = appliedJobsRepo.findByJobSeekerId(jobSeekerDto.getId());
		}

		if( null != appliedJobsPage) {
			masterAppliedJobs = appliedJobsPage.getContent();
			responseJobSeeker.setCurrentPage(appliedJobsPage.getNumber());
			responseJobSeeker.setTotalItems(appliedJobsPage.getNumberOfElements());
			responseJobSeeker.setTotalPages(appliedJobsPage.getTotalPages());
		}else if(null != masterAppliedJobs) {
			responseJobSeeker.setCurrentPage(1);
			responseJobSeeker.setTotalItems(masterAppliedJobs.size());
			responseJobSeeker.setTotalPages(1);
		}
		List<ResponseDTORojgarJobApplied> appliedJobs = new ArrayList<ResponseDTORojgarJobApplied>();
		for (AppliedJobs appliedJob: masterAppliedJobs) {
			ResponseDTORojgarJobApplied responseDTORojgarJobApplied = new ResponseDTORojgarJobApplied();
			responseDTORojgarJobApplied.setAppliedDate(appliedJob.getDate());
			ResponseDTORojgarJob job = buildResponseDTORojgarJobApplied(appliedJob);
			responseDTORojgarJobApplied.setJob(job );
			appliedJobs.add(responseDTORojgarJobApplied);
		}
		responseDTOJobSeeker.setAppliedJobs(appliedJobs );
		responseJobSeeker.setJobSeeker(responseDTOJobSeeker);
		return responseJobSeeker;
	}

	private ResponseDTORojgarJob buildResponseDTORojgarJobApplied(AppliedJobs appliedJob) {
		Optional<JobMaster> jobMasterOptional = jobMasterRepo.findById(Long.valueOf(appliedJob.getJobId()));
		if(!jobMasterOptional.isPresent()) {
			return null;
		}
		JobMaster jobMaster = jobMasterOptional.get();
		ResponseDTORojgarJob responseDTORojgarJob = new ResponseDTORojgarJob();
		responseDTORojgarJob.setTitle(jobMaster.getTitle());
		EmployerDto employer = serviceEmployer.getEmployer(Long.parseLong(jobMaster.getEmployerId()));
		responseDTORojgarJob.setEmployer(employer );
		return responseDTORojgarJob;
	}
	private JobSeekerDto getJobSeekerById(String seekerId) {
		JobSeekerDto jobSeekerDto = null;
		try {
			Optional<JobSeekerMaster> jobSeekerMaster = jobSeekerMasterRepo.findById(Long.parseLong(seekerId));
			if(!jobSeekerMaster.isPresent()){
				return null;
			}
			jobSeekerDto = new JobSeekerDto();
			JobSeekerMaster jobSeeker = jobSeekerMaster.get();
			jobSeekerDto.setAddress(jobSeeker.getAddress());
			jobSeekerDto.setAdhaar_image_url(jobSeeker.getAdhaar_image_url());
			jobSeekerDto.setAvailability(jobSeeker.getAvailability());
			jobSeekerDto.setContact(jobSeeker.getContact());
			jobSeekerDto.setCurrent_location(jobSeeker.getCurrent_location());
			jobSeekerDto.setExpected_compensation(jobSeeker.getExpected_compensation());
			jobSeekerDto.setExpected_salary(jobSeeker.getExpected_salary());
			jobSeekerDto.setExperience(jobSeeker.getExperience());
			jobSeekerDto.setFather_name(jobSeeker.getFather_name());
			jobSeekerDto.setId(jobSeeker.getId().intValue());
			jobSeekerDto.setMessage(jobSeeker.getMessage());
			jobSeekerDto.setName(jobSeeker.getName());
			jobSeekerDto.setPreferred_location(jobSeeker.getPreferred_location());
			jobSeekerDto.setProfile_pic_url(jobSeeker.getProfile_pic_url());
			jobSeekerDto.setRecording_url(jobSeeker.getRecording_url());
			jobSeekerDto.setStatus(jobSeeker.getStatus());
			jobSeekerDto.setEmail(jobSeeker.getEmail());
			jobSeekerDto.setVerified(jobSeeker.getVerified());
			jobSeekerDto.setEmailVerification(jobSeeker.getEmailVerification());
			jobSeekerDto.setMobileVerification(jobSeeker.getMobileVerification());
			jobSeekerDto.setAccountVerification(jobSeeker.getAccountVerification());
		} catch (Exception e) { 
			jobSeekerDto = null;
		}
		return jobSeekerDto;
	}


	
}