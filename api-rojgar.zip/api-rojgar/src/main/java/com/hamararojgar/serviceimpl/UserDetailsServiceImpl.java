package com.hamararojgar.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hamararojgar.dto.ResponseDTOUserRole;
import com.hamararojgar.dto.UserDto;
import com.hamararojgar.model.MasterUserRoleType;
import com.hamararojgar.model.User;
import com.hamararojgar.payload.response.ResponseHamaraRojgarUser;
import com.hamararojgar.payload.response.ResponseUserRole;
import com.hamararojgar.repo.UserRepo;


@Service
public class UserDetailsServiceImpl implements UserDetailsService {
	
	@Autowired
	PasswordEncoder encoder;
	
	@Autowired
	UserRepo userRepo;
	
	@Override
	@Transactional
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		User user = userRepo.findByEmail(email);
		ObjectMapper mapper = new ObjectMapper();
		UserDto userDto = mapper.convertValue(user, UserDto.class);
		userDto.setPassword(encoder.encode(userDto.getPassword()));
		return UserDetailsImpl.build(userDto);
	}
	
	

}