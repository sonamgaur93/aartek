package com.hamararojgar.serviceimpl;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.AddUpdateJobDto;
import com.hamararojgar.dto.AppliedCandidateDto;
import com.hamararojgar.dto.ChatReadDto;
import com.hamararojgar.dto.EmployerDto;
import com.hamararojgar.dto.EmployerLoginRequestDto;
import com.hamararojgar.dto.InviteForJobDto;
import com.hamararojgar.dto.JobMasterDto;
import com.hamararojgar.dto.LeadDto;
import com.hamararojgar.dto.SaveJobChat;
import com.hamararojgar.dto.UpdateDeviceTokenDTO;
import com.hamararojgar.dto.UpdateProfileEmployerDto;
import com.hamararojgar.model.AddJobSeekerDto;
import com.hamararojgar.model.AppliedCandidateQueryMapper;
import com.hamararojgar.model.AppliedJobChatMaster;
import com.hamararojgar.model.AppliedJobMasterQueryMapper;
import com.hamararojgar.model.AppliedJobs;
import com.hamararojgar.model.ApplyJobDto;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.JobListDto;
import com.hamararojgar.model.JobMaster;
import com.hamararojgar.model.JobMasterQueryMapper;
import com.hamararojgar.model.JobSeekerIdDto;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.JobSeekerMasterDto;
import com.hamararojgar.model.JobSeekerMasterQueryMapper;
import com.hamararojgar.model.JobSeekerSkillMap;
import com.hamararojgar.model.JobSkillMap;
import com.hamararojgar.model.MasterCampaign;
import com.hamararojgar.model.UserOtp;
import com.hamararojgar.model.VerifyUserDto;
import com.hamararojgar.payload.response.ResponseEmployer;
import com.hamararojgar.payload.response.ResponseJobSeeker;
import com.hamararojgar.repo.AppliedJobChatMasterRepo;
import com.hamararojgar.repo.AppliedJobsRepo;
import com.hamararojgar.repo.EmployerRepo;
import com.hamararojgar.repo.JobMasterRepo;
import com.hamararojgar.repo.JobSeekerMasterRepo;
import com.hamararojgar.repo.JobSeekerSkillMapRepo;
import com.hamararojgar.repo.JobSkillMapRepo;
import com.hamararojgar.repo.StringResultQueryMapper;
import com.hamararojgar.repo.UserOtpRepo;
import com.hamararojgar.util.RojgarConstantProperties;
import com.hamararojgar.util.Util;

@Service
public class JobSeekerService {

	private static final Logger log = LogManager.getLogger(JobSeekerService.class);
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	private JobSeekerMasterRepo jobSeekerMasterRepo;

	@Autowired
	private JobMasterRepo jobMasterRepo;

	@Autowired
	private JobSeekerSkillMapRepo jobSeekerSkillMapRepo;

	@Autowired
	private AppliedJobsRepo appliedJobsRepo;

	@Autowired
	private AWSS3Service awss3Service;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	JobSkillMapRepo jobSkillMapRepo;

	@Autowired
	AppliedJobChatMasterRepo appliedJobChatMasterRepo;

	@Autowired
	EmployerRepo employerRepo;

	@Autowired
	UserOtpRepo userOtpRepo;

	@Autowired
	AsyncService asyncService;

	@Autowired
	private Util util;

	@Autowired
	private RojgarConstantProperties constantProperties;

	@Autowired
	private ServiceLeadMaster serviceLeadMaster;

	@Autowired
	private ServiceCampaign serviceCampaign;

	public int addEditProfile(AddJobSeekerDto addJobSeekerDto) {
		int result = 0;
		try {
			boolean createNew = isNewJobSeekerData(addJobSeekerDto);
			if (createNew) {
				result = createNewJobSeekerData(addJobSeekerDto);
			} else {
				result = updateJobSeekerData(addJobSeekerDto);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public Optional<JobSeekerMaster> getJobSeekerProfileDetails(Long id) {
		return jobSeekerMasterRepo.findById(id);
	}

	public List<JobMasterDto> getJobList(JobListDto jobListDto) {
		List<JobMasterDto> jobList = new ArrayList<JobMasterDto>();
		try {
			String location = "";
			if (jobListDto.getLocation() != null && !jobListDto.getLocation().equalsIgnoreCase("")) {
				location = " AND location='" + jobListDto.getLocation() + "'";
			}
			if (jobListDto.getSkills() != null && !jobListDto.getSkills().equalsIgnoreCase("")) {
				Set<Integer> jobIdSet = new HashSet<>();
				String skillArr[] = jobListDto.getSkills().split(",");
				if (skillArr.length > 0) {
					for (String s : skillArr) {
						List<JobSkillMap> mapList = jobSkillMapRepo.findBySkillId(Integer.parseInt(s));
						for (JobSkillMap map : mapList) {
							jobIdSet.add(map.getJob_id());
						}
					}
				}
				if (jobIdSet.size() > 0) {
					String jobIdQuery = " id IN (";
					for (Integer id : jobIdSet) {
						jobIdQuery = jobIdQuery + id + ",";
					}
					jobIdQuery = jobIdQuery.substring(0, jobIdQuery.length() - 1);
					jobIdQuery = jobIdQuery + " )";
					if (!location.equalsIgnoreCase("")) {
						location = location + " AND " + jobIdQuery;
					} else {
						location = location + " AND " + jobIdQuery;

					}
				}

			}

			jobList = jdbcTemplate.query("SELECT * from job_master where status='Open' " + location + " ;",
					new JobMasterQueryMapper());
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobList;
	}

	public List<JobMasterDto> getJobs(JobListDto jobListDto) {
		List<JobMasterDto> jobList = new ArrayList<JobMasterDto>();
		try {
			StringBuilder query = new StringBuilder("SELECT * from job_master where status='Open' ");
			try {
				if (null != jobListDto.getLocations()) {
					String locationCluase = convertStringArrayToString(jobListDto.getLocations(), "',");
					if (null != locationCluase) {
						query.append("AND location in (");
						query.append(locationCluase);
						query.append(")");
					}

				}
			} catch (Exception exception) {

			}

			try {
				if (null != jobListDto.getnSkills()) {
					Set<Integer> jobIdSet = new HashSet<>();
					for (Integer skillId : jobListDto.getnSkills()) {
						List<JobSkillMap> mapList = jobSkillMapRepo.findBySkillId(skillId);
						for (JobSkillMap map : mapList) {
							jobIdSet.add(map.getJob_id());
						}
					}

					if (jobIdSet.size() > 0) {
						StringBuilder jobIdQuery = new StringBuilder();
						jobIdQuery.append(" id IN (");
						for (Integer id : jobIdSet) {
							jobIdQuery.append(id).append(",");
						}
						query.append("AND");
						query.append(jobIdQuery.substring(0, jobIdQuery.length() - 1));
						query.append(")");
					}

				}
			} catch (Exception exception) {

			}

			query.append(";");

			jobList = jdbcTemplate.query(query.toString(), new JobMasterQueryMapper());

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobList;
	}

	public Optional<JobMaster> getJobDetails(Long id) {
		return jobMasterRepo.findById(id);
	}

	public String applyForJob(ApplyJobDto applyJobDto) {
		String result = ServerConstants.FAILURERESPONSEDESC;
		try {
			Optional<JobSeekerMaster> jsm = jobSeekerMasterRepo.findById((long) applyJobDto.getJob_seeker_id());

			if (jsm.isPresent()) {
				if (jsm.get().getStatus().equalsIgnoreCase("ACTIVE")) {
					long count = appliedJobsRepo.countByJobIdAndJobSeekerId(applyJobDto.getJob_id(),
							applyJobDto.getJob_seeker_id());
					if (count == 0) {
						AppliedJobs appliedJobs = new AppliedJobs();
						appliedJobs.setJobId(applyJobDto.getJob_id());
						appliedJobs.setJobSeekerId(applyJobDto.getJob_seeker_id());
						appliedJobs.setDate(util.getCurrentDateString());
						appliedJobs.setType("Applied");
						appliedJobsRepo.save(appliedJobs);
						result = ServerConstants.SUCCESRESPONSEDESC;
					} else {
						List<AppliedJobs> ajList = appliedJobsRepo
								.findByJobSeekerIdAndJobId(applyJobDto.getJob_seeker_id(), applyJobDto.getJob_id());
						if (ajList.size() == 1) {
							AppliedJobs aj = ajList.get(0);
							if (aj.getType() != null && aj.getType().equalsIgnoreCase("Invited")) {
								aj.setType("Applied");
								appliedJobsRepo.save(aj);
								result = ServerConstants.SUCCESRESPONSEDESC;
							} else {
								result = ServerConstants.ALREADYAPPLIED;
							}
						}
					}
				} else {
					result = "Job Seeker is Not Active/Verified";
				}

			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public List<JobMasterDto> getAppliedJobList(JobSeekerIdDto jobSeekerIdDto) {
		List<JobMasterDto> jobList = new ArrayList<>();
		try {
			if (jobSeekerIdDto.getJob_seeker_id() != 0) {
				String query = "select aj.id as appliedJobId, aj.date as appliedDate, aj.type as appliedJobType ,  jm.id,jm.accomodation,jm.componsation,jm.description,jm.food,jm.job_type,jm.leave_policy,jm.location,jm.openings,jm.recording_url,jm.skills,jm.status,jm.title,jm.contact,jm.employer_id,jm.experience from applied_jobs as aj  inner join job_master as jm on  aj.job_id=jm.id where job_seeker_id="
						+ jobSeekerIdDto.getJob_seeker_id() + ";";
				jobList = jdbcTemplate.query(query, new AppliedJobMasterQueryMapper());
				/*
				 * List<AppliedJobs> appliedJobList =
				 * appliedJobsRepo.findByJobSeekerId(jobSeekerIdDto. getJob_seeker_id());
				 * if(appliedJobList!=null && appliedJobList.size() > 0){ String idString = "";
				 * for(AppliedJobs appliedJobs : appliedJobList){ idString =
				 * idString+appliedJobs.getJobId()+","; } idString = idString.substring(0,
				 * idString.length() - 1); jobList =
				 * jdbcTemplate.query("SELECT * from job_master where id IN (" +idString+")",
				 * new JobMasterQueryMapper()); }
				 */
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobList;
	}

	public boolean verifyUserByEmail(VerifyUserDto verifyUserDto) {
		try {
			UserOtp userOtp = userOtpRepo.findTop1ByEmailOrderByIdDesc(verifyUserDto.getEmail());
			System.out.println("USer OTP:: " + userOtp);
			if (null != userOtp) {
				if (verifyUserDto.getOtp().equalsIgnoreCase(userOtp.getOtp())
						&& !"verified".equalsIgnoreCase(userOtp.getStatus())) {

					jdbcTemplate.update("update user_otp set status='verified' where id=" + userOtp.getId());
					return true;
				}
			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return false;
	}

	public int verifyUserRegistrationMobileOTP(VerifyUserDto verifyUserDto) {
		int result = 0;
		try {
			if (verifyUserDto.getContact_no() != null && !verifyUserDto.getContact_no().equalsIgnoreCase("")
					&& verifyUserDto.getOtp() != null && !verifyUserDto.getOtp().equalsIgnoreCase("")) {

				UserOtp userOtp = userOtpRepo.findByPhone(verifyUserDto.getContact_no());

				if (userOtp != null) {

					if (verifyUserDto.getOtp().equalsIgnoreCase(userOtp.getOtp())) {
						result = Integer.MAX_VALUE;
						jdbcTemplate.update("delete from user_otp where phone='" + verifyUserDto.getContact_no() + "'");
					}
				}
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public int verifyUser(VerifyUserDto verifyUserDto) {
		int result = 0;
		try {
			if (null == verifyUserDto.getContact_no() || verifyUserDto.getContact_no().trim().isEmpty()
					|| null == verifyUserDto.getOtp() || verifyUserDto.getOtp().trim().isEmpty()) {
				return result;
			}

			UserOtp userOtp = userOtpRepo.findByPhone(verifyUserDto.getContact_no());

			if (null == userOtp) {
				return result;
			}
			if (!verifyUserDto.getOtp().equalsIgnoreCase(userOtp.getOtp())) {
				return result;
			}

			JobSeekerMaster jobSeekerDB = null;
			Optional<JobSeekerMaster> jobSeekerO = jobSeekerMasterRepo
					.findById((long) verifyUserDto.getJob_seeker_id());

			if (jobSeekerO.isPresent()) {
				jobSeekerDB = jobSeekerO.get();
				JobSeekerMaster jm = null;
				jm = jobSeekerMasterRepo.findByContactAndMobileVerification(verifyUserDto.getContact_no(), true);
				if (jm != null) {
					if (jm.getId() == jobSeekerDB.getId()) {
						result = jobSeekerDB.getId().intValue();
						jdbcTemplate
								.update("update job_seeker_master set verified=true, mobile_verification=true where id="
										+ result);
						jdbcTemplate.update("delete from user_otp where phone='" + verifyUserDto.getContact_no() + "'");
					} else {
						result = jm.getId().intValue();
						jdbcTemplate.update("delete from user_otp where phone='" + verifyUserDto.getContact_no() + "'");
					}
				} else {
					result = jobSeekerDB.getId().intValue();
					jdbcTemplate.update(
							"update job_seeker_master set verified=true , mobile_verification=true where id=" + result);
					jdbcTemplate.update("delete from user_otp where phone='" + verifyUserDto.getContact_no() + "'");
				}
			} else {
				JobSeekerMaster jm = null;
				jm = jobSeekerMasterRepo.findByContactAndMobileVerification(verifyUserDto.getContact_no(), true);
				if (jm != null) {
					result = jm.getId().intValue();
					jdbcTemplate.update(
							"update job_seeker_master set verified=true , mobile_verification=true where id=" + result);
					jdbcTemplate.update("delete from user_otp where phone='" + verifyUserDto.getContact_no() + "'");
				}
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public String saveJobChatMessage(SaveJobChat jobSeekerIdDto) {
		String result = ServerConstants.FAILURERESPONSEDESC;
		try {
			AppliedJobChatMaster appliedJobChatMaster = new AppliedJobChatMaster();
			appliedJobChatMaster.setAppliedJobId(jobSeekerIdDto.getAppliedJobId());
			appliedJobChatMaster.setType(jobSeekerIdDto.getType());
			if (jobSeekerIdDto.getType().equalsIgnoreCase("text")) {
				appliedJobChatMaster.setMessage(jobSeekerIdDto.getMessage());
			}
			appliedJobChatMaster.setMessageBy(jobSeekerIdDto.getMessageBy());
			appliedJobChatMaster.setName(jobSeekerIdDto.getName());
			appliedJobChatMaster.setTime(new Date());
			if (jobSeekerIdDto.getMessageBy().equalsIgnoreCase("Employer")) {
				appliedJobChatMaster.setReadByEmployer(true);
				appliedJobChatMaster.setReadByJobSeeker(false);
			} else {
				appliedJobChatMaster.setReadByJobSeeker(true);
				appliedJobChatMaster.setReadByEmployer(false);
			}
			appliedJobChatMasterRepo.save(appliedJobChatMaster);
			if (!jobSeekerIdDto.getType().equalsIgnoreCase("text")) {
				if (jobSeekerIdDto.getFile() != null) {
					String imageUrl = saveChatMessageFile(jobSeekerIdDto.getFile(), appliedJobChatMaster.getId());
					appliedJobChatMaster.setImageUrl(constantProperties.getBaseURLChatImages() + imageUrl);
					appliedJobChatMasterRepo.save(appliedJobChatMaster);
				}
			}
			asyncService.sendPushNotification(jobSeekerIdDto);

			result = ServerConstants.SUCCESRESPONSEDESC;
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public String chatReadUpdate(ChatReadDto jobSeekerIdDto) {
		String result = ServerConstants.FAILURERESPONSEDESC;
		try {
			Optional<AppliedJobChatMaster> data = appliedJobChatMasterRepo.findById((long) jobSeekerIdDto.getChatId());
			if (data.isPresent()) {
				AppliedJobChatMaster appliedJobChatMaster = data.get();
				if (jobSeekerIdDto.isReadByEmployer()) {
					appliedJobChatMaster.setReadByEmployer(true);
				}
				if (jobSeekerIdDto.isReadByJobSeeker()) {
					appliedJobChatMaster.setReadByJobSeeker(true);
				}
				appliedJobChatMasterRepo.save(appliedJobChatMaster);
				result = ServerConstants.SUCCESRESPONSEDESC;
			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public int getUnreadMessageCountJobSeeker(int appliedJobId) {
		int result = 0;
		try {
			result = jdbcTemplate.queryForObject("SELECT count(*) FROM applied_job_chat_master where applied_job_id="
					+ appliedJobId + " and read_by_job_seeker=false ;", Integer.class);
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public boolean checkChatStatus(int appliedJobId) {
		boolean result = false;
		try {
			int count = jdbcTemplate.queryForObject(
					"SELECT count(*) FROM applied_job_chat_master where applied_job_id=" + appliedJobId + ";",
					Integer.class);
			if (count > 0) {
				result = true;
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public int getUnreadMessageCountEmployer(int appliedJobId) {
		int result = 0;
		try {
			result = jdbcTemplate.queryForObject("SELECT count(*) FROM applied_job_chat_master where applied_job_id="
					+ appliedJobId + " and read_by_employer=false ;", Integer.class);
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public Employer employerLoginCheck(EmployerLoginRequestDto requestDto) {
		Employer employer = null;
		try {
			// employer = employerRepo.findByEmailAndPassword(requestDto.getEmail(),
			// requestDto.getPassword());
			employer = employerRepo.findByEmail(requestDto.getEmail());
			if (null != employer && util.validateUserPassword(requestDto.getPassword(), employer.getPassword())) {
				if (requestDto.getDeviceToken() != null) {
					employer.setDeviceToken(requestDto.getDeviceToken());
					employerRepo.save(employer);
				}
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return employer;
	}

	public Employer updateEmplyerProfile(UpdateProfileEmployerDto updateProfileEmployerDto) {
		Employer employer = null;
		try {
			Optional<Employer> emp = employerRepo.findById((long) updateProfileEmployerDto.getEmployerId());
			if (emp.isPresent()) {
				employer = emp.get();
				if (updateProfileEmployerDto.getEmail() != null
						&& !updateProfileEmployerDto.getEmail().equalsIgnoreCase("")) {
					employer.setEmail(updateProfileEmployerDto.getEmail());
				}
				employer.setPhone(updateProfileEmployerDto.getPhone());
				employer.setAddress(updateProfileEmployerDto.getAddress());
				employer.setBusinessType(updateProfileEmployerDto.getBusinessType());
				employer.setCompany(updateProfileEmployerDto.getCompany());
				employer.setDescription(updateProfileEmployerDto.getDescription());
				employer.setGst(updateProfileEmployerDto.getGst());
				employer.setName(updateProfileEmployerDto.getName());
				employer.setPan(updateProfileEmployerDto.getPan());
				employer.setDeviceToken(updateProfileEmployerDto.getDeviceToken());
				String recordingUrl = "";
				String companyImage = "";
				if (updateProfileEmployerDto.getRecording_multipart() != null) {
					recordingUrl = saveCompanyRecording(updateProfileEmployerDto.getRecording_multipart(),
							updateProfileEmployerDto.getEmployerId());
					employer.setRecordingUrl(constantProperties.getBaseURLCompanyRecording() + recordingUrl);
				}
				if (updateProfileEmployerDto.getCompany_image_multipart() != null) {
					companyImage = saveCompanyImage(updateProfileEmployerDto.getCompany_image_multipart(),
							updateProfileEmployerDto.getEmployerId(), "_1");
					employer.setCompanyImage(constantProperties.getBaseURLCompanyImage() + companyImage);
				}
				if (updateProfileEmployerDto.getCompany_image_multipart2() != null) {
					companyImage = saveCompanyImage(updateProfileEmployerDto.getCompany_image_multipart2(),
							updateProfileEmployerDto.getEmployerId(), "_2");
					employer.setCompanyImage2(constantProperties.getBaseURLCompanyImage() + companyImage);
				}
				if (updateProfileEmployerDto.getCompany_image_multipart3() != null) {
					companyImage = saveCompanyImage(updateProfileEmployerDto.getCompany_image_multipart3(),
							updateProfileEmployerDto.getEmployerId(), "_3");
					employer.setCompanyImage3(constantProperties.getBaseURLCompanyImage() + companyImage);
				}
				if (updateProfileEmployerDto.getCompany_image_multipart4() != null) {
					companyImage = saveCompanyImage(updateProfileEmployerDto.getCompany_image_multipart4(),
							updateProfileEmployerDto.getEmployerId(), "_4");
					employer.setCompanyImage4(constantProperties.getBaseURLCompanyImage() + companyImage);
				}
				if (updateProfileEmployerDto.getCompany_image_multipart5() != null) {
					companyImage = saveCompanyImage(updateProfileEmployerDto.getCompany_image_multipart5(),
							updateProfileEmployerDto.getEmployerId(), "_5");
					employer.setCompanyImage5(constantProperties.getBaseURLCompanyImage() + companyImage);
				}
				employerRepo.save(employer);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return employer;
	}

	public List<JobSeekerMasterDto> getJobSeekers(JobListDto jobListDto) {
		List<JobSeekerMasterDto> jobSeekerList = new ArrayList<>();

		try {
			log.error("JobListDto::" + jobListDto);
			StringBuilder query = new StringBuilder("SELECT * from job_seeker_master where status='ACTIVE'");
			if (jobListDto.getName() != null && !jobListDto.getName().equalsIgnoreCase("")) {
				query.append("AND name like'%");
				query.append(jobListDto.getName()).append("%'");
			}

			try {
				if (null != jobListDto.getLocations()) {
					String locationCluase = convertStringArrayToString(jobListDto.getLocations(), "',");
					if (null != locationCluase) {
						query.append("AND current_location in (");
						query.append(locationCluase);
						query.append(")");
					}

				}
			} catch (Exception exception) {

			}
			try {
				if (null != jobListDto.getnSkills()) {
					Set<Integer> jobIdSet = new HashSet<>();
					for (Integer skillId : jobListDto.getnSkills()) {
						List<JobSeekerSkillMap> mapList = jobSeekerSkillMapRepo.findBySkillId(skillId);
						for (JobSeekerSkillMap map : mapList) {
							jobIdSet.add(map.getJobSeekerId());
						}
					}

					if (jobIdSet.size() > 0) {
						StringBuilder jobIdQuery = new StringBuilder();
						jobIdQuery.append(" id IN (");
						for (Integer id : jobIdSet) {

							jobIdQuery.append(id).append(",");
						}
						query.append("AND");
						query.append(jobIdQuery.substring(0, jobIdQuery.length() - 1));
						query.append(")");
					}

				}
			} catch (Exception exception) {

			}

			query.append(";");
			log.error("query::" + query);
			jobSeekerList = jdbcTemplate.query(query.toString(), new JobSeekerMasterQueryMapper());

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerList;
	}

	public List<JobSeekerMasterDto> getJobSeekerList(JobListDto jobListDto) {
		List<JobSeekerMasterDto> jobSeekerList = new ArrayList<>();
		try {
			if (jobListDto.getLocation().equalsIgnoreCase("") && jobListDto.getName().equalsIgnoreCase("")
					&& jobListDto.getSkills().equalsIgnoreCase("")) {
				jobSeekerList = jdbcTemplate.query("SELECT * from job_seeker_master where status='ACTIVE' ;",
						new JobSeekerMasterQueryMapper());
			} else {
				String nameQ = "";
				if (jobListDto.getName() != null && !jobListDto.getName().equalsIgnoreCase("")) {
					nameQ = " AND name='" + jobListDto.getName() + "'";
				}
				String location = "";
				if (jobListDto.getLocation() != null && !jobListDto.getLocation().equalsIgnoreCase("")) {
					System.out.println("jobListDto.getLocation()" + jobListDto.getLocation());

					String skillArr[] = jobListDto.getLocation().split(",");
					location = " AND current_location in (" + convertStringArrayToString(skillArr, "',") + ")";
				}
				if (jobListDto.getSkills() != null && !jobListDto.getSkills().equalsIgnoreCase("")) {
					Set<Integer> jobIdSet = new HashSet<>();
					String skillArr[] = jobListDto.getSkills().split(",");
					if (skillArr.length > 0) {
						for (String s : skillArr) {
							List<JobSeekerSkillMap> mapList = jobSeekerSkillMapRepo.findBySkillId(Integer.parseInt(s));
							for (JobSeekerSkillMap map : mapList) {
								jobIdSet.add(map.getJobSeekerId());
							}
						}
					}
					if (jobIdSet.size() > 0) {
						String jobIdQuery = " id IN (";
						for (Integer id : jobIdSet) {
							jobIdQuery = jobIdQuery + id + ",";
						}
						jobIdQuery = jobIdQuery.substring(0, jobIdQuery.length() - 1);
						jobIdQuery = jobIdQuery + " )";
						if (!location.equalsIgnoreCase("")) {
							location = location + " AND " + jobIdQuery;
						} else {
							location = location + " AND " + jobIdQuery;
						}
					}

				}
				if (!nameQ.equalsIgnoreCase("") && !location.equalsIgnoreCase("")) {
					jobSeekerList = jdbcTemplate.query(
							"SELECT * from job_seeker_master where status='ACTIVE' " + nameQ + " " + location + " ;",
							new JobSeekerMasterQueryMapper());
				} else if (nameQ.equalsIgnoreCase("") && !location.equalsIgnoreCase("")) {
					jobSeekerList = jdbcTemplate.query(
							"SELECT * from job_seeker_master where status='ACTIVE'  " + location + " ;",
							new JobSeekerMasterQueryMapper());
				} else if (!nameQ.equalsIgnoreCase("") && location.equalsIgnoreCase("")) {
					jobSeekerList = jdbcTemplate.query(
							"SELECT * from job_seeker_master where status='ACTIVE' " + nameQ + " ;",
							new JobSeekerMasterQueryMapper());
				}

			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerList;
	}

	public JobMaster addUpdateJob(AddUpdateJobDto addUpdateJobDto) {
		JobMaster jobMaster = null;
		try {
			Optional<JobMaster> job = jobMasterRepo.findById((long) addUpdateJobDto.getJobId());
			if (job.isPresent()) {
				jobMaster = job.get();
				jobMaster.setAccomodation(addUpdateJobDto.getAccomodation());
				jobMaster.setComponsation(addUpdateJobDto.getComponsation());
				jobMaster.setDescription(addUpdateJobDto.getDescription());
				jobMaster.setExperience(addUpdateJobDto.getExperience());
				jobMaster.setFood(addUpdateJobDto.getFood());
				jobMaster.setJob_type(addUpdateJobDto.getJob_type());
				jobMaster.setLeave_policy(addUpdateJobDto.getLeave_policy());
				jobMaster.setLocation(addUpdateJobDto.getLocation());
				jobMaster.setOpenings(addUpdateJobDto.getOpenings());
				// jobMaster.setStatus("Open");
				jobMaster.setTitle(addUpdateJobDto.getTitle());
				jobMaster.setContact(addUpdateJobDto.getContact());
				jobMaster.setEmployerId(String.valueOf(addUpdateJobDto.getEmployerId()));
				jobMasterRepo.save(jobMaster);
				if (addUpdateJobDto.getRecording_multipart() != null) {
					String recordingUrl = saveJobRecording(addUpdateJobDto.getRecording_multipart(), jobMaster.getId());
					jobMaster.setRecording_url(constantProperties.getBaseURLJobRecording() + recordingUrl);
				}
				if (addUpdateJobDto.getSkills() != null && !addUpdateJobDto.getSkills().equalsIgnoreCase("")) {
					jdbcTemplate.update("delete from job_skill_map where job_id=" + jobMaster.getId().intValue());
					jobMaster.setSkills(addUpdateJobDto.getSkills());
					String skillArr[] = addUpdateJobDto.getSkills().split(",");
					if (skillArr.length > 0) {
						for (String s : skillArr) {
							JobSkillMap skillMap = new JobSkillMap();
							skillMap.setJob_id(jobMaster.getId().intValue());
							skillMap.setSkill_id(Integer.parseInt(s));
							jobSkillMapRepo.save(skillMap);
						}
					}
				}
				jobMasterRepo.save(jobMaster);
			} else {
				jobMaster = new JobMaster();
				jobMaster.setAccomodation(addUpdateJobDto.getAccomodation());
				jobMaster.setComponsation(addUpdateJobDto.getComponsation());
				jobMaster.setDescription(addUpdateJobDto.getDescription());
				jobMaster.setExperience(addUpdateJobDto.getExperience());
				jobMaster.setFood(addUpdateJobDto.getFood());
				jobMaster.setJob_type(addUpdateJobDto.getJob_type());
				jobMaster.setLeave_policy(addUpdateJobDto.getLeave_policy());
				jobMaster.setLocation(addUpdateJobDto.getLocation());
				jobMaster.setOpenings(addUpdateJobDto.getOpenings());
				jobMaster.setStatus("Open");
				jobMaster.setDate(util.getCurrentDateString());
				jobMaster.setTitle(addUpdateJobDto.getTitle());
				jobMaster.setContact(addUpdateJobDto.getContact());
				jobMaster.setEmployerId(String.valueOf(addUpdateJobDto.getEmployerId()));
				jobMasterRepo.save(jobMaster);
				if (addUpdateJobDto.getRecording_multipart() != null) {
					String recordingUrl = saveJobRecording(addUpdateJobDto.getRecording_multipart(), jobMaster.getId());
					jobMaster.setRecording_url(constantProperties.getBaseURLJobRecording() + recordingUrl);
				}
				if (addUpdateJobDto.getSkills() != null && !addUpdateJobDto.getSkills().equalsIgnoreCase("")) {
					jobMaster.setSkills(addUpdateJobDto.getSkills());
					String skillArr[] = addUpdateJobDto.getSkills().split(",");
					if (skillArr.length > 0) {
						for (String s : skillArr) {
							JobSkillMap skillMap = new JobSkillMap();
							skillMap.setJob_id(jobMaster.getId().intValue());
							skillMap.setSkill_id(Integer.parseInt(s));
							jobSkillMapRepo.save(skillMap);
						}
					}
				}
				jobMaster.setJobTrackId("ID0" + jobMaster.getId());
				jobMasterRepo.save(jobMaster);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobMaster;
	}

	public List<AppliedCandidateDto> getAppliedCandidateListByJobId(int id) {
		List<AppliedCandidateDto> appliedCandidateList = null;
		try {
			String query = "select address, adhaar_image_url, availability, contact_no, current_location, expected_compensation, expected_salary, experience, father_name, message, name, preferred_location, profile_pic_url, recording_url, skills, status, email, verified, device_token, applied_jobs.id as appliedJobId,applied_jobs.date as appliedDate,applied_jobs.type as appliedJobType, job_id, job_seeker_id from job_seeker_master inner join applied_jobs on job_seeker_master.id = applied_jobs.job_seeker_id where applied_jobs.job_id="
					+ id + " ;";
			appliedCandidateList = jdbcTemplate.query(query, new AppliedCandidateQueryMapper());
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return appliedCandidateList;
	}

	public void markJobAsFulfilled(int id) {
		try {
			Optional<JobMaster> jobMaster = jobMasterRepo.findById((long) id);
			if (jobMaster.isPresent()) {
				String status = jobMaster.get().getStatus();
				if (status.equalsIgnoreCase("Open")) {
					jdbcTemplate.update("update job_master set status='Closed' where id=" + id);
				} else {
					jdbcTemplate.update("update job_master set status='Open' where id=" + id);
				}
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}

	}

	public String getSkillStringByJobSeekerId(Long id) {
		String skills = "";
		try {
			List<String> skillList = jdbcTemplate.query(
					"select sk.title as title from job_seeker_skill_map as map inner join skill_master as sk on map.skill_id = sk.id where map.job_seeker_id="
							+ id,
					new StringResultQueryMapper());
			for (String s : skillList) {
				skills = skills + s + ",";
			}
			if (skills.length() > 1) {
				skills = skills.substring(0, skills.length() - 1);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return skills;
	}

	public String inviteForJob(InviteForJobDto applyJobDto) {
		String result = ServerConstants.FAILURERESPONSEDESC;
		try {
			long count = appliedJobsRepo.countByJobIdAndJobSeekerId(applyJobDto.getJobId(),
					applyJobDto.getJob_seeker_Id());
			if (count == 0) {
				AppliedJobs appliedJobs = new AppliedJobs();
				appliedJobs.setJobId(applyJobDto.getJobId());
				appliedJobs.setJobSeekerId(applyJobDto.getJob_seeker_Id());
				appliedJobs.setDate(util.getCurrentDateString());
				appliedJobs.setType("Invited");
				appliedJobsRepo.save(appliedJobs);
				AppliedJobChatMaster appliedJobChatMaster = new AppliedJobChatMaster();
				appliedJobChatMaster.setAppliedJobId(appliedJobs.getId().intValue());
				appliedJobChatMaster.setType("text");
				appliedJobChatMaster.setImageUrl("");
				String message = "Hi " + applyJobDto.getJobSeekerName() + ", You have been invited by "
						+ applyJobDto.getEmployerName() + " for Job Title: " + applyJobDto.getJobTitle()
						+ ". To apply today search in job listings and apply. Regards " + applyJobDto.getEmployerName();
				appliedJobChatMaster.setMessage(message);
				appliedJobChatMaster.setMessageBy("Employer");
				appliedJobChatMaster.setName(applyJobDto.getEmployerName());
				appliedJobChatMaster.setReadByEmployer(true);
				appliedJobChatMaster.setReadByJobSeeker(false);
				appliedJobChatMaster.setTime(new Date());
				appliedJobChatMasterRepo.save(appliedJobChatMaster);
				result = ServerConstants.SUCCESRESPONSEDESC;
				// TODO Send Push Notification
				SaveJobChat dto = new SaveJobChat();
				dto.setAppliedJobId(appliedJobs.getId().intValue());
				dto.setMessageBy("Employer");
				dto.setName(applyJobDto.getEmployerName());
				dto.setType("text");
				dto.setMessage(message);
				asyncService.sendPushNotification(dto);
			} else {
				List<AppliedJobs> ajList = appliedJobsRepo.findByJobSeekerIdAndJobId(applyJobDto.getJob_seeker_Id(),
						applyJobDto.getJobId());
				if (ajList.size() == 1) {
					AppliedJobs aj = ajList.get(0);
					if (aj.getType() != null && aj.getType().equalsIgnoreCase("Invited")) {
						result = ServerConstants.ALREADYINVITED;
					} else {
						result = ServerConstants.ALREADYAPPLIED;
					}
				}
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public String getSkillStringByJobId(Long id) {
		String skills = "";
		try {
			List<String> skillList = jdbcTemplate.query(
					"select sk.title as title from job_skill_map as map inner join skill_master as sk on map.skill_id = sk.id where map.job_id="
							+ id,
					new StringResultQueryMapper());
			for (String s : skillList) {
				skills = skills + s + ",";
			}
			if (skills.length() > 1) {
				skills = skills.substring(0, skills.length() - 1);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		log.info("Skills:: " + skills);
		return skills;
	}

	public List<AppliedCandidateDto> getAppliedCandidateListByEmployerId(int id) {
		List<AppliedCandidateDto> appliedCandidateList = null;
		try {
			List<JobMaster> jobList = jobMasterRepo.findByEmployerId(String.valueOf(id));
			if (null == jobList || jobList.isEmpty())
				return appliedCandidateList;

			String jobIdQuery = " IN (";
			for (JobMaster jm : jobList) {
				jobIdQuery = jobIdQuery + jm.getId() + ",";
			}
			jobIdQuery = jobIdQuery.substring(0, jobIdQuery.length() - 1);
			jobIdQuery = jobIdQuery + " )";
			String query = "select address, adhaar_image_url, availability, contact_no, current_location, expected_compensation, expected_salary, experience, father_name, message, name, preferred_location, profile_pic_url, recording_url, skills, status, email, verified, device_token, applied_jobs.id as appliedJobId,applied_jobs.date as appliedDate,applied_jobs.type as appliedJobType, job_id, job_seeker_id from job_seeker_master inner join applied_jobs on job_seeker_master.id = applied_jobs.job_seeker_id where applied_jobs.job_id "
					+ jobIdQuery + " ;";
			appliedCandidateList = jdbcTemplate.query(query, new AppliedCandidateQueryMapper());
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return appliedCandidateList;
	}

	public String checkJobApplied(ApplyJobDto applyJobDto) {
		String result = ServerConstants.FAILURERESPONSEDESC;
		try {
			long count = appliedJobsRepo.countByJobIdAndJobSeekerId(applyJobDto.getJob_id(),
					applyJobDto.getJob_seeker_id());
			if (count == 0) {
				result = "Not Applied for this Job";
			} else {
				List<AppliedJobs> ajList = appliedJobsRepo.findByJobSeekerIdAndJobId(applyJobDto.getJob_seeker_id(),
						applyJobDto.getJob_id());
				if (ajList.size() == 1) {
					AppliedJobs aj = ajList.get(0);
					if (aj.getType() != null && aj.getType().equalsIgnoreCase("Invited")) {
						result = "Received Invite for this Job";
					} else {
						result = ServerConstants.ALREADYAPPLIED;
					}
				}
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public String getRandomBannerImage() {
		String result = "";
		try {
			int count = jdbcTemplate.queryForObject("SELECT count(*) FROM advertisements_master where status='ACTIVE';",
					Integer.class);
			if (count > 0) {
				result = jdbcTemplate.queryForObject(
						"SELECT image_url FROM advertisements_master where status='ACTIVE' ORDER BY RAND() LIMIT 1;",
						String.class);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public Date getLastChatMessageTime(int appliedJobId) {
		Date result = null;
		try {
			int count = jdbcTemplate.queryForObject("SELECT count(*) FROM applied_job_chat_master where applied_job_id="
					+ appliedJobId + " order by id desc limit 1;", Integer.class);
			if (count > 0) {
				result = jdbcTemplate.queryForObject("SELECT time FROM applied_job_chat_master where applied_job_id="
						+ appliedJobId + " order by id desc limit 1;", Date.class);
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}

	public JobSeekerMaster getJobSeekerbyMobileNumber(String mobileNumber) {
		return jobSeekerMasterRepo.findTop1ByContactOrderByIdDesc(mobileNumber);
	}

	public Integer updateDeviceToken(UpdateDeviceTokenDTO updateDeviceTokenDTO) {

		if (null == updateDeviceTokenDTO)
			return 0;

		if ("SATHI".equalsIgnoreCase(updateDeviceTokenDTO.getUserType())) {
			Employer employer = employerRepo.findByEmail(updateDeviceTokenDTO.getId());
			if (null == employer) {
				return 0;
			}

			return jdbcTemplate.update("update employer_master set device_token='"
					+ updateDeviceTokenDTO.getDeviceToken() + "' where id=" + employer.getId());

		} else if ("SEEKER".equalsIgnoreCase(updateDeviceTokenDTO.getUserType())) {
			JobSeekerMaster jobSeekerMaster = jobSeekerMasterRepo
					.findTop1ByContactOrderByIdDesc(updateDeviceTokenDTO.getId());
			if (null == jobSeekerMaster) {
				return 0;
			}

			return jdbcTemplate.update("update job_seeker_master set device_token='"
					+ updateDeviceTokenDTO.getDeviceToken() + "' where id=" + jobSeekerMaster.getId());

		}

		return 0;
	}

	private static String convertStringArrayToString(String[] strArr, String delimiter) {
		StringBuilder sb = new StringBuilder();
		for (String str : strArr)
			sb.append("'").append(str).append(delimiter);
		return sb.substring(0, sb.length() - 1);
	}

	private String saveCompanyImage(MultipartFile recording_multipart, int id, String string) {
		String fName = "";
		try {
			if (null != recording_multipart) {
				fName = "employer_company_image_" + string + "_" + id + "."
						+ FilenameUtils.getExtension(recording_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(recording_multipart, constantProperties.getS3bucketCompanyImage(), fName);
				} else {
					Path path = Paths.get(constantProperties.getUploadFolderCompanyImage() + fName);
					Files.write(path, recording_multipart.getBytes());
				}
			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}

	private String saveCompanyRecording(MultipartFile recording_multipart, int id) {
		String fName = "";
		try {
			if (null != recording_multipart) {
				fName = "employer_company_recording_" + id + "."
						+ FilenameUtils.getExtension(recording_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(recording_multipart, constantProperties.getS3bucketCompanyRecording(),
							fName);
				} else {
					Path path = Paths.get(constantProperties.getUploadFolderCompanyRecording() + fName);
					Files.write(path, recording_multipart.getBytes());
				}
			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}

	private String saveRecordingFile(MultipartFile recording_multipart, Long id) {
		String fName = "";
		try {
			if (null != recording_multipart) {
				fName = "job_seeker_recording_" + id + "."
						+ FilenameUtils.getExtension(recording_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(recording_multipart, constantProperties.getS3bucketRecording(), fName);
				} else {
					Path path = Paths.get(constantProperties.getUploadFolderRecording() + fName);
					Files.write(path, recording_multipart.getBytes());
				}
			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}

	private String saveProfileImage(MultipartFile profile_pic_multipart, Long id) {
		String fName = "";
		try {

			if (null != profile_pic_multipart) {
				fName = "job_seeker_profile_" + id + "."
						+ FilenameUtils.getExtension(profile_pic_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(profile_pic_multipart, constantProperties.getS3bucketProfile(), fName);
				} else {
					Path path = Paths.get(constantProperties.getUploadFolderProfile() + fName);
					Files.write(path, profile_pic_multipart.getBytes());
				}
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}

	private String saveAdhaarImage(MultipartFile adhaar_image_multipart, Long id) {
		String fName = "";
		try {
			if (null != adhaar_image_multipart) {
				fName = "job_seeker_adhaar_" + id + "."
						+ FilenameUtils.getExtension(adhaar_image_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(adhaar_image_multipart, constantProperties.getS3bucketAdhar(), fName);
				} else {
					Path path = Paths.get(constantProperties.getUploadFolderAdhar() + fName);
					Files.write(path, adhaar_image_multipart.getBytes());
				}
			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}

	private String saveChatMessageFile(MultipartFile recording_multipart, Long id) {
		String fName = "";
		try {
			if (null != recording_multipart) {
				fName = "chat_image" + id + "." + FilenameUtils.getExtension(recording_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(recording_multipart, constantProperties.getS3bucketChatFile(), fName);
				} else {
					Path path = Paths.get(constantProperties.getUploadFolderChatFile() + fName);
					Files.write(path, recording_multipart.getBytes());
				}
			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}

	private String saveJobRecording(MultipartFile recording_multipart, Long id) {
		String fName = "";
		try {

			if (null != recording_multipart) {
				fName = "job_recording_" + id + "."
						+ FilenameUtils.getExtension(recording_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(recording_multipart, constantProperties.getS3bucketJobRecording(), fName);
				} else {
					Path path = Paths.get(constantProperties.getUploadFolderJobRecording() + fName);
					Files.write(path, recording_multipart.getBytes());
				}
			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}

	private void buildLeadData(JobSeekerMaster jobSeeker) {
		LeadDto leadDto = new LeadDto();
		leadDto.setType("Job Seeker");
		leadDto.setName(jobSeeker.getName());
		leadDto.setPhone(jobSeeker.getContact());
		leadDto.setStage("L2");
		MasterCampaign masterCampaign = serviceCampaign.getMasterCampaignById(1l);
		if (null != masterCampaign) {
			leadDto.setCampaignCode(masterCampaign.getCampaignCode());
		}
		leadDto.setCustomerId(String.valueOf(jobSeeker.getId()));
		leadDto.setAgent_id(1);
		leadDto.setAgent_name("SYSTEM");
		;
		serviceLeadMaster.createLeadMaster(leadDto);
	}

	private boolean isNewJobSeekerData(AddJobSeekerDto addJobSeekerDto) {
		if (0 == addJobSeekerDto.getJob_seeker_id()) {
			return true;
		}

		Optional<JobSeekerMaster> jobSeekerO = jobSeekerMasterRepo.findById((long) addJobSeekerDto.getJob_seeker_id());
		if (!jobSeekerO.isPresent()) {
			return true;
		}

		return false;
	}

	private int createNewJobSeekerData(AddJobSeekerDto addJobSeekerDto) {
		int result = 0;
		JobSeekerMaster jobSeeker = new JobSeekerMaster();
		jobSeeker.setEntryDateTime(Instant.now());
		jobSeeker.setRegistredDateTime(jobSeeker.getEntryDateTime());
		if (addJobSeekerDto.getAddress() != null && !addJobSeekerDto.getAddress().equalsIgnoreCase("")) {
			jobSeeker.setAddress(addJobSeekerDto.getAddress());
		}
		if (addJobSeekerDto.getAvailability() != null && !addJobSeekerDto.getAvailability().equalsIgnoreCase("")) {
			jobSeeker.setAvailability(addJobSeekerDto.getAvailability());
		}
		if (addJobSeekerDto.getEmail() != null && !addJobSeekerDto.getEmail().equalsIgnoreCase("")) {
			jobSeeker.setEmail(addJobSeekerDto.getEmail());
		}
		if (addJobSeekerDto.getContact_no() != null && !addJobSeekerDto.getContact_no().equalsIgnoreCase("")) {
			jobSeeker.setContact(addJobSeekerDto.getContact_no());
		}
		if (addJobSeekerDto.getCurrent_location() != null
				&& !addJobSeekerDto.getCurrent_location().equalsIgnoreCase("")) {
			jobSeeker.setCurrent_location(addJobSeekerDto.getCurrent_location());
		}
		if (addJobSeekerDto.getExpected_compensation() != null
				&& !addJobSeekerDto.getExpected_compensation().equalsIgnoreCase("")) {
			jobSeeker.setExpected_compensation(addJobSeekerDto.getExpected_compensation());
		}
		if (addJobSeekerDto.getExpected_salary() != null
				&& !addJobSeekerDto.getExpected_salary().equalsIgnoreCase("")) {
			jobSeeker.setExpected_salary(addJobSeekerDto.getExpected_salary());
		}
		if (addJobSeekerDto.getExperience() != null && !addJobSeekerDto.getExperience().equalsIgnoreCase("")) {
			jobSeeker.setExperience(addJobSeekerDto.getExperience());
		}
		if (addJobSeekerDto.getFather_name() != null && !addJobSeekerDto.getFather_name().equalsIgnoreCase("")) {
			jobSeeker.setFather_name(addJobSeekerDto.getFather_name());
		}
		if (addJobSeekerDto.getMessage() != null && !addJobSeekerDto.getMessage().equalsIgnoreCase("")) {
			jobSeeker.setMessage(addJobSeekerDto.getMessage());
		}
		if (addJobSeekerDto.getName() != null && !addJobSeekerDto.getName().equalsIgnoreCase("")) {
			jobSeeker.setName(addJobSeekerDto.getName());
		}
		if (addJobSeekerDto.getPreferred_location() != null
				&& !addJobSeekerDto.getPreferred_location().equalsIgnoreCase("")) {
			jobSeeker.setPreferred_location(addJobSeekerDto.getPreferred_location());
		}
		if (addJobSeekerDto.getDeviceToken() != null && !addJobSeekerDto.getDeviceToken().equalsIgnoreCase("")) {
			jobSeeker.setDeviceToken(addJobSeekerDto.getDeviceToken());
		}
		jobSeeker.setStatus("IN-ACTIVE");
		jobSeeker.setVerified(false);
		jobSeeker.setMobileVerification(true);
		jobSeeker.setEntryDateTime(Instant.now());
		jobSeeker.setRegistredDateTime(jobSeeker.getEntryDateTime());
		jobSeekerMasterRepo.save(jobSeeker);
		if (addJobSeekerDto.getSkills() != null && !addJobSeekerDto.getSkills().equalsIgnoreCase("")) {
			jobSeeker.setSkills(addJobSeekerDto.getSkills());
			String skillArr[] = addJobSeekerDto.getSkills().split(",");
			if (skillArr.length > 0) {
				for (String s : skillArr) {
					JobSeekerSkillMap skillMap = new JobSeekerSkillMap();
					skillMap.setJobSeekerId(jobSeeker.getId().intValue());
					skillMap.setSkillId(Integer.parseInt(s));
					jobSeekerSkillMapRepo.save(skillMap);
				}
			}
		}

		result = jobSeeker.getId().intValue();
		if (addJobSeekerDto.getAdhaar_image_multipart() != null) {
			String adhaarUrl = saveAdhaarImage(addJobSeekerDto.getAdhaar_image_multipart(), jobSeeker.getId());
			jobSeeker.setAdhaar_image_url(constantProperties.getBaseURLAdhar() + adhaarUrl);
		}
		if (addJobSeekerDto.getProfile_pic_multipart() != null) {
			String profileUrl = saveProfileImage(addJobSeekerDto.getProfile_pic_multipart(), jobSeeker.getId());
			jobSeeker.setProfile_pic_url(constantProperties.getBaseURLProfile() + profileUrl);
		}
		if (addJobSeekerDto.getRecording_multipart() != null) {
			String recordingUrl = saveRecordingFile(addJobSeekerDto.getRecording_multipart(), jobSeeker.getId());
			jobSeeker.setRecording_url(constantProperties.getBaseURLRecording() + recordingUrl);
		}

		jobSeeker.setEmailVerification(addJobSeekerDto.getEmailVerification());
		jobSeeker.setMobileVerification(addJobSeekerDto.getMobileVerification());
		jobSeeker.setAccountVerification(addJobSeekerDto.getAccountVerification());
		if (null != addJobSeekerDto.getWhatsappNumber() && !addJobSeekerDto.getWhatsappNumber().isEmpty()) {
			jobSeeker.setWhatsappNumber(addJobSeekerDto.getWhatsappNumber());
		}
		jobSeeker.setWhatsappVerification(addJobSeekerDto.getWhatsappVerification());
		jobSeekerMasterRepo.save(jobSeeker);
		buildLeadData(jobSeeker);
		return result;
	}

	private int updateJobSeekerData(AddJobSeekerDto addJobSeekerDto) {
		Optional<JobSeekerMaster> jobSeekerO = jobSeekerMasterRepo.findById((long) addJobSeekerDto.getJob_seeker_id());
		JobSeekerMaster jobSeekerDB = jobSeekerO.get();
		jobSeekerDB.setAddress(addJobSeekerDto.getAddress());
		jobSeekerDB.setAvailability(addJobSeekerDto.getAvailability());
		jobSeekerDB.setEmail(addJobSeekerDto.getEmail());
		jobSeekerDB.setContact(addJobSeekerDto.getContact_no());
		jobSeekerDB.setCurrent_location(addJobSeekerDto.getCurrent_location());
		jobSeekerDB.setExpected_compensation(addJobSeekerDto.getExpected_compensation());
		jobSeekerDB.setExpected_salary(addJobSeekerDto.getExpected_salary());

		jobSeekerDB.setExperience(addJobSeekerDto.getExperience());
		jobSeekerDB.setFather_name(addJobSeekerDto.getFather_name());
		jobSeekerDB.setMessage(addJobSeekerDto.getMessage());
		jobSeekerDB.setName(addJobSeekerDto.getName());
		jobSeekerDB.setPreferred_location(addJobSeekerDto.getPreferred_location());
		jobSeekerDB.setDeviceToken(addJobSeekerDto.getDeviceToken());
		
		if (addJobSeekerDto.getSkills() != null && !addJobSeekerDto.getSkills().equalsIgnoreCase("")) {
			jobSeekerDB.setSkills(addJobSeekerDto.getSkills());
			String skillArr[] = addJobSeekerDto.getSkills().split(",");
			if (skillArr.length > 0) {
				jdbcTemplate.update(
						"delete from job_seeker_skill_map where job_seeker_id=" + jobSeekerDB.getId().intValue());
				for (String s : skillArr) {
					JobSeekerSkillMap skillMap = new JobSeekerSkillMap();
					skillMap.setJobSeekerId(jobSeekerDB.getId().intValue());
					skillMap.setSkillId(Integer.parseInt(s));
					jobSeekerSkillMapRepo.save(skillMap);
				}
			}
		}
		jobSeekerMasterRepo.save(jobSeekerDB);
		if (addJobSeekerDto.getAdhaar_image_multipart() != null) {
			String adhaarUrl = saveAdhaarImage(addJobSeekerDto.getAdhaar_image_multipart(), jobSeekerDB.getId());
			jobSeekerDB.setAdhaar_image_url(constantProperties.getBaseURLAdhar() + adhaarUrl);
		}
		if (addJobSeekerDto.getProfile_pic_multipart() != null) {
			String profileUrl = saveProfileImage(addJobSeekerDto.getProfile_pic_multipart(), jobSeekerDB.getId());
			jobSeekerDB.setProfile_pic_url(constantProperties.getBaseURLProfile() + profileUrl);
		}
		if (addJobSeekerDto.getRecording_multipart() != null) {
			String recordingUrl = saveRecordingFile(addJobSeekerDto.getRecording_multipart(), jobSeekerDB.getId());
			jobSeekerDB.setRecording_url(constantProperties.getBaseURLRecording() + recordingUrl);
		}
		jobSeekerDB.setUpdateDateTime(Instant.now());
		jobSeekerMasterRepo.save(jobSeekerDB);
		return jobSeekerDB.getId().intValue();
	}

	public ResponseEmployer getJobList(Long id, Map<String, String> searchParameter) {
		Optional<Employer> optional = employerRepo.findById(id);
		if (!optional.isPresent())
			return null;

		Employer employer = optional.get();
		ResponseEmployer responseEmployer = new ResponseEmployer();
		EmployerDto employerDto = new EmployerDto();
		BeanUtils.copyProperties(employer, employerDto);

		List<JobMaster> jobList = jobMasterRepo.findByEmployerId(String.valueOf(id));

		if (null == jobList || jobList.isEmpty())
			return null;

		List<JobMasterDto> jobMasterDtoList = new ArrayList<JobMasterDto>();
		for (JobMaster jobMaster : jobList) {
			JobMasterDto jobMasterDto = new JobMasterDto();
			BeanUtils.copyProperties(jobMaster, jobMasterDto);
			jobMasterDtoList.add(jobMasterDto);
		}
		employerDto.setJobList(jobMasterDtoList);
		responseEmployer.setEmployer(employerDto);
		return responseEmployer;
	}

	public List<JobSeekerMaster> getJobSeekers(Long[] memberCodes) {
		List<Long> inputAsList = Arrays.asList(memberCodes);
		return jobSeekerMasterRepo.findAllByIdIn(inputAsList);
	}

}
