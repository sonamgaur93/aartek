package com.hamararojgar.serviceimpl;

import java.io.File;

import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.model.S3Object;

public interface AWSS3Service {

	void uploadFile(MultipartFile multipartFile, String fileName);
	void uploadFile(MultipartFile multipartFile, String folerName, String fileName);
	void uploadFile(File file, String fileName);
	S3Object downloadFile(String key);
	S3Object downloadFile(String folderName, String key);
}
