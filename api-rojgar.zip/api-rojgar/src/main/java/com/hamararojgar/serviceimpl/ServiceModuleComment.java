package com.hamararojgar.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hamararojgar.dto.ResponseDTOModuleComment;
import com.hamararojgar.model.MasterCampaign;
import com.hamararojgar.model.ModelModuleComment;
import com.hamararojgar.payload.response.ResponseModuleComment;
import com.hamararojgar.repo.RepoModuleComment;

@Service
public class ServiceModuleComment {
	
	@Autowired
	private RepoModuleComment  repoModuleComment;

	public ResponseModuleComment getComments(String moduleName, String recordId, Map<String, String> searchParameters) {
		
		Page<ModelModuleComment> page = null;
		List<ModelModuleComment> modelModuleComments = null;
		String processModuleName= null;
		if("jscomments".equalsIgnoreCase(moduleName)) {
			processModuleName = "JOB_SEEKER";
		}else if("sathicomments".equalsIgnoreCase(moduleName)) {
			processModuleName = "SATHI";
		}else if("jobcomments".equalsIgnoreCase(moduleName)) {
			processModuleName = "JOB";
		}
		
		if (null == processModuleName) {
			return null;
		}
		
		if(null == searchParameters || searchParameters.isEmpty()){
			modelModuleComments = repoModuleComment.findByModuleNameAndRecordId(processModuleName, recordId);
		}else {
			Pageable paging = null;
			Integer size = null;
			Integer pageNumber = null;
			try {
				size = Integer.valueOf(searchParameters.get("size"));
				pageNumber = Integer.valueOf(searchParameters.get("page"));
			}catch(Exception exception) {
				
			}
			Sort sort = Sort.by("id").descending();
			if (null != size && size >= 1) {
				if (null == pageNumber || pageNumber < 0) {
					pageNumber = 0;
				}
				paging = PageRequest.of(pageNumber, size, sort);
			}
			
			
			if(null == paging) {
				modelModuleComments = repoModuleComment.findByModuleNameAndRecordId(processModuleName, recordId);
			}else {
				page= repoModuleComment.findByModuleNameAndRecordId(processModuleName, recordId, paging);
				
			}
		}
		ResponseModuleComment responseModuleComment = new ResponseModuleComment();	
		if(null != page ) {
			modelModuleComments = page.getContent();
			responseModuleComment.setCurrentPage(page.getNumber());
			responseModuleComment.setTotalItems(page.getNumberOfElements());
			responseModuleComment.setTotalPages(page.getTotalPages());
		}
		
		if(null == modelModuleComments ||  modelModuleComments.isEmpty()) {
			return null;
		}
		List<ResponseDTOModuleComment> comments = new ArrayList<ResponseDTOModuleComment>();
		for (ModelModuleComment modelModuleComment : modelModuleComments) {
			ResponseDTOModuleComment responseDTOModuleComment = new ResponseDTOModuleComment();
			responseDTOModuleComment.setModuleComment(modelModuleComment.getComment());
			responseDTOModuleComment.setEntryDateTime(modelModuleComment.getEntryDateTime());
			comments.add(responseDTOModuleComment);
		}
		
		responseModuleComment.setComments(comments);
		return responseModuleComment;

	}
	


	
}