package com.hamararojgar.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hamararojgar.dto.EmployerDto;
import com.hamararojgar.dto.ResponseDTOJobSeeker;
import com.hamararojgar.dto.ResponseDTORojgarJob;
import com.hamararojgar.model.AppliedJobs;
import com.hamararojgar.model.JobMaster;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.payload.response.ResponseRojgarJob;
import com.hamararojgar.repo.AppliedJobsRepo;
import com.hamararojgar.repo.JobMasterRepo;
import com.hamararojgar.repo.JobSeekerMasterRepo;

@Service
public class ServiceRojgarJobs {

	private static final Logger log = LogManager.getLogger(ServiceRojgarJobs.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	JobMasterRepo jobMasterRepo;

	@Autowired
	AppliedJobsRepo appliedJobsRepo;

	@Autowired
	JobSeekerMasterRepo jobSeekerMasterRepo;

	@Autowired
	ServiceEmployer serviceEmployer;

	public ResponseRojgarJob getAppliedCandidates(String jobId, Map<String, String> searchParameters) {
		Optional<JobMaster> jobMasterOptional = jobMasterRepo.findById(Long.parseLong(jobId));
		if (!jobMasterOptional.isPresent()) {
			return null;
		}
		JobMaster jobMaster = jobMasterOptional.get();
		log.info("JobMaster master available {}", jobId);
		ResponseRojgarJob responseRojgarJob = new ResponseRojgarJob();
		ResponseDTORojgarJob job = new ResponseDTORojgarJob();
		job.setTitle(jobMaster.getTitle());
		job.setId(jobMaster.getId());
		job.setEmployer(buildEmployer(jobMaster.getEmployerId()));
		job.setSeekers(buildAppliedSeekers(Integer.parseInt(jobId), searchParameters, responseRojgarJob));
		job.setApplied(buildJobAppliedOrInvited(Integer.parseInt(jobId), "Applied"));
		job.setInvited(buildJobAppliedOrInvited(Integer.parseInt(jobId), "Invited"));
		responseRojgarJob.setJob(job);

		return responseRojgarJob;
	}

	private List<ResponseDTOJobSeeker> buildAppliedSeekers(int jobId, Map<String, String> searchParameters,
			ResponseRojgarJob responseRojgarJob) {
		List<AppliedJobs> appliedJobs = null;
		Page<AppliedJobs> appliedJobsPage = null;
		if (null == searchParameters || searchParameters.isEmpty()) {
			appliedJobs = appliedJobsRepo.findByJobId(jobId);
		} else {
			Pageable paging = null;
			Integer size = null;
			Integer pageNumber = null;
			try {
				size = Integer.valueOf(searchParameters.get("size"));
				pageNumber = Integer.valueOf(searchParameters.get("page"));
			} catch (Exception exception) {

			}
			if (null != size && size >= 1) {
				if (null == pageNumber || pageNumber < 0) {
					pageNumber = 0;
				}
				paging = PageRequest.of(pageNumber, size);
			}
			if (null == paging) {
				appliedJobs = appliedJobsRepo.findByJobId(jobId);
			} else {
				appliedJobsPage = appliedJobsRepo.findByJobId(jobId, paging);
				appliedJobs = appliedJobsPage.getContent();
			}
		}
		if (null == appliedJobs) {
			return null;
		}
		if (null != appliedJobsPage) {
			responseRojgarJob.setCurrentPage(appliedJobsPage.getNumber());
			responseRojgarJob.setTotalItems(appliedJobsPage.getNumberOfElements());
			responseRojgarJob.setTotalPages(appliedJobsPage.getTotalPages());
		} else {
			responseRojgarJob.setCurrentPage(1);
			responseRojgarJob.setTotalItems(appliedJobs.size());
			responseRojgarJob.setTotalPages(1);
		}
		
		Map<Integer, JobSeekerMaster> mapJobSeekerMaster = new HashMap<Integer, JobSeekerMaster>();
		for (AppliedJobs appliedJob : appliedJobs) {

			if (!mapJobSeekerMaster.containsKey(Integer.valueOf(appliedJob.getJobSeekerId()))) {
				JobSeekerMaster jobSeekerMaster = getJobSeeker(appliedJob.getJobSeekerId());
				mapJobSeekerMaster.put(Integer.valueOf(appliedJob.getJobSeekerId()), jobSeekerMaster);
			}
		}
		List<ResponseDTOJobSeeker> responseDTOJobSeekers = new ArrayList<ResponseDTOJobSeeker>();
		for (Integer jobSeekerId : mapJobSeekerMaster.keySet()) {
			JobSeekerMaster jobSeekerMaster = mapJobSeekerMaster.get(jobSeekerId);
			ResponseDTOJobSeeker responseDTOJobSeeker = new ResponseDTOJobSeeker();
			responseDTOJobSeeker.setId(Long.valueOf(jobSeekerId));
			responseDTOJobSeeker.setName(jobSeekerMaster.getName());
			responseDTOJobSeeker.setContact(jobSeekerMaster.getContact());
			responseDTOJobSeekers.add(responseDTOJobSeeker);
		}
		return responseDTOJobSeekers;
	}

	private Set<Integer> buildJobAppliedOrInvited(int jobId, String type) {
		List<AppliedJobs> appliedJobs = appliedJobsRepo.findByJobIdAndTypeIgnoreCase(jobId, type);
		Set<Integer> jobSeekerId = null;
		if (null != appliedJobs) {
			jobSeekerId = new HashSet<Integer>();
			for (AppliedJobs appliedJob : appliedJobs) {
					jobSeekerId.add(appliedJob.getJobSeekerId());

			}
		}
		return jobSeekerId;
	}

	private JobSeekerMaster getJobSeeker(int jobSeekerId) {
		Optional<JobSeekerMaster> optionalJobSeekerMaster = jobSeekerMasterRepo.findById(Long.valueOf(jobSeekerId));
		if (!optionalJobSeekerMaster.isPresent()) {
			return null;
		}
		return optionalJobSeekerMaster.get();
	}

	private EmployerDto buildEmployer(String employerId) {
		return serviceEmployer.getEmployer(Long.parseLong(employerId));
	}

}