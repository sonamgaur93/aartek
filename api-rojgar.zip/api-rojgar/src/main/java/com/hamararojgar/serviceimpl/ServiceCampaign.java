package com.hamararojgar.serviceimpl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.DTOCampaign;
import com.hamararojgar.dto.ResponseDTOHamararojgarUser;
import com.hamararojgar.dto.ResponseDTOLead;
import com.hamararojgar.model.LeadMaster;
import com.hamararojgar.model.MasterCampaign;
import com.hamararojgar.model.MasterUserRoleType;
import com.hamararojgar.model.RelationCampaignLead;
import com.hamararojgar.model.RelationCampaignMembers;
import com.hamararojgar.model.User;
import com.hamararojgar.payload.request.RequestCampaign;
import com.hamararojgar.payload.request.RequestRojgarSearchParameter;
import com.hamararojgar.payload.response.ResponseCampaign;
import com.hamararojgar.repo.CampaignLeadRepo;
import com.hamararojgar.repo.CampaignMemberRepo;
import com.hamararojgar.repo.CampaignRepo;
import com.hamararojgar.repo.RepoMasterUserRoleType;
import com.hamararojgar.util.Util;

import jdk.internal.org.jline.utils.Log;

@Service
public class ServiceCampaign {
	
	private static final Logger log = LogManager.getLogger(ServiceCampaign.class);

	@Autowired
	private CampaignRepo campaignRepo;

	@Autowired
	private ServiceMember serviceMember;

	@Autowired
	private CampaignMemberRepo campaignMemberRepo;
	
	@Autowired
	private CampaignLeadRepo campaignLeadRepo;

	@Autowired
	Util util;
	
	@Autowired
	private RepoMasterUserRoleType repoMasterUserRoleType;

	
	@Autowired
	ServiceLeadMaster serviceLeadMaster;

	public ResponseCampaign createCampaign(RequestCampaign requestCampaign) {

		MasterCampaign masterCampaign = new MasterCampaign();
		BeanUtils.copyProperties(requestCampaign, masterCampaign);
		masterCampaign.setCampaignCode(masterCampaign.buildCampaignCode());
		masterCampaign.setEntryDateTime(Instant.now());
		masterCampaign.setCampaignStartDate(util.getInstantByDateFormat(requestCampaign.getCampaignStartDate()));
		masterCampaign.setCampaignEndDate(util.getInstantByDateFormat(requestCampaign.getCampaignEndDate()));
		campaignRepo.save(masterCampaign);
		requestCampaign.setCampaignCode(masterCampaign.getCampaignCode());
		processCampaignMembers(requestCampaign);
		ResponseCampaign responseCampaign = getCampaign(masterCampaign.getCampaignCode());
		return responseCampaign;
	}

	public ResponseCampaign getCampaign(Pageable paging) {
		List<MasterCampaign> masterCampaigns = null;
		Page<MasterCampaign> page = null;
		if (null == paging) {
			masterCampaigns = campaignRepo.findAll();
		} else {
			page = campaignRepo.findAll(paging);
			masterCampaigns = page.getContent();
		}
		List<DTOCampaign> dtoCampaigns = new ArrayList<DTOCampaign>();
		ResponseCampaign responseCampaign = new ResponseCampaign();
		DTOCampaign dtoCampaign = new DTOCampaign();
		dtoCampaign.setCampaignCode("-1");
		dtoCampaign.setCampaignName("Select  All");
		dtoCampaigns.add(dtoCampaign);
		if (null == masterCampaigns) {
			responseCampaign.setCampaigns(dtoCampaigns);
			return responseCampaign;
		}
		
		for (MasterCampaign masterCampaign : masterCampaigns) {
			dtoCampaign = new DTOCampaign();
			BeanUtils.copyProperties(masterCampaign, dtoCampaign);
			//dtoCampaign.setMembers(buildCampaingMembersByCampaignCode(dtoCampaign.getCampaignCode()));
			//dtoCampaign.setLeads(buildCampaingLeadssByCampaignCode(dtoCampaign.getCampaignCode()));
			dtoCampaigns.add(dtoCampaign);
		}
		
		responseCampaign.setCampaigns(dtoCampaigns);
		if (null != page) {
			responseCampaign.setCurrentPage(page.getNumber());
			responseCampaign.setTotalItems(page.getNumberOfElements());
			responseCampaign.setTotalPages(page.getTotalPages());
		}
		return responseCampaign;
	}
	
	public ResponseCampaign getCampaign(Map<String, String> parameters) {
		log.info("getCampaign(Map<String, String> parameters)");
		if(null != parameters) {
			for (String parameterKey : parameters.keySet()) {
				log.info("Parameter Key :: " +parameterKey + " Value:: "+ parameters.get(parameterKey));
			}
		}
		Pageable paging = null;
		Integer size = null;
		Integer pageNumber = null;
		String campaignKey= (parameters.containsKey("campaignKey")?parameters.get("campaignKey"): null);
		String startDate= (parameters.containsKey("startDate")?parameters.get("startDate"): null);
		Instant campaignStartDate = null;
		if(null != startDate) {
			try {
				campaignStartDate = Instant.parse(startDate);
			}catch(Exception exception) {
				campaignStartDate = null;
			}
		}
		String endDate= (parameters.containsKey("endDate")?parameters.get("endDate"): null);
		
		Instant campaignEndDate = null;
		if(null != endDate) {
			try {
				campaignEndDate = Instant.parse(endDate);
			}catch(Exception exception) {
				campaignEndDate = null;
			}
		}
		
		try {
			size = Integer.valueOf(parameters.get("size"));
			pageNumber = Integer.valueOf(parameters.get("page"));
		}catch(Exception exception) {
			
		}
		Sort sort = Sort.by("id").descending();
		if (null != size && size >= 1) {
			if (null == pageNumber || pageNumber < 0) {
				pageNumber = 0;
			}
			paging = PageRequest.of(pageNumber, size, sort);
		}
		List<MasterCampaign> masterCampaigns = null;
		Page<MasterCampaign> page = null;

		if (null == paging && null == campaignKey && null==campaignStartDate && null==campaignEndDate) {
			masterCampaigns = campaignRepo.findAll(sort);
		} else if (null != campaignKey && null !=campaignStartDate && null != campaignEndDate ) {
			if(null != paging) {
				page = campaignRepo.findByCampaignStartDateGreaterThanEqualAndCampaignEndDateLessThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(campaignStartDate, campaignEndDate,campaignKey, campaignKey, paging);
			}else {
				masterCampaigns = campaignRepo.findByCampaignStartDateGreaterThanEqualAndCampaignEndDateLessThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(campaignStartDate, campaignEndDate,campaignKey, campaignKey);
			}
		}else if (null != campaignKey && null ==campaignStartDate && null == campaignEndDate) {
			if(null != paging) {
				page = campaignRepo.findByCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(campaignKey, campaignKey, paging);
			}else {
				masterCampaigns = campaignRepo.findByCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(campaignKey, campaignKey, sort);
			}
		}else if (null != campaignKey && null !=campaignStartDate && null == campaignEndDate) {
			if(null != paging) {
				page = campaignRepo.findByCampaignStartDateGreaterThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(campaignStartDate, campaignKey, campaignKey, paging);
			}else {
				masterCampaigns = campaignRepo.findByCampaignStartDateGreaterThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(campaignStartDate, campaignKey, campaignKey);
			}
		}else if (null != campaignKey && null ==campaignStartDate && null != campaignEndDate) {
			if(null != paging) {
				page = campaignRepo.findByCampaignEndDateLessThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(campaignEndDate, campaignKey, campaignKey, paging);
			}else {
				masterCampaigns = campaignRepo.findByCampaignEndDateLessThanEqualAndCampaignCodeContainsOrCampaignNameContainsAllIgnoreCase(campaignEndDate, campaignKey, campaignKey);
			}
		}else if (null == campaignKey && null !=campaignStartDate && null != campaignEndDate) {
			if(null != paging) {
				page = campaignRepo.findByCampaignStartDateGreaterThanEqualAndCampaignEndDateLessThanEqual(campaignStartDate, campaignEndDate, paging);
			}else {
				masterCampaigns = campaignRepo.findByCampaignStartDateGreaterThanEqualAndCampaignEndDateLessThanEqual(campaignStartDate, campaignEndDate);
			}
		}else if (null == campaignKey && null !=campaignStartDate && null == campaignEndDate) {
			if(null != paging) {
				page = campaignRepo.findAllByCampaignStartDateGreaterThanEqual(campaignStartDate, paging);
			}else {
				masterCampaigns = campaignRepo.findAllByCampaignStartDateGreaterThanEqual(campaignStartDate);
			}
		}else if (null == campaignKey && null ==campaignStartDate && null != campaignEndDate) {
			if(null != paging) {
				page = campaignRepo.findAllByCampaignEndDateLessThanEqual(campaignEndDate, paging);
			}else {
				masterCampaigns = campaignRepo.findAllByCampaignEndDateLessThanEqual(campaignEndDate);
			}
		}else {
			page = campaignRepo.findAll(paging);
		}

		List<DTOCampaign> dtoCampaigns = new ArrayList<DTOCampaign>();
		DTOCampaign dtoCampaign = new DTOCampaign();
		dtoCampaign.setCampaignCode("-1");
		dtoCampaign.setCampaignName("Select  All");
		dtoCampaigns.add(dtoCampaign);
		
		ResponseCampaign responseCampaign = new ResponseCampaign();
		
		if (null != page) {
			masterCampaigns = page.getContent();
			responseCampaign.setCurrentPage(page.getNumber());
			responseCampaign.setTotalItems(page.getNumberOfElements());
			responseCampaign.setTotalPages(page.getTotalPages());
		}

		if (null == masterCampaigns) {
			responseCampaign.setCampaigns(dtoCampaigns);
			return responseCampaign;
		}
		
		for (MasterCampaign masterCampaign : masterCampaigns) {
			dtoCampaign = new DTOCampaign();
			BeanUtils.copyProperties(masterCampaign, dtoCampaign);
			//dtoCampaign.setMembers(buildCampaingMembersByCampaignCode(dtoCampaign.getCampaignCode()));
			//dtoCampaign.setLeads(buildCampaingLeadssByCampaignCode(dtoCampaign.getCampaignCode()));
			dtoCampaigns.add(dtoCampaign);
		}
		responseCampaign.setCampaigns(dtoCampaigns);
		return responseCampaign;
	}
	
	public ResponseCampaign getLeadsByCampaign(String campaignCode) {
		MasterCampaign masterCampaign = campaignRepo.findCampaignByCampaignCode(campaignCode);
		if (null != masterCampaign) {
			return null;
		}

		ResponseCampaign responseCampaign = new ResponseCampaign();
		DTOCampaign dtoCampaign = new DTOCampaign();
		BeanUtils.copyProperties(masterCampaign, dtoCampaign);
		dtoCampaign.setLeads(buildCampaingLeadssByCampaignCode(dtoCampaign.getCampaignCode()));
		responseCampaign.setCampaign(dtoCampaign);
		return responseCampaign;
	}

	



	public ResponseCampaign getCampaign(String campaignCode) {
		MasterCampaign masterCampaign = campaignRepo.findCampaignByCampaignCode(campaignCode);
		if (null == masterCampaign) {
			return null;
		}
		//log.info("/campaign/{campaignCode}" +campaignCode );
		ResponseCampaign responseCampaign = new ResponseCampaign();
		DTOCampaign dtoCampaign = new DTOCampaign();
		BeanUtils.copyProperties(masterCampaign, dtoCampaign);
		//log.info(" BeanUtils /campaign/{campaignCode}" +campaignCode );
		dtoCampaign.setMembers(buildCampaingMembersByCampaignCode(dtoCampaign.getCampaignCode()));
		//dtoCampaign.setLeads(buildCampaingLeadssByCampaignCode(dtoCampaign.getCampaignCode()));
		responseCampaign.setCampaign(dtoCampaign);
		return responseCampaign;
	}

	public ResponseCampaign updateCampaign(RequestCampaign requestCampaign) {
		String campaignCode = requestCampaign.getCampaignCode();
		if (null == campaignCode || campaignCode.isEmpty()) {
			return null;
		}
		MasterCampaign masterCampaign = campaignRepo.findCampaignByCampaignCode(campaignCode);
		if (masterCampaign == null) {
			return null;
		}
		updateMasterCampaign(masterCampaign, requestCampaign);
		processCampaignMembers(requestCampaign);
		return getCampaign(campaignCode);
	}

	public List<RelationCampaignMembers> getRelationCampaignMembers(String campaignCode) {
		return campaignMemberRepo.getMembersByCampaignCode(Long.parseLong(campaignCode));
	}

	private List<ResponseDTOHamararojgarUser> buildCampaingMembersByCampaignCode(String campaignCode) {
		List<RelationCampaignMembers> relationCampaignMembers = getRelationCampaignMembers(campaignCode);
		if (null == relationCampaignMembers) {
			return null;
		}

		List<User> userModels = new ArrayList<User>();
		for (RelationCampaignMembers relationCampaignMembers2 : relationCampaignMembers) {
			User userModel = serviceMember.getModelUser(relationCampaignMembers2.getMemberCode());
			if (null != userModel) {
				userModels.add(userModel);
			}
		}
		if (userModels.isEmpty()) {
			return null;
		}

		List<ResponseDTOHamararojgarUser> responseDTOHamararojgarUsers = new ArrayList<ResponseDTOHamararojgarUser>();
		for (User user : userModels) {
			ResponseDTOHamararojgarUser responseDTOHamararojgarUser = new ResponseDTOHamararojgarUser();
			responseDTOHamararojgarUser.setId(user.getId());
			responseDTOHamararojgarUser.setUsername(user.getUsername());
			responseDTOHamararojgarUser.setRole(user.getRole());
			MasterUserRoleType masterUserRoleType = repoMasterUserRoleType.findByShortCode(user.getRole());
			if(null != masterUserRoleType) {
				responseDTOHamararojgarUser.setRoleName(masterUserRoleType.getUserRoleName());
			}
			responseDTOHamararojgarUsers.add(responseDTOHamararojgarUser);
		}
		return responseDTOHamararojgarUsers;
	}
	
	public Set<Long> getMembers(String campaignCode) {
		List<RelationCampaignMembers> members = campaignMemberRepo.getMembersByCampaignCode(Long.parseLong(campaignCode));
		if(null == members || members.isEmpty()) {
			return null;
		}
		
		Set<Long> existMemmbers = new HashSet<Long>();
		for (RelationCampaignMembers campaignMember : members) {
			existMemmbers.add(campaignMember.getMemberCode());
		}
		return existMemmbers;
	}

	private void updateMasterCampaign(MasterCampaign masterCampaign, RequestCampaign requestCampaign) {
		if (null != requestCampaign.getCampaignDescription() && !requestCampaign.getCampaignDescription().isEmpty()) {
			masterCampaign.setCampaignDescription(requestCampaign.getCampaignDescription());
		}

		if (null != requestCampaign.getCampaignName() && !requestCampaign.getCampaignName().isEmpty()) {
			masterCampaign.setCampaignName(requestCampaign.getCampaignName());
		}
		masterCampaign.setCampaignStartDate(Instant.parse(requestCampaign.getCampaignStartDate()));
		masterCampaign.setCampaignEndDate(Instant.parse(requestCampaign.getCampaignEndDate()));
		campaignRepo.save(masterCampaign);
	}
	
	public ResponseCampaign getCampaignByMemberId(String memberId) {
		
		List<RelationCampaignMembers> relationCampaignMembers = campaignMemberRepo.getCampaignsByMemberCode(Long.parseLong(memberId));
		List<DTOCampaign> dtoCampaigns = new ArrayList<DTOCampaign>();
		ResponseCampaign responseCampaign = new ResponseCampaign();
		DTOCampaign dtoCampaign = new DTOCampaign();
		dtoCampaign.setCampaignCode("-1");
		dtoCampaign.setCampaignName("Select  Campaign");
		dtoCampaigns.add(dtoCampaign);
		if (null == relationCampaignMembers) {
			responseCampaign.setCampaigns(dtoCampaigns);
			return responseCampaign;
		}
		List<String>  campaignCodes = new ArrayList<String>();
		for (RelationCampaignMembers relationCampaignMember : relationCampaignMembers) {
			campaignCodes.add(String.valueOf(relationCampaignMember.getCampaignCode()));
		}
		List<MasterCampaign> masterCampaigns = null;
		User userModel = serviceMember.getModelUser(Long.parseLong(memberId));
		if(ServerConstants.USER_ROLE_FLDA.equalsIgnoreCase(userModel.getRole())) {
			masterCampaigns = campaignRepo.findByCampaignCodeInAndCampaignEndDateGreaterThanEqual(campaignCodes, Instant.now());	
		}else {
			masterCampaigns = campaignRepo.findByCampaignCodeIn(campaignCodes);
		}
		
		for (MasterCampaign masterCampaign : masterCampaigns) {
			dtoCampaign = new DTOCampaign();
			BeanUtils.copyProperties(masterCampaign, dtoCampaign);
			dtoCampaigns.add(dtoCampaign);
		}
		responseCampaign.setCampaigns(dtoCampaigns);
		return responseCampaign;
	}
	
	public MasterCampaign getMasterCampaignById(Long  masterCampaignId) {
		MasterCampaign masterCampaign = null;
		Optional<MasterCampaign> optionalMasterCampaign =  campaignRepo.findById(masterCampaignId);
		if(optionalMasterCampaign.isPresent()) {
			masterCampaign = optionalMasterCampaign.get();
		}
		return masterCampaign;
	}
	
	public ResponseCampaign getMembersByCampaign(String campaignCode) {
		MasterCampaign masterCampaign = campaignRepo.findCampaignByCampaignCode(campaignCode);
		if (null == masterCampaign) {
			return null;
		}
		ResponseCampaign responseCampaign = new ResponseCampaign();
		DTOCampaign dtoCampaign = new DTOCampaign();
		BeanUtils.copyProperties(masterCampaign, dtoCampaign);
		dtoCampaign.setMembers(buildCampaingMembersByCampaignCode(dtoCampaign.getCampaignCode()));
		responseCampaign.setCampaign(dtoCampaign);
		return responseCampaign;
	}

	public ResponseCampaign getCampaign(RequestRojgarSearchParameter requestSearchParameter) {
		if (null == requestSearchParameter) {
			return null;
		}
		if (null == requestSearchParameter.getSize() || null == requestSearchParameter.getPage()) {
			return null;
		}
		if (0 >= requestSearchParameter.getSize() || 0 > requestSearchParameter.getPage()) {
			return null;
		}
		Page<MasterCampaign> page = null;
		Sort sortByCampaingNameASC=Sort.by("campaignName").ascending();
		Pageable paging = PageRequest.of(requestSearchParameter.getPage(), requestSearchParameter.getSize(),
				sortByCampaingNameASC);
		if(null != requestSearchParameter.getCampaignCodes() && 0<requestSearchParameter.getCampaignCodes().length ) {
			List<Long> inputAsList = Arrays.asList(requestSearchParameter.getCampaignCodes());
			List<String> strings =  inputAsList.stream().map(Object::toString)
                    .collect(Collectors.toList());
			page = campaignRepo.findByCampaignCodeIn(strings, paging);
		}else {
			page = campaignRepo.findAll(paging);
		}
		
		ResponseCampaign responseCampaign = buildResponseCampaign(page);
		return responseCampaign;
	}
	
	public ResponseCampaign getCampaignMembers(RequestRojgarSearchParameter requestSearchParameter) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private ResponseCampaign buildResponseCampaign(Page<MasterCampaign> page) {
		List<MasterCampaign> masterCampaigns = null;
		ResponseCampaign responseCampaign = new ResponseCampaign(); 
		if (null != page) {
			masterCampaigns = page.getContent();
			responseCampaign.setCurrentPage(page.getNumber());
			responseCampaign.setTotalItems(page.getNumberOfElements());
			responseCampaign.setTotalPages(page.getTotalPages());
		}
		if(null != masterCampaigns && masterCampaigns.size()> 0) {
			List<DTOCampaign> dtoCampaigns = new ArrayList<DTOCampaign>();
			for (MasterCampaign masterCampaign : masterCampaigns) {
				DTOCampaign dtoCampaign = new DTOCampaign();
				dtoCampaign.setCampaignCode(masterCampaign.getCampaignCode());
				dtoCampaign.setCampaignName(masterCampaign.getCampaignName());
				dtoCampaigns.add(dtoCampaign);
			}
			responseCampaign.setCampaigns(dtoCampaigns);
		}
		if(responseCampaign.getCampaigns().size()==0) {
			return null;
		}
		return responseCampaign;
	}

	private List<RelationCampaignLead> getRelationCampaignLeads(String campaignCode) {
		List<RelationCampaignLead>  campaignLeads = campaignLeadRepo.getLeadsByCampaignCode(campaignCode);
		return campaignLeads;
	}
	
	private List<ResponseDTOLead> buildCampaingLeadssByCampaignCode(String campaignCode) {
		List<RelationCampaignLead> relationCampaignLeads = getRelationCampaignLeads(campaignCode);
		if (null == relationCampaignLeads) {
			return null;
		}

		List<LeadMaster> leadMasters = new ArrayList<LeadMaster>();
		for (RelationCampaignLead relationCampaignLead : relationCampaignLeads) {
			LeadMaster leadMaster = serviceLeadMaster.getLeadMaster(relationCampaignLead.getLeadCode());
			if (null != leadMaster) {
				leadMasters.add(leadMaster);
			}
		}
		if (leadMasters.isEmpty()) {
			return null;
		}

		List<ResponseDTOLead> responseDTOLeads = new ArrayList<ResponseDTOLead>();
		for (LeadMaster leadMaster : leadMasters) {
			ResponseDTOLead responseDTOLead = new ResponseDTOLead();
			responseDTOLead.setId(leadMaster.getId());
			responseDTOLead.setLeadType(leadMaster.getType());
			responseDTOLead.setLeadMemberName(leadMaster.getName());
			responseDTOLeads.add(responseDTOLead);
		}
		return responseDTOLeads;
	}

	private void processCampaignMembers(RequestCampaign requestCampaign) {
		if (null != requestCampaign.getMembers() && !requestCampaign.getMembers().isEmpty()) {
			Set<Long> requestMembers = requestCampaign.getMembers();
			Set<Long> existMemebrs=getMembers(requestCampaign.getCampaignCode());
			if(null != existMemebrs && !existMemebrs.isEmpty()) {
				requestMembers.removeAll(existMemebrs);
			}
			for (Long memberCode : requestMembers) {
				RelationCampaignMembers relationCampaignMembers = new RelationCampaignMembers();
				relationCampaignMembers.setCampaignCode(Long.parseLong(requestCampaign.getCampaignCode()));
				relationCampaignMembers.setMemberCode(memberCode);
				relationCampaignMembers.setEntryDateTime(Instant.now());
				campaignMemberRepo.save(relationCampaignMembers);
			}
		}
	}




}