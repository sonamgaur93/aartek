package com.hamararojgar.serviceimpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.EmployerDto;
import com.hamararojgar.model.Employer;
import com.hamararojgar.payload.response.ResponseEmployer;
import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.repo.EmployerRepo;


@Service
public class ServiceEmployer {
	
	private static final Logger log = LogManager.getLogger(ServiceEmployer.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");
	
	@Autowired
	EmployerRepo employerRepo;

	public ResponseHamaraRojgar getEmployerList(Map<String, String> searchParameters) {
		reqLog.info("getEmployerList called");
		Sort sort = Sort.by("name").ascending();
		Pageable paging = null;
		Integer size = null;
		Integer pageNumber = null;
		try {
			size = Integer.valueOf(searchParameters.get("size"));
			pageNumber = Integer.valueOf(searchParameters.get("page"));
			paging = PageRequest.of(pageNumber, size, sort);
		}catch(Exception exception) {
			
		}
		String companyName = searchParameters.get("company");
		companyName = (null == companyName? "": companyName.trim());
		
		String contactName = searchParameters.get("name");
		contactName = (null == contactName? "": contactName.trim());
		
		String email = searchParameters.get("email");
		email = (null == email? "": email.trim());
		
		String contact = searchParameters.get("contact");
		contact = (null == contact? "": contact.trim());
		
		List<String> statusValues = new ArrayList<>();
		String status = searchParameters.get("status");
		if(null == status || status.trim().isEmpty()) {
			status = "ALL";
		}
		
		if("ALL".equalsIgnoreCase(status)){
			statusValues.add("ACTIVE");
			statusValues.add("IN-ACTIVE");
			statusValues.add("BLOCKED");
		}else {
			statusValues.add(status);
		}
		
		List<Boolean> verfiedValues = new ArrayList<>();
		
		String verified = searchParameters.get("verified");
		if(null == verified || verified.trim().isEmpty()) {
			verified = "ALL";
		}
		if("ALL".equalsIgnoreCase(verified)){
			verfiedValues.add(true);
			verfiedValues.add(false);
		}else if(verified.equalsIgnoreCase("Verified")){
			verfiedValues.add(true);
		}else if(verified.equalsIgnoreCase("Not Verified")){
			verfiedValues.add(false);
		}
		
		List<Employer> employerList = null;
		Page<Employer> employerPageList = null;
		if(companyName.isEmpty() && contactName.isEmpty() && email.isEmpty() && contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findByEmailVerificationInAndStatusIn(verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByEmailVerificationInAndStatusIn(verfiedValues, statusValues, sort);
			}
		}else if(!companyName.isEmpty() && !contactName.isEmpty() && !email.isEmpty() && !contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(companyName, contactName, email, contact, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(companyName, contactName, email, contact, verfiedValues,statusValues,sort);
			}
		}else if(!companyName.isEmpty() && contactName.isEmpty() && email.isEmpty() && contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByCompanyContainsIgnoreCaseAndEmailVerificationInAndStatusIn(companyName, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByCompanyContainsIgnoreCaseAndEmailVerificationInAndStatusIn(companyName, verfiedValues,statusValues,sort);
			}
		}else if(companyName.isEmpty() && !contactName.isEmpty() && email.isEmpty() && contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByNameContainsIgnoreCaseAndEmailVerificationInAndStatusIn(contactName, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByNameContainsIgnoreCaseAndEmailVerificationInAndStatusIn(contactName, verfiedValues,statusValues,sort);
			}
		}else if(companyName.isEmpty() && contactName.isEmpty() && !email.isEmpty() && contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByEmailContainsIgnoreCaseAndEmailVerificationInAndStatusIn(email, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByEmailContainsIgnoreCaseAndEmailVerificationInAndStatusIn(email, verfiedValues,statusValues,sort);
			}
		}else if(companyName.isEmpty() && contactName.isEmpty() && email.isEmpty() && !contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByPhoneContainsIgnoreCaseAndEmailVerificationInAndStatusIn(contact, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByPhoneContainsIgnoreCaseAndEmailVerificationInAndStatusIn(contact, verfiedValues,statusValues,sort);
			}
		}else if(!companyName.isEmpty() && !contactName.isEmpty() && email.isEmpty() && contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailVerificationInAndStatusIn(companyName, contactName, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailVerificationInAndStatusIn(companyName, contactName, verfiedValues,statusValues,sort);
			}
		}else if(!companyName.isEmpty() && contactName.isEmpty() && !email.isEmpty() && contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByCompanyContainsIgnoreCaseAndEmailContainsIgnoreCaseAndEmailVerificationInAndStatusIn(companyName, email, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByCompanyContainsIgnoreCaseAndEmailContainsIgnoreCaseAndEmailVerificationInAndStatusIn(companyName, email, verfiedValues,statusValues,sort);
			}
		}else if(!companyName.isEmpty() && contactName.isEmpty() && email.isEmpty() && !contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByCompanyContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(companyName, contact, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByCompanyContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(companyName, contact, verfiedValues,statusValues,sort);
			}
		}else if(companyName.isEmpty() && !contactName.isEmpty() && !email.isEmpty() && contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByNameContainsIgnoreCaseAndEmailContainsAndEmailVerificationInAndStatusIn(contactName, email, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByNameContainsIgnoreCaseAndEmailContainsAndEmailVerificationInAndStatusIn(contactName, email, verfiedValues,statusValues,sort);
			}
		}else if(companyName.isEmpty() && !contactName.isEmpty() && email.isEmpty() && !contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByNameContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(contactName, contact, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByNameContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(contactName, contact, verfiedValues,statusValues,sort);
			}
		}else if(companyName.isEmpty() && contactName.isEmpty() && !email.isEmpty() && !contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByEmailContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(email, contact, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByEmailContainsIgnoreCaseAndPhoneContainsAndEmailVerificationInAndStatusIn(email, contact, verfiedValues,statusValues,sort);
			}
		}else if(!companyName.isEmpty() && !contactName.isEmpty() && !email.isEmpty() && contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndEmailVerificationInAndStatusIn(companyName, contactName, email, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByCompanyContainsIgnoreCaseAndNameContainsIgnoreCaseAndEmailContainsAndEmailVerificationInAndStatusIn(companyName, contactName, email, verfiedValues,statusValues,sort);
			}
		}else if(!companyName.isEmpty() && !contactName.isEmpty() && email.isEmpty() && !contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByCompanyContainsIgnoreCaseAndNameContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(companyName, contactName, contact, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByCompanyContainsIgnoreCaseAndNameContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(companyName, contactName, contact, verfiedValues,statusValues,sort);
			}
		}else if(!companyName.isEmpty() && contactName.isEmpty() && !email.isEmpty() && !contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByCompanyContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(companyName, email, contact, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByCompanyContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(companyName, email, contact, verfiedValues,statusValues,sort);
			}
		}else if(companyName.isEmpty() && !contactName.isEmpty() && !email.isEmpty() && !contact.isEmpty()) {
			if(null != paging) {
				employerPageList = employerRepo.findAllByNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(contactName, email, contact, verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByNameContainsIgnoreCaseAndEmailContainsAndPhoneContainsAndEmailVerificationInAndStatusIn(contactName, email, contact, verfiedValues,statusValues,sort);
			}
		}else {
			if(null != paging) {
				employerPageList = employerRepo.findByEmailVerificationInAndStatusIn(verfiedValues,statusValues,paging);
				employerList = employerPageList.getContent();
			}else {
				employerList = employerRepo.findAllByEmailVerificationInAndStatusIn(verfiedValues, statusValues, sort);
			}
		}

		if(null == employerList) {
			return null;
		}
		ResponseEmployer responseEmployer = new ResponseEmployer();
		if(null != employerPageList) {
			responseEmployer.setCurrentPage(employerPageList.getNumber());
			responseEmployer.setTotalItems(employerPageList.getNumberOfElements());
			responseEmployer.setTotalPages(employerPageList.getTotalPages());
		}else {
			responseEmployer.setCurrentPage(1);
			responseEmployer.setTotalItems(employerList.size());
			responseEmployer.setTotalPages(1);
		}
		List<EmployerDto> employers = new ArrayList<EmployerDto>();
		for (Employer employer : employerList) {
			EmployerDto employerDto = new EmployerDto();
			employerDto.setId(employer.getId());
			employerDto.setName(employer.getName());
			employerDto.setCompany(employer.getCompany());
			employerDto.setEmail(employer.getEmail());
			employerDto.setPhone(employer.getPhone());
			employers.add(employerDto);
		}
		responseEmployer.setEmployers(employers);
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		responseHamaraRojgar.setContent(responseEmployer);
		responseHamaraRojgar.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
		responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		return responseHamaraRojgar;
	}
	
	public EmployerDto getEmployer(Long id) {
		
		Optional<Employer > optionalEmployer = employerRepo.findById(id);
		if(!optionalEmployer.isPresent()) {
			return null;
		}
		Employer employer = optionalEmployer.get();
		EmployerDto employerDto = new EmployerDto();
		employerDto.setId(employer.getId());
		employerDto.setName(employer.getName());
		employerDto.setCompany(employer.getCompany());
		log.info("At getEmployer {} ", employerDto);
		return employerDto;
		
	}
	
	public List<Employer>  getEmployers(Long[] memberCodes){
		List<Long> inputAsList = Arrays.asList(memberCodes);
		return employerRepo.findAllById(inputAsList);
	}
	
}