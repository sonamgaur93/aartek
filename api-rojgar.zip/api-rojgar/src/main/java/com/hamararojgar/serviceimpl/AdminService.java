package com.hamararojgar.serviceimpl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hamararojgar.dto.AddUpdateJobDto;
import com.hamararojgar.dto.EmployerDto;
import com.hamararojgar.dto.JobDetailsDto;
import com.hamararojgar.dto.JobSeekerDto;
import com.hamararojgar.dto.ResponseDTOEmployer;
import com.hamararojgar.dto.ResponseDTOJobSeeker;
import com.hamararojgar.dto.ResponseDTOModuleComment;
import com.hamararojgar.dto.ResponseDTORefferal;
import com.hamararojgar.dto.StatusDTO;
import com.hamararojgar.dto.UserDto;
import com.hamararojgar.model.AddJobSeekerDto;
import com.hamararojgar.model.AdvertisementsMaster;
import com.hamararojgar.model.AppliedJobs;
import com.hamararojgar.model.BusinessTypeMaster;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.JobMaster;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.JobSeekerSkillMap;
import com.hamararojgar.model.JobSkillMap;
import com.hamararojgar.model.ModelModuleComment;
import com.hamararojgar.model.NotificationMaster;
import com.hamararojgar.model.SkillMaster;
import com.hamararojgar.model.User;
import com.hamararojgar.payload.request.RequestModelModulComment;
import com.hamararojgar.payload.response.ResponseModuleComment;
import com.hamararojgar.payload.response.ResponseRojgarJob;
import com.hamararojgar.payload.response.ResponseUser;
import com.hamararojgar.repo.AdvertisementsMasterRepo;
import com.hamararojgar.repo.BusinessTypeMasterRepo;
import com.hamararojgar.repo.EmployerRepo;
import com.hamararojgar.repo.JobMasterRepo;
import com.hamararojgar.repo.JobSeekerMasterRepo;
import com.hamararojgar.repo.JobSeekerSkillMapRepo;
import com.hamararojgar.repo.JobSkillMapRepo;
import com.hamararojgar.repo.NotificationMasterRepo;
import com.hamararojgar.repo.RepoModuleComment;
import com.hamararojgar.repo.SkillMasterRepo;
import com.hamararojgar.repo.UserRepo;
import com.hamararojgar.util.RojgarConstantProperties;

import jdk.internal.org.jline.utils.Log;

@Service
public class AdminService {
	
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");
	private static final Logger log = LogManager.getLogger(AdminService.class);
	@Autowired
	JobSeekerMasterRepo jobSeekerMasterRepo;
	
	@Autowired
	JobSeekerSkillMapRepo jobSeekerSkillMapRepo;
	
	@Autowired
	SkillMasterRepo skillMasterRepo;
	
	@Autowired
	EmployerRepo employerRepo;
	
	@Autowired
	JdbcTemplate jdbcTemplate; 
	
	@Autowired
	JobMasterRepo jobMasterRepo;
	
	@Autowired
	NotificationMasterRepo notificationMasterRepo;

	@Autowired
	AdvertisementsMasterRepo advertisementsMasterRepo;
	
	@Autowired
	BusinessTypeMasterRepo businessTypeMasterRepo;
	
	@Autowired
	private RojgarConstantProperties constantProperties;
	
	
	@Autowired
	private RepoModuleComment  repoModuleComment;
	
	@Autowired
	private AWSS3Service awss3Service;
	
	@Autowired
	private UserRepo userRepo;
	
	public Page<JobSeekerMaster> getJobSeekerList(Pageable pageable, String name, String contact, String email, String verified, String status) {
		 Page<JobSeekerMaster> data = null;
		List<Boolean> v = new ArrayList<>();
		List<String> s = new ArrayList<>();
		if(verified.equalsIgnoreCase("All")){
			 v.add(true);
			 v.add(false);
		}else if(verified.equalsIgnoreCase("Verified")){
			 v.add(true);
		}else if(verified.equalsIgnoreCase("Not Verified")){
			v.add(false);
		}
		if(status.equalsIgnoreCase("All")){
			 s.add("ACTIVE");
			 s.add("IN-ACTIVE");
			 s.add("BLOCKED");
		}else{
			s.add(status);
		}
		Pageable sortedpage = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by("id").descending());
		
		if(name.equalsIgnoreCase("") && contact.equalsIgnoreCase("") && email.equalsIgnoreCase("")){
			data = jobSeekerMasterRepo.findByVerifiedAndStatus(v,s,sortedpage);
			/*if(v.size() ==  0 && status.equalsIgnoreCase("All")){
				data = jobSeekerMasterRepo.findAll(sortedpage);
			}else if(v.size() ==  0 && s.size() ==  1){
				data = jobSeekerMasterRepo.findByStatus(s, sortedpage);
			}else{
				data = jobSeekerMasterRepo.findByVerifiedAndStatus(v,s,sortedpage);
			}*/
			
		}else if(!name.equalsIgnoreCase("") && contact.equalsIgnoreCase("") && email.equalsIgnoreCase("")){
			data = jobSeekerMasterRepo.findAllByNameLike(name,v,s,sortedpage);
		}else if(name.equalsIgnoreCase("") && !contact.equalsIgnoreCase("") && email.equalsIgnoreCase("")){
			data = jobSeekerMasterRepo.findAllByContactLike(contact,v,s,sortedpage);
		}else if(name.equalsIgnoreCase("") && contact.equalsIgnoreCase("") && !email.equalsIgnoreCase("")){
			data = jobSeekerMasterRepo.findAllByEmailLike(email,v,s,sortedpage);
		}else if(!name.equalsIgnoreCase("") && !contact.equalsIgnoreCase("") && email.equalsIgnoreCase("")){
			data = jobSeekerMasterRepo.findByNameLikeAndContactLike(name,contact,v,s,sortedpage);
		}else if(!name.equalsIgnoreCase("") && contact.equalsIgnoreCase("") && !email.equalsIgnoreCase("")){
			data = jobSeekerMasterRepo.findByNameLikeAndEmailLike(name, email,v,s, sortedpage);
		}else if(name.equalsIgnoreCase("") && !contact.equalsIgnoreCase("") && !email.equalsIgnoreCase("")){
			data = jobSeekerMasterRepo.findByContactLikeAndEmailLike(contact, email,v,s, sortedpage);
		}else if(!name.equalsIgnoreCase("") && !contact.equalsIgnoreCase("") && !email.equalsIgnoreCase("")){
			data = jobSeekerMasterRepo.findByNameLikeAndEmailLikeAndContactLike(name, email, contact,v,s, sortedpage);
		}else{
			data = jobSeekerMasterRepo.findAll(sortedpage);
		}
		
		return data;
	}
	


	public JobSeekerDto getJobSeekerById(Long id) {
		JobSeekerDto jobSeekerDto = new JobSeekerDto();
		try {
			Optional<JobSeekerMaster> jobSeekerMaster = jobSeekerMasterRepo.findById(id);
			if(jobSeekerMaster.isPresent()){
				JobSeekerMaster jobSeeker = jobSeekerMaster.get();
				jobSeekerDto.setAddress(jobSeeker.getAddress());
				jobSeekerDto.setAdhaar_image_url(jobSeeker.getAdhaar_image_url());
				jobSeekerDto.setAvailability(jobSeeker.getAvailability());
				jobSeekerDto.setContact(jobSeeker.getContact());
				jobSeekerDto.setCurrent_location(jobSeeker.getCurrent_location());
				jobSeekerDto.setExpected_compensation(jobSeeker.getExpected_compensation());
				jobSeekerDto.setExpected_salary(jobSeeker.getExpected_salary());
				jobSeekerDto.setExperience(jobSeeker.getExperience());
				jobSeekerDto.setFather_name(jobSeeker.getFather_name());
				jobSeekerDto.setId(jobSeeker.getId().intValue());
				jobSeekerDto.setMessage(jobSeeker.getMessage());
				jobSeekerDto.setName(jobSeeker.getName());
				jobSeekerDto.setPreferred_location(jobSeeker.getPreferred_location());
				jobSeekerDto.setProfile_pic_url(jobSeeker.getProfile_pic_url());
				jobSeekerDto.setRecording_url(jobSeeker.getRecording_url());
				jobSeekerDto.setStatus(jobSeeker.getStatus());
				jobSeekerDto.setEmail(jobSeeker.getEmail());
				jobSeekerDto.setVerified(jobSeeker.getVerified());
				jobSeekerDto.setEmailVerification(jobSeeker.getEmailVerification());
				jobSeekerDto.setMobileVerification(jobSeeker.getMobileVerification());
				jobSeekerDto.setAccountVerification(jobSeeker.getAccountVerification());
				List<SkillMaster> skillList = new ArrayList<SkillMaster>();
				List<JobSeekerSkillMap> skillMap =  jobSeekerSkillMapRepo.findByJobSeekerId(jobSeeker.getId().intValue());
				for(JobSeekerSkillMap skill : skillMap){
					Optional<SkillMaster> master =  skillMasterRepo.findById((long)skill.getSkillId());
					if(master.isPresent()){
						skillList.add(master.get());
					}
				}
				jobSeekerDto.setSkills(skillList);
			}
		} catch (Exception e) { 
			// TODO: handle exception
		}
		return jobSeekerDto;
	}

	public boolean updateInfBlockedStatus(StatusDTO statusDTO) {
		boolean result = false;
		try {
			Optional<JobSeekerMaster> jobSeekerMaster = jobSeekerMasterRepo.findById(Long.parseLong(statusDTO.getId()));
			if(jobSeekerMaster.isPresent()){
				JobSeekerMaster user = jobSeekerMaster.get();
				if(statusDTO.getStatus().equalsIgnoreCase("BLOCK")){
					user.setStatus("BLOCKED");
				}else{
					if(user.getVerified()!=null && user.getVerified()){
						user.setStatus("ACTIVE");
					}else{
						user.setStatus("IN-ACTIVE");
					}
				}
				jobSeekerMasterRepo.save(user);
				RequestModelModulComment requestModelModulComment = buildRequestModelModuleComment(statusDTO, "JOB_SEEKER");
				createModelModuleComment(requestModelModulComment );
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	




	public int updateJobSeekerDetails(AddJobSeekerDto addJobSeekerDto) {
		int result = 0;
		try {
			if(addJobSeekerDto.getJob_seeker_id()!=0){
				Optional<JobSeekerMaster> jobSeekerO = jobSeekerMasterRepo.findById((long)addJobSeekerDto.getJob_seeker_id());
				if(jobSeekerO.isPresent()){
					JobSeekerMaster jobSeeker = jobSeekerO.get();
					if(addJobSeekerDto.getAdhaar_image_multipart()!=null){
						String adhaarUrl  = saveAdhaarImage(addJobSeekerDto.getAdhaar_image_multipart(),jobSeeker.getId());
						jobSeeker.setAdhaar_image_url(constantProperties.getBaseURLAdhar()+adhaarUrl);
					}
					if(addJobSeekerDto.getProfile_pic_multipart()!=null){
						String profileUrl  = saveProfileImage(addJobSeekerDto.getProfile_pic_multipart(),jobSeeker.getId());
						jobSeeker.setProfile_pic_url(constantProperties.getBaseURLProfile()+profileUrl);
					}
					jobSeeker.setAddress(addJobSeekerDto.getAddress());
					jobSeeker.setAvailability(addJobSeekerDto.getAvailability());
					jobSeeker.setContact(addJobSeekerDto.getContact_no());
					jobSeeker.setCurrent_location(addJobSeekerDto.getCurrent_location());
					jobSeeker.setExpected_compensation(addJobSeekerDto.getExpected_compensation());
					jobSeeker.setExpected_salary(addJobSeekerDto.getExpected_salary());
					jobSeeker.setExperience(addJobSeekerDto.getExperience());
					jobSeeker.setFather_name(addJobSeekerDto.getFather_name());
					jobSeeker.setMessage(addJobSeekerDto.getMessage());
					jobSeeker.setName(addJobSeekerDto.getName());
					jobSeeker.setPreferred_location(addJobSeekerDto.getPreferred_location());
					jobSeeker.setSkills(addJobSeekerDto.getSkills());
					jobSeeker.setStatus(addJobSeekerDto.getStatus());
					jobSeeker.setEmail(addJobSeekerDto.getEmail());
					jobSeeker.setVerified(addJobSeekerDto.getVerified());
					jobSeeker.setEmailVerification(addJobSeekerDto.getEmailVerification());
					jobSeeker.setMobileVerification(addJobSeekerDto.getMobileVerification());
					jobSeeker.setAccountVerification(addJobSeekerDto.getAccountVerification());
					String skillArr[] = addJobSeekerDto.getSkills().split(",");
					if(skillArr.length>0){
						jdbcTemplate.update("delete from job_seeker_skill_map where job_seeker_id="+jobSeeker.getId().intValue());
						for(String s : skillArr){
							JobSeekerSkillMap  skillMap = new JobSeekerSkillMap();
							skillMap.setJobSeekerId(jobSeeker.getId().intValue());
							skillMap.setSkillId(Integer.parseInt(s));
							jobSeekerSkillMapRepo.save(skillMap);
						}
					}
					jobSeekerMasterRepo.save(jobSeeker);
					result = jobSeeker.getId().intValue();
					RequestModelModulComment requestModelModulComment = new RequestModelModulComment();
					requestModelModulComment.setModuleComment(addJobSeekerDto.getComment());
					requestModelModulComment.setModuleName("JOB_SEEKER");
					requestModelModulComment.setRecordId(String.valueOf(jobSeeker.getId()));
					createModelModuleComment(requestModelModulComment );
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public Page<Employer> getEmployerList(Pageable pageable, String name, String contact, String email, String verified, String status) {
		Pageable sortedpage = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by("id").descending());
		List<Boolean> v = new ArrayList<>();
		List<String> s = new ArrayList<>();
		if(verified.equalsIgnoreCase("All")){
			 v.add(true);
			 v.add(false);
		}else if(verified.equalsIgnoreCase("Verified")){
			 v.add(true);
		}else if(verified.equalsIgnoreCase("Not Verified")){
			v.add(false);
		}
		if(status.equalsIgnoreCase("All")){
			 s.add("ACTIVE");
			 s.add("IN-ACTIVE");
			 s.add("BLOCKED");
		}else if(status.equalsIgnoreCase("IN-ACTIVE")){
			 s.add("IN-ACTIVE");
		}else{
			s.add(status);
		}
		Page<Employer> data = null;
		if(name.equalsIgnoreCase("") && contact.equalsIgnoreCase("") && email.equalsIgnoreCase("")){
			data = employerRepo.findByVerifiedAndStatus(v,s,sortedpage);
		}else if(!name.equalsIgnoreCase("") && contact.equalsIgnoreCase("") && email.equalsIgnoreCase("")){
			data = employerRepo.findAllByNameLike(name,v,s,sortedpage);
		}else if(name.equalsIgnoreCase("") && !contact.equalsIgnoreCase("") && email.equalsIgnoreCase("")){
			data = employerRepo.findAllByContactLike(contact,v,s, sortedpage);
		}else if(name.equalsIgnoreCase("") && contact.equalsIgnoreCase("") && !email.equalsIgnoreCase("")){
			data = employerRepo.findAllByEmailLike(email,v,s,sortedpage);
		}else if(!name.equalsIgnoreCase("") && !contact.equalsIgnoreCase("") && email.equalsIgnoreCase("")){
			data = employerRepo.findByNameLikeAndContactLike(name,contact,v,s,sortedpage);
		}else if(!name.equalsIgnoreCase("") && contact.equalsIgnoreCase("") && !email.equalsIgnoreCase("")){
			data = employerRepo.findByNameLikeAndEmailLike(name, email,v,s, sortedpage);
		}else if(name.equalsIgnoreCase("") && !contact.equalsIgnoreCase("") && !email.equalsIgnoreCase("")){
			data = employerRepo.findByContactLikeAndEmailLike(contact, email, v,s,sortedpage);
		}else if(!name.equalsIgnoreCase("") && !contact.equalsIgnoreCase("") && !email.equalsIgnoreCase("")){
			data = employerRepo.findByNameLikeAndEmailLikeAndContactLike(name, email, contact,v,s, sortedpage);
		}else{
			data = employerRepo.findAll(sortedpage);
		}
		return data;
	}
	
	public Page<Employer> getEmployerList(Map<String, String> searchParameters) {
		Sort sort = Sort.by("name").descending();
		Pageable paging = null;
		Integer size = null;
		Integer pageNumber = null;
		try {
			size = Integer.valueOf(searchParameters.get("size"));
			pageNumber = Integer.valueOf(searchParameters.get("page"));
			paging = PageRequest.of(pageNumber, size, sort);
		}catch(Exception exception) {
		}
		
		
		Page<Employer> data = employerRepo.findAll(paging);
		return data;
	}

	public ResponseDTOEmployer getEmployerById(Long id) {
		ResponseDTOEmployer responseDto = new ResponseDTOEmployer();
		Employer  employer = null;
		try {
			Optional<Employer> emp = employerRepo.findById(id);
			if(emp.isPresent()){
				 employer = emp.get();
				 BeanUtils.copyProperties(employer, responseDto);
			}
		} catch (Exception e) { 
			// TODO: handle exception
		}
		return responseDto;
	}

	
//	public Employer getEmployerById1(Long id) {
//		Employer  employer = null;
//		try {
//			Optional<Employer> emp = employerRepo.findById(id);
//			if(emp.isPresent()){
//				 employer = emp.get();
//				 
//				 if(employer.getRefferalInfo().getRefferalType()=="campaign") {
//					 
//				 }
//			}
//		} catch (Exception e) { 
//			// TODO: handle exception
//		}
//		return employer;
//	}
	
	
	
	

	public boolean updateBlockedStatusClickedEmp(StatusDTO statusDTO) {
		boolean result = false;
		try {
			Optional<Employer> jobSeekerMaster = employerRepo.findById(Long.parseLong(statusDTO.getId()));
			if(jobSeekerMaster.isPresent()){
				Employer user = jobSeekerMaster.get();
				if(statusDTO.getStatus().equalsIgnoreCase("BLOCK")){
					user.setStatus("BLOCKED");
				}else{
					if(user.getVerified()!=null && user.getVerified()){
						user.setStatus("ACTIVE");
					}else{
						user.setStatus("IN-ACTIVE");
					}
				}
				employerRepo.save(user);
				RequestModelModulComment  requestModelModulComment = buildRequestModelModuleComment(statusDTO, "SATHI");
				createModelModuleComment(requestModelModulComment);
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	
	

	public int updateEmployerDetails(EmployerDto employer) {
		int result = 0;
		try {
			if(employer.getId()!=0){
				Optional<Employer> empO = employerRepo.findById((long)employer.getId());
				if(empO.isPresent()){
					Employer emp = empO.get();
					if(employer.getCompany_image_multipart()!=null){
						String companyImage  = saveCompanyImage(employer.getCompany_image_multipart(),employer.getId().intValue(),"_1");
						emp.setCompanyImage(constantProperties.getBaseURLCompanyImage()+companyImage);
					}
					if(employer.getCompany_image2_multipart()!=null){
						String companyImage  = saveCompanyImage(employer.getCompany_image2_multipart(),employer.getId().intValue(),"_2");
						emp.setCompanyImage2(constantProperties.getBaseURLCompanyImage()+companyImage);
					}
					if(employer.getCompany_image3_multipart()!=null){
						String companyImage  = saveCompanyImage(employer.getCompany_image3_multipart(),employer.getId().intValue(),"_3");
						emp.setCompanyImage3(constantProperties.getBaseURLCompanyImage()+companyImage);
					}
					if(employer.getCompany_image4_multipart()!=null){
						String companyImage  = saveCompanyImage(employer.getCompany_image4_multipart(),employer.getId().intValue(),"_4");
						emp.setCompanyImage4(constantProperties.getBaseURLCompanyImage()+companyImage);
					}
					if(employer.getCompany_image5_multipart()!=null){
						String companyImage  = saveCompanyImage(employer.getCompany_image5_multipart(),employer.getId().intValue(),"_5");
						emp.setCompanyImage5(constantProperties.getBaseURLCompanyImage()+companyImage);
					}
					emp.setAddress(employer.getAddress());
					emp.setBusinessType(employer.getBusinessType());
					emp.setCompany(employer.getCompany());
					emp.setDescription(employer.getDescription());
					emp.setEmail(employer.getEmail());
					emp.setGst(employer.getGst());
					emp.setName(employer.getName());
					emp.setPan(employer.getPan());
					if(null != employer.getPhone() && !employer.getPhone().trim().isEmpty()) {
						emp.setPhone(employer.getPhone());
					}
					
					emp.setStatus(employer.getStatus());
					emp.setEmailVerification(employer.getEmailVerification());
					emp.setMobileVerification(employer.getMobileVerification());
					emp.setAccountVerification(employer.getAccountVerification());
					/*if(employer.getStatus().equalsIgnoreCase("Active")){
						emp.setVerified(true);
					}*/
					emp.setVerified(employer.getVerified());
					employerRepo.save(emp);
					result = emp.getId().intValue();
					RequestModelModulComment requestModelModulComment = new RequestModelModulComment();
					requestModelModulComment.setModuleComment(employer.getComment());
					requestModelModulComment.setModuleName("SATHI");
					requestModelModulComment.setRecordId(String.valueOf(employer.getId()));
					createModelModuleComment(requestModelModulComment);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public Page<JobMaster> getJobList(Map<String, String> parameters) {
		for (String parameKey : parameters.keySet()) {
			log.info("Param Key:: ["+parameKey+"] Param Value:: ["+parameters.get(parameKey)+"]");
		}
		Page<JobMaster> data = null;
		Pageable paging = null;
		Integer size = null;
		Integer pageNumber = null;
		try {
			size = Integer.valueOf(parameters.get("size"));
			pageNumber = Integer.valueOf(parameters.get("page"));
		}catch(Exception exception) {
			
		}
		if(null == size || 0> size) {
			size= 10;
		}
		if(null == pageNumber || 0> pageNumber) {
			pageNumber= 0;
		}
		Sort sort = Sort.by("id").descending();
		paging = PageRequest.of(pageNumber, size, sort);
		String jobId= (parameters.containsKey("jobId")?parameters.get("jobId").trim(): null);
		if(null == jobId) {
			jobId= "";
		}
		String location= (parameters.containsKey("location")?parameters.get("location").trim(): null);
		if(null == location) {
			location= "";
		}
		String title= (parameters.containsKey("title")?parameters.get("title").trim(): null);
		if(null == title) {
			title= "";
		}
		String status= (parameters.containsKey("status")?parameters.get("status").trim(): null);
		if(null == status) {
			status= "All";
		}
		List<String> statusList = new ArrayList<>();
		if("All".equalsIgnoreCase(status)) {
			statusList.add("Open");
			statusList.add("Closed");
		}else {
			statusList.add(status);
		}
		
		for (String statsData : statusList) {
			log.info("statsData Key:: ["+statsData+"]");
		}
		String employerId= (parameters.containsKey("employerId")?parameters.get("employerId").trim(): null);
		if(null == employerId) {
			employerId= "";
		}
		List<String>  empIds= null;
		if(null != employerId && !employerId.trim().isEmpty()) {
			String[] employerIds = employerId.trim().split("\\s*,\\s*");
			empIds = new ArrayList<String>( Arrays.asList(employerIds ) );
		}
		if(null != empIds && empIds.isEmpty()) {
			empIds = null;
		}
		if(title.equalsIgnoreCase("") && location.equalsIgnoreCase("") && jobId.equalsIgnoreCase("") && null == empIds){
			log.info("Condition 1");
			data = jobMasterRepo.findByStatusIn(statusList, paging);
		}else if(!title.equalsIgnoreCase("") && location.equalsIgnoreCase("") && jobId.equalsIgnoreCase("")){
			log.info("Condition 2");
			data = jobMasterRepo.findByTitleContainsAndStatusIn(title,statusList,paging);
		}else if(title.equalsIgnoreCase("") && !location.equalsIgnoreCase("")  && jobId.equalsIgnoreCase("")){
			log.info("Condition 3");
			data = jobMasterRepo.findByLocationContainsAndStatusIn(location,statusList,paging);
		}else if(title.equalsIgnoreCase("") && location.equalsIgnoreCase("")  && !jobId.equalsIgnoreCase("")){
			log.info("Condition 4");
			data = jobMasterRepo.findByJobTrackIdContainsAndStatusIn(jobId,statusList,paging);
		}else if(!title.equalsIgnoreCase("") && !location.equalsIgnoreCase("") && jobId.equalsIgnoreCase("")){
			log.info("Condition 5");
			data = jobMasterRepo.findByTitleContainsAndLocationContainsAndStatusIn(title,location,statusList,paging);
		}else if(title.equalsIgnoreCase("") && !location.equalsIgnoreCase("") && !jobId.equalsIgnoreCase("")){
			log.info("Condition 6");
			data = jobMasterRepo.findByLocationContainsAndJobTrackIdContainsAndStatusIn(location,jobId,statusList,paging);
		}else if(!title.equalsIgnoreCase("") && location.equalsIgnoreCase("") && !jobId.equalsIgnoreCase("")){
			log.info("Condition 7");
			data = jobMasterRepo.findByTitleContainsAndJobTrackIdContainsAndStatusIn(title,jobId,statusList,paging);
		}else if(!title.equalsIgnoreCase("") && !location.equalsIgnoreCase("") && !jobId.equalsIgnoreCase("")){
			log.info("Condition 8");
			data = jobMasterRepo.findByTitleContainsAndLocationContainsAndJobTrackIdContainsAndStatusIn(title,location,jobId,statusList,paging);
		}else if(null !=empIds && !empIds.isEmpty()){
			log.info("Condition 9");
			data = jobMasterRepo.findByEmployerIdInAndStatusIn(empIds,statusList,paging);
		}else{
			log.info("Condition 10");
			data = jobMasterRepo.findAll(paging);
		}
		return data;
	}

	public boolean updateJobStatus(StatusDTO statusDTO) {
		boolean result = false;
		try {
			Optional<JobMaster> job = jobMasterRepo.findById(Long.parseLong(statusDTO.getId()));
			if(job.isPresent()){
				JobMaster user = job.get();
				user.setStatus(statusDTO.getStatus());
				jobMasterRepo.save(user);
				RequestModelModulComment requestModelModulComment = buildRequestModelModuleComment(statusDTO, "JOB");
				createModelModuleComment(requestModelModulComment );
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	@Autowired
	JobSkillMapRepo  jobSkillMapRepo;

	public JobDetailsDto getJobDetailsById(Long id) {
		JobDetailsDto jobDetailsDto = new JobDetailsDto();
		try {
			Optional<JobMaster> job = jobMasterRepo.findById(id);
			if(job.isPresent()){
				JobMaster jobMaster = job.get();
				jobDetailsDto.setAccomodation(jobMaster.getAccomodation());
				jobDetailsDto.setComponsation(jobMaster.getComponsation());
				jobDetailsDto.setDescription(jobMaster.getDescription());
				jobDetailsDto.setEmployerId(Integer.parseInt(jobMaster.getEmployerId()));
				jobDetailsDto.setExperience(jobMaster.getExperience());
				jobDetailsDto.setFood(jobMaster.getFood());
				jobDetailsDto.setId(id);
				jobDetailsDto.setJob_type(jobMaster.getJob_type());
				jobDetailsDto.setLeave_policy(jobMaster.getLeave_policy());
				jobDetailsDto.setLocation(jobMaster.getLocation());
				jobDetailsDto.setOpenings(jobMaster.getOpenings());
				jobDetailsDto.setRecording_url(jobMaster.getRecording_url());
				jobDetailsDto.setStatus(jobMaster.getStatus());
				jobDetailsDto.setTitle(jobMaster.getTitle());
				jobDetailsDto.setContact(jobMaster.getContact());
				List<SkillMaster> skillList = new ArrayList<SkillMaster>();
				List<JobSkillMap> skillMap =  jobSkillMapRepo.findByJobId(jobMaster.getId().intValue());
				for(JobSkillMap skill : skillMap){
					Optional<SkillMaster> master =  skillMasterRepo.findById((long)skill.getSkill_id());
					if(master.isPresent()){
						skillList.add(master.get());
					}
				}
				jobDetailsDto.setSkills(skillList);
			}
		} catch (Exception e) { 
			// TODO: handle exception
		}
		return jobDetailsDto;
	}

	public int updateJobDetails(AddUpdateJobDto jobDto) {
		int result = 0;
		try {
			if(jobDto.getJobId()!=0){
				Optional<JobMaster> jobO = jobMasterRepo.findById((long)jobDto.getJobId());
				if(jobO.isPresent()){
					JobMaster job = jobO.get();
					job.setAccomodation(jobDto.getAccomodation());
					job.setComponsation(jobDto.getComponsation());
					job.setDescription(jobDto.getDescription());
					job.setExperience(jobDto.getExperience());
					job.setFood(jobDto.getFood());
					job.setJob_type(jobDto.getJob_type());
					job.setLeave_policy(jobDto.getLeave_policy());
					job.setLocation(jobDto.getLocation());
					job.setOpenings(jobDto.getOpenings());
					job.setStatus(jobDto.getStatus());
					job.setTitle(jobDto.getTitle());
					job.setContact(jobDto.getContact());
					job.setSkills(jobDto.getSkills());
					jdbcTemplate.update("delete from job_skill_map where job_id="+job.getId().intValue());
					job.setSkills(jobDto.getSkills());
					String skillArr[] = jobDto.getSkills().split(",");
					if(skillArr.length>0){
						for(String s : skillArr){
							try {
								JobSkillMap  skillMap = new JobSkillMap();
								skillMap.setJob_id(job.getId().intValue());
								skillMap.setSkill_id(Integer.parseInt(s));
								jobSkillMapRepo.save(skillMap);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
					jobMasterRepo.save(job);
					RequestModelModulComment requestModelModulComment = new RequestModelModulComment();
					requestModelModulComment.setModuleName("JOB");
					requestModelModulComment.setRecordId(String.valueOf(jobDto.getJobId()));
					requestModelModulComment.setModuleComment(jobDto.getComment());
					createModelModuleComment(requestModelModulComment );
					result = job.getId().intValue();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public NotificationMaster getNotificationById(Long id) {
		NotificationMaster  notificationMaster =null;
		Optional<NotificationMaster> jobSeekerMaster = notificationMasterRepo.findById(id);
		if(jobSeekerMaster.isPresent()){
			notificationMaster = jobSeekerMaster.get();
		}
		return notificationMaster;
	}

	public AdvertisementsMaster getAdvertisementById(Long id) {
		AdvertisementsMaster  notificationMaster =null;
		Optional<AdvertisementsMaster> jobSeekerMaster = advertisementsMasterRepo.findById(id);
		if(jobSeekerMaster.isPresent()){
			notificationMaster = jobSeekerMaster.get();
		}
		return notificationMaster;
	}

	public boolean updateBlockedStatusClickedAdd(StatusDTO statusDTO) {
		boolean result = false;
		try {
			Optional<AdvertisementsMaster> jobSeekerMaster = advertisementsMasterRepo.findById(Long.parseLong(statusDTO.getId()));
			if(jobSeekerMaster.isPresent()){
				AdvertisementsMaster user = jobSeekerMaster.get();
				if(statusDTO.getStatus().equalsIgnoreCase("IN-ACTIVE")){
					user.setStatus("ACTIVE");
				}else{
						user.setStatus("IN-ACTIVE");
				}
				advertisementsMasterRepo.save(user);
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	public Page<BusinessTypeMaster> getBusinessTypeList(Pageable pageable, String name) {
		 Page<BusinessTypeMaster> data = null;
		
		Pageable sortedpage = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by("id").descending());
		
		if("".equalsIgnoreCase(name.trim())){
			data = businessTypeMasterRepo.findAll(sortedpage);
		}else if(!"".equalsIgnoreCase(name.trim())){
			data = businessTypeMasterRepo.findAllByNameLike(name,sortedpage);
		}else{
			data = businessTypeMasterRepo.findAll(sortedpage);
		}
		
		return data;
	}
	

	
	private String saveAdhaarImage(MultipartFile adhaar_image_multipart, Long id) {
		String fName = "";
		try {
			if (null != adhaar_image_multipart) {
				fName = "job_seeker_adhaar_" + id + "."
						+ FilenameUtils.getExtension(adhaar_image_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(adhaar_image_multipart, constantProperties.getS3bucketAdhar(), fName);
				} else {
					Path path = Paths.get(constantProperties.getUploadFolderAdhar()+ fName);
					Files.write(path, adhaar_image_multipart.getBytes());
				}
			}
			
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}
	
	private String saveProfileImage(MultipartFile profile_pic_multipart, Long id) {
		String fName = "";
		try {
			if (null != profile_pic_multipart) {
				fName = "job_seeker_profile_" + id + "."
						+ FilenameUtils.getExtension(profile_pic_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(profile_pic_multipart, constantProperties.getS3bucketProfile(), fName);
				} else {
					Path path = Paths.get(constantProperties.getUploadFolderProfile() + fName);
					Files.write(path, profile_pic_multipart.getBytes());
				}
			}
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}
	
	private String saveCompanyImage(MultipartFile recording_multipart, int id, String string) {
		String fName = "";
		try {
			if (null != recording_multipart) {
				fName = "employer_company_image_" + string + "_" + id + "."
						+ FilenameUtils.getExtension(recording_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(recording_multipart, constantProperties.getS3bucketCompanyImage(), fName);
				} else {
					Path path = Paths.get(constantProperties.getUploadFolderCompanyImage() + fName);
					Files.write(path, recording_multipart.getBytes());
				}
			}
			
		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}

	private boolean createModelModuleComment(RequestModelModulComment requestModelModulComment) {
		try {
			ModelModuleComment modelModuleComment = new ModelModuleComment();
			modelModuleComment.setModuleName(requestModelModulComment.getModuleName());
			modelModuleComment.setComment(requestModelModulComment.getModuleComment());
			modelModuleComment.setRecordId(requestModelModulComment.getRecordId());
			modelModuleComment.setEntryDateTime(Instant.now());
			repoModuleComment.save(modelModuleComment);
			return true;
		}catch(Exception exception) {
			
		}
		return false;
	}
	
	private RequestModelModulComment buildRequestModelModuleComment(StatusDTO statusDTO, String moduleName) {
		RequestModelModulComment requestModelModulComment = new RequestModelModulComment();
		requestModelModulComment.setModuleName(moduleName);
		requestModelModulComment.setRecordId(statusDTO.getId());
		requestModelModulComment.setModuleComment(statusDTO.getComment());
		return requestModelModulComment;
	}



	public ResponseUser getAgentsByType(String type) {
	
		 List<User> findByRole = userRepo.findByRole(type);
		 
		 List<ResponseDTORefferal> finalList = new ArrayList<ResponseDTORefferal>();
		 
		 ResponseUser users = new ResponseUser();
		 
		 for (User user : findByRole) {
			
		 ResponseDTORefferal	 temp = new ResponseDTORefferal();
		 temp.setCode(String.valueOf(user.getId()));
		 temp.setName(user.getUsername());
		 
		 finalList.add(temp);
			 
		}
		 
		 users.setUsers(finalList);
		
		 return users;
		
	}

//	private List<ResponseDTOJobSeeker> buildAppliedSeekers(int jobId, Map<String, String> searchParameters,
//			ResponseRojgarJob responseRojgarJob) {
//		List<User> userData = null;
//		Page<User> userDataPage = null;
//		if (null == searchParameters || searchParameters.isEmpty()) {
//			appliedJobs = appliedJobsRepo.findByJobId(jobId);
//		} else {
//			Pageable paging = null;
//			Integer size = null;
//			Integer pageNumber = null;
//			try {
//				size = Integer.valueOf(searchParameters.get("size"));
//				pageNumber = Integer.valueOf(searchParameters.get("page"));
//			} catch (Exception exception) {
//
//			}
//			if (null != size && size >= 1) {
//				if (null == pageNumber || pageNumber < 0) {
//					pageNumber = 0;
//				}
//				paging = PageRequest.of(pageNumber, size);
//			}
//			if (null == paging) {
//				appliedJobs = appliedJobsRepo.findByJobId(jobId);
//			} else {
//				appliedJobsPage = appliedJobsRepo.findByJobId(jobId, paging);
//				appliedJobs = appliedJobsPage.getContent();
//			}
//		}
//		if (null == appliedJobs) {
//			return null;
//		}
//		if (null != appliedJobsPage) {
//			responseRojgarJob.setCurrentPage(appliedJobsPage.getNumber());
//			responseRojgarJob.setTotalItems(appliedJobsPage.getNumberOfElements());
//			responseRojgarJob.setTotalPages(appliedJobsPage.getTotalPages());
//		} else {
//			responseRojgarJob.setCurrentPage(1);
//			responseRojgarJob.setTotalItems(appliedJobs.size());
//			responseRojgarJob.setTotalPages(1);
//		}
//		
//		Map<Integer, JobSeekerMaster> mapJobSeekerMaster = new HashMap<Integer, JobSeekerMaster>();
//		for (AppliedJobs appliedJob : appliedJobs) {
//
//			if (!mapJobSeekerMaster.containsKey(Integer.valueOf(appliedJob.getJobSeekerId()))) {
//				JobSeekerMaster jobSeekerMaster = getJobSeeker(appliedJob.getJobSeekerId());
//				mapJobSeekerMaster.put(Integer.valueOf(appliedJob.getJobSeekerId()), jobSeekerMaster);
//			}
//		}
//		List<ResponseDTOJobSeeker> responseDTOJobSeekers = new ArrayList<ResponseDTOJobSeeker>();
//		for (Integer jobSeekerId : mapJobSeekerMaster.keySet()) {
//			JobSeekerMaster jobSeekerMaster = mapJobSeekerMaster.get(jobSeekerId);
//			ResponseDTOJobSeeker responseDTOJobSeeker = new ResponseDTOJobSeeker();
//			responseDTOJobSeeker.setId(Long.valueOf(jobSeekerId));
//			responseDTOJobSeeker.setName(jobSeekerMaster.getName());
//			responseDTOJobSeeker.setContact(jobSeekerMaster.getContact());
//			responseDTOJobSeekers.add(responseDTOJobSeeker);
//		}
//		return responseDTOJobSeekers;
//	}


	
}
