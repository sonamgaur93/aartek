package com.hamararojgar.serviceimpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hamararojgar.dto.ResponseDTOHamararojgarUser;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.RelationCampaignMembers;
import com.hamararojgar.model.User;
import com.hamararojgar.payload.request.RequestRojgarSearchParameter;
import com.hamararojgar.payload.response.ResponseHamaraRojgarUser;
import com.hamararojgar.repo.CampaignMemberRepo;
import com.hamararojgar.repo.UserRepo;
import com.hamararojgar.util.Util;

@Service
public class ServiceMember {

	@Autowired
	private UserRepo userRepo;

	@Autowired
	Util util;

	@Autowired
	private CampaignMemberRepo campaignMemberRepo;

	public List<User> getModelUsers() {
		List<User> users = null;
		users = userRepo.findAll();
		return users;
	}

	public User getModelUser(Long id) {
		Optional<User> user = userRepo.findById(id);
		if (user.isPresent()) {
			return user.get();
		}
		return null;
	}

	public ResponseHamaraRojgarUser getUsers(Pageable paging) {
		List<User> users = null;
		Page<User> page = null;

		if (null == paging) {
			users = userRepo.findAll();
		} else {
			page = userRepo.findAll(paging);
			users = page.getContent();
		}

		if (null == users) {
			return null;
		}
		List<ResponseDTOHamararojgarUser> dtoHamararojgarUsers = new ArrayList<ResponseDTOHamararojgarUser>();
		for (User user : users) {
			ResponseDTOHamararojgarUser responseDTOHamararojgarUser = new ResponseDTOHamararojgarUser();
			BeanUtils.copyProperties(user, responseDTOHamararojgarUser);
			dtoHamararojgarUsers.add(responseDTOHamararojgarUser);
		}

		ResponseHamaraRojgarUser responseUserRole = new ResponseHamaraRojgarUser();
		responseUserRole.setUsers(dtoHamararojgarUsers);

		if (null != page) {
			responseUserRole.setCurrentPage(page.getNumber());
			responseUserRole.setTotalItems(page.getNumberOfElements());
			responseUserRole.setTotalPages(page.getTotalPages());
		}
		return responseUserRole;
	}

	public ResponseHamaraRojgarUser getUsers(RequestRojgarSearchParameter requestSearchParameter) {
		ResponseHamaraRojgarUser responseHamaraRojgarUser = null;
		if (null == requestSearchParameter) {
			return responseHamaraRojgarUser;
		}

		if (null == requestSearchParameter.getSize() || null == requestSearchParameter.getPage()) {
			return responseHamaraRojgarUser;
		}
		if (0 >= requestSearchParameter.getSize() || 0 > requestSearchParameter.getPage()) {
			return responseHamaraRojgarUser;
		}
		responseHamaraRojgarUser = new ResponseHamaraRojgarUser();

		List<Long> requestMembers = new ArrayList<Long>();
		Set<Long> campainMembers = getCampaignMembers(requestSearchParameter.getCampaignCodes());

		if (null != campainMembers) {
			for (Long memberCode : campainMembers) {
				requestMembers.add(memberCode);
			}
		}

		Sort sort = Sort.by("username").ascending();
		Pageable paging = PageRequest.of(requestSearchParameter.getPage(), requestSearchParameter.getSize(),
				sort);
		List<User> users = null;
		Page<User> page = null;
		if (requestMembers.size() == 0) {
			page = userRepo.findAll(paging);
		} else {
			page = userRepo.findByIdIn(requestMembers, paging);
		}
		if (null != page) {
			users = page.getContent();
			responseHamaraRojgarUser.setCurrentPage(page.getNumber());
			responseHamaraRojgarUser.setTotalItems(page.getNumberOfElements());
			responseHamaraRojgarUser.setTotalPages(page.getTotalPages());
		}

		if (null != users && !users.isEmpty()) {
			List<ResponseDTOHamararojgarUser> dtoHamararojgarUsers = new ArrayList<ResponseDTOHamararojgarUser>();
			for (User user : users) {
				ResponseDTOHamararojgarUser responseDTOHamararojgarUser = new ResponseDTOHamararojgarUser();
				responseDTOHamararojgarUser.setId(user.getId());
				responseDTOHamararojgarUser.setUsername(user.getUsername());
				dtoHamararojgarUsers.add(responseDTOHamararojgarUser);
			}
			responseHamaraRojgarUser.setUsers(dtoHamararojgarUsers);
		}
		return responseHamaraRojgarUser;
	}

	private Set<Long> getCampaignMembers(Long[] campaignCodes) {
		List<Long> inputAsList = Arrays.asList(campaignCodes);
		List<RelationCampaignMembers> campaignMembers = campaignMemberRepo
				.getCampaignMembersByCampaignCodeIn(inputAsList);

		if (null != campaignMembers && campaignMembers.size() > 0) {
			Set<Long> members = new HashSet<Long>();
			for (RelationCampaignMembers campaignMember : campaignMembers) {
				members.add(campaignMember.getMemberCode());
			}
			return members;
		}
		return null;
	}

}
