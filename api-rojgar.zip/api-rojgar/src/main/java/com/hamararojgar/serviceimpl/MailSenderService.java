package com.hamararojgar.serviceimpl;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.hamararojgar.util.RojgarConstantProperties;

@Service
public class MailSenderService {
	
	private static final Logger log = LogManager.getLogger(MailSenderService.class);
	
	@Autowired
	private JavaMailSender javaMailSender;	
	
	@Autowired
	private RojgarConstantProperties constantProperties;
	
	@Async
	public void sendMail(String to, String message, String subject){
		try {
			MimeMessage msg = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(msg, true);
			helper.setFrom(constantProperties.getGmailFrom(),"Rojgar");
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setText(message);
			//helper.setText(message, true);
			javaMailSender.send(msg);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	@Async
	public void sendMailBySmtp(String to, String mailContent, String subject){
		Properties props = null;
		Transport transport = null;
		Session mailSession = null;
		MimeMessage message = null;
		try {
			
			
			props = new Properties(System.getProperties());
			props.put("mail.transport.protocol", "smtp");
			props.put("mail.host", constantProperties.getSmtpHost());
			props.put("mail.smtp.host", constantProperties.getSmtpHost());
			props.put("mail.smtp.port", constantProperties.getSmtpPort());
			props.put("mail.smtp.from", "<" + constantProperties.getSmtpFromEmail() + ">");
			mailSession = Session.getInstance(props);
			mailSession.setDebug(false);
			message = new MimeMessage(mailSession);
			message.setFrom(new InternetAddress(constantProperties.getSmtpFromEmail()));
			InternetAddress[] replyToAddress = new InternetAddress[1];
			replyToAddress[0] = new InternetAddress(constantProperties.getSmtpFromEmail());
			message.setReplyTo(replyToAddress);
			message.addRecipient(Message.RecipientType.TO,
					new InternetAddress(to));
			message.setSubject(subject, "UTF-8");
			message.setSentDate(new Date());
			message.setContent(mailContent, "text/HTML; charset=utf-8");
			message.setHeader("Content-Type", "text/html; charset=utf-8");
			//message.setHeader("Content-Transfer-Encoding", "quoted-printable");
			message.saveChanges();
			transport = mailSession.getTransport();
			transport.connect(constantProperties.getSmtpUserName(), constantProperties.getSmtpPassword());
			message.saveChanges();
			transport.sendMessage(message, message.getRecipients(Message.RecipientType.TO));
			transport.close();
			transport = null;
			mailSession = null;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
