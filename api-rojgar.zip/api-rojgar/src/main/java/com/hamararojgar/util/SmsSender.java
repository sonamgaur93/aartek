package com.hamararojgar.util;

import java.net.URLEncoder;
import java.sql.Timestamp;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/*// Install the Java helper library from twilio.com/docs/libraries/java

import com.twilio.Twilio;
import com.twilio.http.TwilioRestClient;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;*/

@Service
public class SmsSender {
	
	private static final Logger log = LogManager.getLogger(SmsSender.class);
	
	//@Value("${app.variables.sms.api.url}")
	private static String apiUrl="https://api.textlocal.in/send/?apikey=fMCrYVbhZYo-9n6eC1pRDPfN0fLQ6bnNWJ1bIQCkvf&message={message}&sender={sender}&numbers={numbers}";
	
	public static void sendSMS(String numbers, String otp) {
		try {
			/*ResponseEntity<String> response = null;
			RestTemplate restTemplate = new RestTemplate();
			String plainCreds = "AC30d11ef732f1ab3b1c9349d064bdbd37:b45a3e96fb306bbee73ca38ed96d7c04";
			byte[] plainCredsBytes = plainCreds.getBytes();
			byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
			String base64Creds = new String(base64CredsBytes);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			headers.add("Authorization", "Basic " + base64Creds);

			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("To", to);
			map.add("From", "+919741099709");
			map.add("Body", "Use "+otp+" to verify your portal account.");

			HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(map, headers);

			response = restTemplate.exchange(MYURL, HttpMethod.POST, entity, String.class);
			System.out.println("SMS API response Code : " + response.getStatusCode());
			System.out.println("SMS API response " + response.getBody());*/
			String sender = "hamroj";
			String newline = "%n";
			String message = "Dear Customer,"+newline+otp+ " is the OTP to Claim your account. Please enter the 6 digit OTP and verify your account."+newline+"Regards"+newline+"Team blujobs"+newline+"Octal Frames Technologies (PE ID 1201160260076269281)";
			message = "Dear Customer,%n "+otp+" is the OTP to Claim your account. Please enter the 6 digit OTP and verify your account.%nRegards%nTeam blujobs%nOctal Frames Technologies (PE ID 1201160260076269281)";
			message = URLEncoder.encode(message,"UTF-8");
			Timestamp requestTime = new Timestamp(System.currentTimeMillis());
			HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
			clientHttpRequestFactory.setConnectTimeout(10000);
			RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
			ResponseEntity<String> response = restTemplate.getForEntity(apiUrl, String.class,
					message, sender,numbers);
			if (response != null) {
				log.info("SMS API response Code : {} Request Time : {} Response Time : {}", response.getStatusCode(),requestTime,new Timestamp(System.currentTimeMillis()));
				log.info("SMS API response : {}", response.getBody());
				
			} else {
				log.info("No Response from API");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}